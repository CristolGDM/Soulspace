
using ORKFramework;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Battles/Block Combatant Spawn")]
	public class BlockCombatantSpawn : BaseColliderZone
	{
		void Start()
		{
			this.gameObject.layer = 2;
			if(this.GetComponent<Collider>() == null && 
				this.GetComponent<Collider2D>() == null)
			{
				UnityWrapper.Destroy(this.gameObject);
			}
			else
			{
				ORK.Game.Scene.AddNoSpawn(this);
			}
		}
		
		
		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "BlockCombatantSpawn.psd");
		}
	}
}
