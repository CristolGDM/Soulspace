
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using ORKFramework;
using System.Collections.Generic;
using System.Text;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/UI/Update UI Text")]
	public class UpdateUIText : MonoBehaviour
	{
		public Text textComponent;

		public float updateTime = 0;

		public string text = "";


		// content object
		public UIContentOrigin contentOrigin = UIContentOrigin.Player;

		public int memberIndex = 0;

		public FindObjectSetting findObject;

		public GameObject contentObject;

		public bool updateObject = false;

		public float objectUpdateTime = 0;


		// variable
		public UIVariableOrigin variableOrigin = UIVariableOrigin.Global;

		public ObjectVariablesComponent objectVariablesComponent;


		// in-game
		private float timeout = 0;

		private float objectTimeout = 0;

		private IContent content;

		private IContentSimple typeContent;

		private VariableHandler handler;

		private List<SceneObjectComponent>  soList;


		/*
		============================================================================
		Text update functions
		============================================================================
		*/
		void Update()
		{
			if(this.updateObject)
			{
				if(this.objectTimeout <= 0)
				{
					this.UpdateObject();
					this.objectTimeout = this.objectUpdateTime;
				}
				else
				{
					this.objectTimeout -= ORK.Core.GUITimeDelta; ;
				}
			}

			if(this.timeout <= 0)
			{
				this.UpdateText();

				this.timeout = this.updateTime;
			}
			else
			{
				this.timeout -= ORK.Core.GUITimeDelta;
			}
		}

		public void UpdateText()
		{
			if(this.textComponent != null)
			{
				if(this.content == null)
				{
					this.UpdateObject();
				}

				this.textComponent.text = TextHelper.ReplaceSpecials(
					this.GetTextUpdate(), this.handler);
			}
		}

		private string GetTextUpdate()
		{
			if(this.content != null)
			{
				string tmp = this.text;

				if(this.content is Combatant)
				{
					Combatant combatant = this.content as Combatant;
					int replace = -2;

					// status value
					if(tmp.Contains("%sv"))
					{
						// base
						replace = TextHelper.GetEnclosedInt(ref tmp, "%sv.base", "%");
						while(replace != -2)
						{
							tmp = tmp.Replace("%sv.base" + replace + "%",
								combatant.Status[replace].GetBaseValue().ToString());
							replace = TextHelper.GetEnclosedInt(ref tmp, "%sv.base", "%");
						}
						// min
						replace = TextHelper.GetEnclosedInt(ref tmp, "%sv.min", "%");
						while(replace != -2)
						{
							tmp = tmp.Replace("%sv.min" + replace + "%",
								combatant.Status[replace].GetMinValue().ToString());
							replace = TextHelper.GetEnclosedInt(ref tmp, "%sv.min", "%");
						}
						// max
						replace = TextHelper.GetEnclosedInt(ref tmp, "%sv.max", "%");
						while(replace != -2)
						{
							tmp = tmp.Replace("%sv.max" + replace + "%",
								combatant.Status[replace].GetMaxValue().ToString());
							replace = TextHelper.GetEnclosedInt(ref tmp, "%sv.max", "%");
						}
						// displayed
						replace = TextHelper.GetEnclosedInt(ref tmp, "%sv.display", "%");
						while(replace != -2)
						{
							tmp = tmp.Replace("%sv.display" + replace + "%",
								combatant.Status[replace].GetDisplayValue().ToString());
							replace = TextHelper.GetEnclosedInt(ref tmp, "%sv.display", "%");
						}
						// preview max
						replace = TextHelper.GetEnclosedInt(ref tmp, "%sv.previewmax", "%");
						while(replace != -2)
						{
							tmp = tmp.Replace("%sv.previewmax" + replace + "%",
								combatant.Status[replace].GetPreviewMaxValue().ToString());
							replace = TextHelper.GetEnclosedInt(ref tmp, "%sv.previewmax", "%");
						}
						// preview
						replace = TextHelper.GetEnclosedInt(ref tmp, "%sv.preview", "%");
						while(replace != -2)
						{
							tmp = tmp.Replace("%sv.preview" + replace + "%",
								combatant.Status[replace].GetPreviewValue(false).ToString());
							replace = TextHelper.GetEnclosedInt(ref tmp, "%sv.preview", "%");
						}
						// current
						replace = TextHelper.GetEnclosedInt(ref tmp, "%sv", "%");
						while(replace != -2)
						{
							tmp = tmp.Replace("%sv" + replace + "%",
								combatant.Status[replace].GetValue().ToString());
							replace = TextHelper.GetEnclosedInt(ref tmp, "%sv", "%");
						}
					}

					// attack attributes
					if(tmp.Contains("%atkattr"))
					{
						// min
						replace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr.min", "%");
						while(replace != -2)
						{
							tmp = tmp.Replace("%atkattr.min" + replace + "%",
								combatant.Status.GetAttackAttribute(replace).GetMinValue().ToString());
							replace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr.min", "%");
						}
						// max
						replace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr.max", "%");
						while(replace != -2)
						{
							tmp = tmp.Replace("%atkattr.max" + replace + "%",
								combatant.Status.GetAttackAttribute(replace).GetMaxValue().ToString());
							replace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr.max", "%");
						}
						// base
						replace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr.base", "%");
						while(replace != -2)
						{
							int subReplace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr.base" + replace + "%", "%");
							while(subReplace != -2)
							{
								tmp = tmp.Replace("%atkattr.base" + replace + "%" + subReplace + "%",
									combatant.Status.GetAttackAttribute(replace).GetBaseValue(subReplace).ToString());
								subReplace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr.base" + replace + "%", "%");
							}
							replace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr.base", "%");
						}
						// start
						replace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr.start", "%");
						while(replace != -2)
						{
							int subReplace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr.start" + replace + "%", "%");
							while(subReplace != -2)
							{
								tmp = tmp.Replace("%atkattr.start" + replace + "%" + subReplace + "%",
									combatant.Status.GetAttackAttribute(replace).GetStartValue(subReplace).ToString());
								subReplace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr.start" + replace + "%", "%");
							}
							replace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr.start", "%");
						}
						// preview
						replace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr.preview", "%");
						while(replace != -2)
						{
							int subReplace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr.preview" + replace + "%", "%");
							while(subReplace != -2)
							{
								tmp = tmp.Replace("%atkattr.preview" + replace + "%" + subReplace + "%",
									combatant.Status.GetAttackAttribute(replace).GetPreviewValue(subReplace).ToString());
								subReplace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr.preview" + replace + "%", "%");
							}
							replace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr.preview", "%");
						}
						// current
						replace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr", "%");
						while(replace != -2)
						{
							int subReplace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr" + replace + "%", "%");
							while(subReplace != -2)
							{
								tmp = tmp.Replace("%atkattr" + replace + "%" + subReplace + "%",
									combatant.Status.GetAttackAttribute(replace).GetValue(subReplace).ToString());
								subReplace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr" + replace + "%", "%");
							}
							replace = TextHelper.GetEnclosedInt(ref tmp, "%atkattr", "%");
						}
					}

					// defence attributes
					if(tmp.Contains("%defattr"))
					{
						// min
						replace = TextHelper.GetEnclosedInt(ref tmp, "%defattr.min", "%");
						while(replace != -2)
						{
							tmp = tmp.Replace("%defattr.min" + replace + "%",
								combatant.Status.GetDefenceAttribute(replace).GetMinValue().ToString());
							replace = TextHelper.GetEnclosedInt(ref tmp, "%defattr.min", "%");
						}
						// max
						replace = TextHelper.GetEnclosedInt(ref tmp, "%defattr.max", "%");
						while(replace != -2)
						{
							tmp = tmp.Replace("%defattr.max" + replace + "%",
								combatant.Status.GetDefenceAttribute(replace).GetMaxValue().ToString());
							replace = TextHelper.GetEnclosedInt(ref tmp, "%defattr.max", "%");
						}
						// base
						replace = TextHelper.GetEnclosedInt(ref tmp, "%defattr.base", "%");
						while(replace != -2)
						{
							int subReplace = TextHelper.GetEnclosedInt(ref tmp, "%defattr.base" + replace + "%", "%");
							while(subReplace != -2)
							{
								tmp = tmp.Replace("%defattr.base" + replace + "%" + subReplace + "%",
									combatant.Status.GetDefenceAttribute(replace).GetBaseValue(subReplace).ToString());
								subReplace = TextHelper.GetEnclosedInt(ref tmp, "%defattr.base" + replace + "%", "%");
							}
							replace = TextHelper.GetEnclosedInt(ref tmp, "%defattr.base", "%");
						}
						// start
						replace = TextHelper.GetEnclosedInt(ref tmp, "%defattr.start", "%");
						while(replace != -2)
						{
							int subReplace = TextHelper.GetEnclosedInt(ref tmp, "%defattr.start" + replace + "%", "%");
							while(subReplace != -2)
							{
								tmp = tmp.Replace("%defattr.start" + replace + "%" + subReplace + "%",
									combatant.Status.GetDefenceAttribute(replace).GetStartValue(subReplace).ToString());
								subReplace = TextHelper.GetEnclosedInt(ref tmp, "%defattr.start" + replace + "%", "%");
							}
							replace = TextHelper.GetEnclosedInt(ref tmp, "%defattr.start", "%");
						}
						// preview
						replace = TextHelper.GetEnclosedInt(ref tmp, "%defattr.preview", "%");
						while(replace != -2)
						{
							int subReplace = TextHelper.GetEnclosedInt(ref tmp, "%defattr.preview" + replace + "%", "%");
							while(subReplace != -2)
							{
								tmp = tmp.Replace("%defattr.preview" + replace + "%" + subReplace + "%",
									combatant.Status.GetDefenceAttribute(replace).GetPreviewValue(subReplace).ToString());
								subReplace = TextHelper.GetEnclosedInt(ref tmp, "%defattr.preview" + replace + "%", "%");
							}
							replace = TextHelper.GetEnclosedInt(ref tmp, "%defattr.preview", "%");
						}
						// current
						replace = TextHelper.GetEnclosedInt(ref tmp, "%defattr", "%");
						while(replace != -2)
						{
							int subReplace = TextHelper.GetEnclosedInt(ref tmp, "%defattr" + replace + "%", "%");
							while(subReplace != -2)
							{
								tmp = tmp.Replace("%defattr" + replace + "%" + subReplace + "%",
									combatant.Status.GetDefenceAttribute(replace).GetValue(subReplace).ToString());
								subReplace = TextHelper.GetEnclosedInt(ref tmp, "%defattr" + replace + "%", "%");
							}
							replace = TextHelper.GetEnclosedInt(ref tmp, "%defattr", "%");
						}
					}
				}

				return tmp.
					Replace("%n", this.content.GetName()).
					Replace("%sn", this.content.GetShortName()).
					Replace("%d", this.content.GetDescription()).
					Replace("%tn", this.typeContent != null ? this.typeContent.GetName() : "").
					Replace("%tsn", this.typeContent != null ? this.typeContent.GetShortName() : "").
					Replace("%td", this.typeContent != null ? this.typeContent.GetDescription() : "");
			}
			else
			{
				return this.text.
					Replace("%n", "").
					Replace("%sn", "").
					Replace("%d", "").
					Replace("%tn", "").
					Replace("%tsn", "").
					Replace("%td", "");
			}
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public void UpdateObject()
		{
			this.content = this.GetContent();
			if(this.content != null)
			{
				this.typeContent = this.content.GetTypeContent();
			}
		}

		public void UpdateVariableHandler(GameObject gameObject)
		{
			this.handler = null;
			if(UIVariableOrigin.Global == this.variableOrigin)
			{
				this.handler = ORK.Game.Variables;
			}
			else if(UIVariableOrigin.ContentObject == this.variableOrigin)
			{
				if(gameObject != null)
				{
					this.handler = ObjectVariablesComponent.Get(gameObject);
				}
			}
			else if(UIVariableOrigin.Object == this.variableOrigin)
			{
				if(this.objectVariablesComponent != null)
				{
					this.handler = this.objectVariablesComponent.GetHandler();
				}
			}
		}

		public IContent GetContent()
		{
			if(UIContentOrigin.Player == this.contentOrigin)
			{
				if(ORK.Game.ActiveGroup.Leader != null)
				{
					this.UpdateVariableHandler(ORK.Game.ActiveGroup.Leader.GameObject);
					return ORK.Game.ActiveGroup.Leader;
				}
			}
			else if(UIContentOrigin.Member == this.contentOrigin)
			{
				Combatant combatant = ORK.Game.ActiveGroup.MemberAt(this.memberIndex);
				this.UpdateVariableHandler(combatant.GameObject);
				return combatant;
			}
			else if(UIContentOrigin.FindObject == this.contentOrigin)
			{
				List<GameObject> list = this.findObject.Find(this.gameObject);
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						CombatantComponent cc = list[i].transform.root.GetComponentInChildren<CombatantComponent>();
						if(cc != null)
						{
							this.UpdateVariableHandler(list[i]);
							return cc.combatant;
						}
						else
						{
							if(this.soList == null)
							{
								this.soList = new List<SceneObjectComponent>();
							}
							list[i].transform.root.GetComponentsInChildren<SceneObjectComponent>(this.soList);
							for(int j = 0; j < this.soList.Count; j++)
							{
								IContent obj = this.soList[j].GetSceneObject();
								if(obj != null)
								{
									this.UpdateVariableHandler(list[i]);
									return obj;
								}
							}
						}
					}
				}
			}
			else if(UIContentOrigin.GameObject == this.contentOrigin)
			{
				if(this.contentObject != null)
				{
					this.UpdateVariableHandler(this.contentObject);
					return ComponentHelper.GetContent(this.contentObject);
				}
			}
			this.UpdateVariableHandler(null);
			return null;
		}
	}
}
