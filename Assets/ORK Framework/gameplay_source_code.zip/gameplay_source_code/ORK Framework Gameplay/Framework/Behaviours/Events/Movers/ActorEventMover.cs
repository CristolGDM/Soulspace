
using ORKFramework;
using ORKFramework.Events;
using System.Collections;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class ActorEventMover : MonoBehaviour
	{
		// objects
		private Transform actor;

		private Transform target;

		private Vector3 position;

		private CharacterController controller;

		private bool applyGravity;


		// time
		private float time;

		private float time2;


		// settings
		private float speed;

		private Function interpolate;

		private Vector3 startPos;

		private Vector3 distancePos;

		private float distanceReduction;

		private bool faceDirection = false;

		private bool ignoreHeightDistance = false;


		// curves
		private AnimationCurve xCurve;

		private float xCurveMultiply = 1;

		private AnimationCurve yCurve;

		private float yCurveMultiply = 1;

		private AnimationCurve zCurve;

		private float zCurveMultiply = 1;

		private bool curveLocalSpace = false;

		private float curveTime = 0;


		// move types
		private bool speedToObject = false;

		private bool speedToPosition = false;

		private bool moveToPosition = false;

		private bool moveToDir = false;

		private bool curveMove = false;

		private BaseEvent callback = null;

		private int next = 0;


		// secure movement
		private bool secureMove = false;

		private Vector3 lastPosition;

		private float lastMoveTime = 0;

		private float secureTime = 0.5f;

		private bool stopAtTarget = false;

		public void StopMoving()
		{
			this.DoCallback();

			this.actor = null;
			this.target = null;
			this.controller = null;
			this.faceDirection = false;
			this.ignoreHeightDistance = false;
			this.speedToObject = false;
			this.speedToPosition = false;
			this.moveToPosition = false;
			this.moveToDir = false;
			this.stopAtTarget = false;
			this.interpolate = null;

			this.curveMove = false;
			this.xCurve = null;
			this.yCurve = null;
			this.zCurve = null;
		}

		protected virtual void DoCallback()
		{
			if(this.callback != null)
			{
				BaseEvent tmp = this.callback;
				this.callback = null;
				tmp.StepFinished(this.next);
			}
		}


		/*
		============================================================================
		Move functions
		============================================================================
		*/
		public void SpeedToObject(Transform a, bool ic, bool g, bool fd, bool ignoreHeightDistance,
			float s, float d, Transform t, BaseEvent cb, int n, float secureTime, bool stopAtTarget)
		{
			this.StopMoving();

			this.actor = a;
			if(ic)
			{
				this.controller = this.actor.GetComponent<CharacterController>();
			}
			this.applyGravity = g;
			this.speed = s;
			this.distanceReduction = d;
			this.target = t;
			this.callback = cb;
			this.next = n;
			this.faceDirection = fd;
			this.ignoreHeightDistance = ignoreHeightDistance;

			if(secureTime >= 0.1f)
			{
				this.secureMove = true;
				this.secureTime = secureTime;
			}
			this.stopAtTarget = stopAtTarget;

			this.speedToObject = true;
		}

		public void SpeedToPosition(Transform a, bool ic, bool g, bool fd, bool ignoreHeightDistance,
			float s, float d, Vector3 pos, BaseEvent cb, int n, float secureTime, bool stopAtTarget)
		{
			this.StopMoving();

			this.actor = a;
			if(ic)
			{
				this.controller = this.actor.GetComponent<CharacterController>();
			}
			this.applyGravity = g;
			this.speed = s;
			this.distanceReduction = d;
			this.position = pos;
			this.callback = cb;
			this.next = n;
			this.faceDirection = fd;
			this.ignoreHeightDistance = ignoreHeightDistance;

			if(secureTime >= 0.1f)
			{
				this.secureMove = true;
				this.secureTime = secureTime;
			}
			this.stopAtTarget = stopAtTarget;

			this.speedToPosition = true;
		}

		public void MoveToPosition(Transform a, bool ic, bool g, bool fd, bool ignoreHeightDistance,
			Vector3 pos, EaseType et, float t)
		{
			this.StopMoving();

			this.actor = a;
			if(ic)
			{
				this.controller = this.actor.GetComponent<CharacterController>();
			}
			this.applyGravity = g;
			this.position = pos;
			this.interpolate = Interpolate.Ease(et);
			this.time = 0;
			this.time2 = t;

			if(fd)
			{
				if(ignoreHeightDistance)
				{
					if(HorizontalPlaneType.XY == ORK.GameSettings.horizontalPlane)
					{
						this.actor.LookAt(new Vector3(this.position.x, this.position.y, this.actor.position.z));
					}
					else
					{
						this.actor.LookAt(new Vector3(this.position.x, this.actor.position.y, this.position.z));
					}
				}
				else
				{
					this.actor.LookAt(this.position);
				}
			}

			this.startPos = this.actor.position;
			this.distancePos = this.position - this.startPos;

			this.moveToPosition = true;
		}

		public void MoveToDirection(Transform a, bool ic, Vector3 d, bool fd, bool ignoreHeightDistance, float s, float t)
		{
			this.StopMoving();

			this.actor = a;
			if(ic)
			{
				this.controller = this.actor.GetComponent<CharacterController>();
			}
			this.position = d;
			this.speed = s;
			this.time = 0;
			this.time2 = t;

			if(fd)
			{
				if(ignoreHeightDistance)
				{
					if(HorizontalPlaneType.XY == ORK.GameSettings.horizontalPlane)
					{
						this.actor.LookAt(new Vector3(this.position.x + this.actor.position.x,
							this.position.y + this.actor.position.y, this.actor.position.z));
					}
					else
					{
						this.actor.LookAt(new Vector3(this.position.x + this.actor.position.x,
							this.actor.position.y, this.position.z + this.actor.position.z));
					}
				}
				else
				{
					this.actor.LookAt(new Vector3(this.position.x + this.actor.position.x,
						this.position.y + this.actor.position.y, this.position.z + this.actor.position.z));
				}
			}
			this.moveToDir = true;
		}

		public void MoveByCurve(Transform a,
			AnimationCurve xCurve, float xMultiply,
			AnimationCurve yCurve, float yMultiply,
			AnimationCurve zCurve, float zMultiply,
			bool localSpace, float time, float curveTime)
		{
			this.StopMoving();

			this.actor = a;
			this.position = this.actor.position;

			this.xCurve = xCurve;
			this.xCurveMultiply = xMultiply;
			this.yCurve = yCurve;
			this.yCurveMultiply = yMultiply;
			this.zCurve = zCurve;
			this.zCurveMultiply = zMultiply;
			this.curveLocalSpace = localSpace;

			this.time = 0;
			this.time2 = time;
			this.curveTime = curveTime;

			this.curveMove = true;
		}


		/*
		============================================================================
		Callbacks functions
		============================================================================
		*/
		protected virtual void OnControllerColliderHit(ControllerColliderHit hit)
		{
			if(this.speedToObject &&
				this.callback != null &&
				hit.gameObject == this.target.gameObject)
			{
				this.speedToObject = false;
				if(this.controller)
				{
					this.controller.Move(Vector3.zero);
				}
				this.DoCallback();
			}
		}

		protected virtual void OnCollisionEnter(Collision collisionInfo)
		{
			if(this.speedToObject &&
				this.callback != null &&
				collisionInfo.gameObject == this.target.gameObject)
			{
				this.speedToObject = false;
				if(this.controller)
				{
					this.controller.Move(Vector3.zero);
				}
				this.DoCallback();
			}
		}

		protected virtual void OnCollisionEnter2D(Collision2D collisionInfo)
		{
			if(this.speedToObject &&
				this.callback != null &&
				collisionInfo.gameObject == this.target.gameObject)
			{
				this.speedToObject = false;
				if(this.controller)
				{
					this.controller.Move(Vector3.zero);
				}
				this.DoCallback();
			}
		}

		protected virtual void OnTriggerEnter(Collider other)
		{
			if(this.speedToObject &&
				this.callback != null &&
				other.gameObject == this.target.gameObject)
			{
				this.speedToObject = false;
				if(this.controller)
				{
					this.controller.Move(Vector3.zero);
				}
				this.DoCallback();
			}
		}

		protected virtual void OnTriggerEnter2D(Collider2D other)
		{
			if(this.speedToObject &&
				this.callback != null &&
				other.gameObject == this.target.gameObject)
			{
				this.speedToObject = false;
				if(this.controller)
				{
					this.controller.Move(Vector3.zero);
				}
				this.DoCallback();
			}
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		protected virtual void Update()
		{
			if(!ORK.Game.Paused)
			{
				if(this.speedToObject)
				{
					if(this.target != null)
					{
						float tmpSpeed = this.speed * ORK.Game.DeltaTime;
						if(this.stopAtTarget)
						{
							float remainingDistance = VectorHelper.Distance(
								this.actor.position, this.target.position, this.ignoreHeightDistance);
							if(remainingDistance < tmpSpeed)
							{
								tmpSpeed = remainingDistance;
							}
						}

						if(this.faceDirection)
						{
							if(this.ignoreHeightDistance)
							{
								if(HorizontalPlaneType.XY == ORK.GameSettings.horizontalPlane)
								{
									this.actor.LookAt(new Vector3(this.target.position.x, this.target.position.y, this.actor.position.z));
								}
								else
								{
									this.actor.LookAt(new Vector3(this.target.position.x, this.actor.position.y, this.target.position.z));
								}
							}
							else
							{
								this.actor.LookAt(this.target.position);
							}
						}

						if(this.controller)
						{
							Vector3 moveDirection = this.faceDirection ?
								Vector3.forward :
								VectorHelper.GetDirection(this.actor.position,
									this.ignoreHeightDistance ?
										new Vector3(this.target.position.x, this.actor.position.y, this.target.position.z) :
										this.target.position);

							if(this.faceDirection)
							{
								moveDirection = this.actor.TransformDirection(moveDirection);
							}

							if(this.applyGravity)
							{
								this.controller.Move((moveDirection.normalized * tmpSpeed) + (Physics.gravity * ORK.Game.DeltaTime));
							}
							else
							{
								this.controller.Move(moveDirection.normalized * tmpSpeed);
							}
						}
						else
						{
							this.actor.position = Vector3.MoveTowards(this.actor.position,
								this.ignoreHeightDistance ?
									new Vector3(this.target.position.x, this.actor.position.y, this.target.position.z) :
									this.target.position,
								tmpSpeed);
						}

						if(this.secureMove && this.actor.position != this.lastPosition)
						{
							this.lastPosition = this.actor.position;
							this.lastMoveTime = Time.time;
						}
					}

					if(this.target == null ||
						(this.secureMove && this.lastMoveTime + this.secureTime < Time.time) ||
						VectorHelper.Distance(this.actor.position, this.target.position, this.ignoreHeightDistance) - this.distanceReduction <= 0.2f)
					{
						this.speedToObject = false;
						if(this.controller)
						{
							this.controller.Move(Vector3.zero);
						}
						this.DoCallback();
					}
				}
				else if(this.speedToPosition)
				{
					float tmpSpeed = this.speed * ORK.Game.DeltaTime;
					if(this.stopAtTarget)
					{
						float remainingDistance = VectorHelper.Distance(
							this.actor.position, this.position, this.ignoreHeightDistance);
						if(remainingDistance < tmpSpeed)
						{
							tmpSpeed = remainingDistance;
						}
					}

					if(this.faceDirection)
					{
						if(this.ignoreHeightDistance)
						{
							if(HorizontalPlaneType.XY == ORK.GameSettings.horizontalPlane)
							{
								this.actor.LookAt(new Vector3(this.position.x, this.position.y, this.actor.position.z));
							}
							else
							{
								this.actor.LookAt(new Vector3(this.position.x, this.actor.position.y, this.position.z));
							}
						}
						else
						{
							this.actor.LookAt(this.position);
						}
					}

					if(this.controller)
					{
						Vector3 moveDirection = this.faceDirection ?
							Vector3.forward :
							VectorHelper.GetDirection(this.actor.position,
								this.ignoreHeightDistance ?
									new Vector3(this.position.x, this.actor.position.y, this.position.z) :
									this.position);

						if(this.faceDirection)
						{
							moveDirection = this.actor.TransformDirection(moveDirection);
						}

						if(this.applyGravity)
						{
							this.controller.Move((moveDirection.normalized * tmpSpeed) + (Physics.gravity * ORK.Game.DeltaTime));
						}
						else
						{
							this.controller.Move(moveDirection.normalized * tmpSpeed);
						}
					}
					else
					{
						this.actor.position = Vector3.MoveTowards(this.actor.position,
							this.ignoreHeightDistance ?
								new Vector3(this.position.x, this.actor.position.y, this.position.z) :
								this.position,
							tmpSpeed);
					}

					if(this.secureMove && this.actor.position != this.lastPosition)
					{
						this.lastPosition = this.actor.position;
						this.lastMoveTime = Time.time;
					}

					if((this.secureMove && this.lastMoveTime + this.secureTime < Time.time) ||
						VectorHelper.Distance(this.actor.position, this.position, this.ignoreHeightDistance) - this.distanceReduction <= 0.2f)
					{
						this.speedToPosition = false;
						if(this.controller)
						{
							this.controller.Move(Vector3.zero);
						}
						this.DoCallback();
					}
				}
				else if(this.moveToPosition)
				{
					this.time += ORK.Game.DeltaTime;
					if(this.controller)
					{
						Vector3 moveDirection = Interpolate.Ease(this.interpolate, this.startPos,
							this.distancePos, this.time, this.time2) - this.actor.position;

						if(this.applyGravity)
						{
							moveDirection += Physics.gravity;
						}
						this.controller.Move(moveDirection);
					}
					else
					{
						this.actor.position = Interpolate.Ease(this.interpolate, this.startPos,
							this.distancePos, this.time, this.time2);
					}

					if(this.time >= this.time2)
					{
						this.moveToPosition = false;
						if(this.controller)
						{
							this.controller.Move(Vector3.zero);
						}
					}
				}
				else if(this.moveToDir)
				{
					float t = ORK.Game.DeltaTime;
					this.time += t;
					if(this.controller)
					{
						this.controller.Move(this.position * this.speed * t);
					}
					else
					{
						this.actor.position += this.position * this.speed * t;
					}

					if(this.time >= this.time2)
					{
						this.moveToDir = false;
						if(this.controller)
						{
							this.controller.Move(Vector3.zero);
						}
					}
				}
				else if(this.curveMove)
				{
					this.time += ORK.Game.DeltaTime;
					float evaluate = this.curveTime * (this.time / this.time2);

					Vector3 tmp = Vector3.zero;
					if(this.xCurve != null)
					{
						tmp.x = this.xCurve.Evaluate(evaluate) * this.xCurveMultiply;
					}
					if(this.yCurve != null)
					{
						tmp.y = this.yCurve.Evaluate(evaluate) * this.yCurveMultiply;
					}
					if(this.zCurve != null)
					{
						tmp.z = this.zCurve.Evaluate(evaluate) * this.zCurveMultiply;
					}

					if(this.curveLocalSpace)
					{
						this.actor.position = this.position;
						this.actor.position = this.actor.TransformPointUnscaled(tmp);
					}
					else
					{
						this.actor.position = this.position + tmp;
					}

					if(this.time >= this.time2)
					{
						this.curveMove = false;
					}
				}
			}
		}
	}
}
