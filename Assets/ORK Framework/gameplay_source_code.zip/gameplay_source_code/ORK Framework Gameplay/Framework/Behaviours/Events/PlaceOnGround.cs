
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Scenes/Place On Ground")]
	public class PlaceOnGround : MonoBehaviour
	{
		public float distance = 100.0f;

		public LayerMask layerMask = -1;

		public Vector3 offset = Vector3.zero;
	
		void Start()
		{
			this.Place();
		}
	
		public void Place()
		{
			RaycastOutput hit;
			if(RaycastHelper.Raycast(transform.position, -Vector3.up, out hit, this.distance, this.layerMask))
			{
				transform.position = hit.point + this.offset;
			}
		}
	
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "PlaceOnGround.psd");
		}
	}
}