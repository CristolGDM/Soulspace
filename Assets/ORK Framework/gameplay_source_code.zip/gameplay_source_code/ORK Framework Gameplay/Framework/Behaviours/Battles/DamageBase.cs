
using ORKFramework;
using UnityEngine;
using System.Collections;

namespace ORKFramework.Behaviours
{
	public abstract class DamageBase : MonoBehaviour
	{
		// ingame
		protected Combatant combatant;

		void OnEnable()
		{
			if(this.combatant != null)
			{
				this.StartCoroutine(this.ReInit());
			}
		}

		private void Start()
		{
			this.Init();
		}

		protected virtual IEnumerator ReInit()
		{
			yield return null;
			this.Init();
		}

		protected virtual void Init()
		{
			this.combatant = ComponentHelper.GetCombatant(this.transform.root.gameObject);
		}

		public Combatant Combatant
		{
			get { return this.combatant; }
			set { this.combatant = value; }
		}
	}
}
