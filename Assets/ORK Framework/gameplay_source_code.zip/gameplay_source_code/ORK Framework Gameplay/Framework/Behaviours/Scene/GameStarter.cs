
using ORKFramework;
using UnityEngine;
using System.Collections;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Scenes/ORK Game Starter")]
	public class GameStarter : MonoBehaviour
	{
		public bool useAssetBundle = false;

		public ORKProjectAsset project;

		public AssetBundleSimple assetBundle = new AssetBundleSimple();


		// call main menu
		public bool callMainMenu = false;

		public float callAfter = 0;


		// start game
		public bool startGame = false;

		protected virtual void Awake()
		{
			if(!ORK.Initialized)
			{
				ORKProjectAsset projectAsset = this.Project;

				if(projectAsset != null)
				{
					ORK.Initialize(projectAsset);
				}
				else
				{
					Debug.LogError("ORK Project Asset not found!");
				}

				if(!ORK.Game.Running)
				{
					if(this.callMainMenu)
					{
						this.StartCoroutine(this.CallMainMenu());
					}
					else if(this.startGame)
					{
						ORK.Game.NewGame(false);
					}
				}
			}
		}

		protected virtual IEnumerator CallMainMenu()
		{
			if(this.callAfter > 0)
			{
				yield return new WaitForSeconds(this.callAfter);
			}
			ORK.MainMenu.menu.Show();
		}

		protected virtual ORKProjectAsset Project
		{
			get
			{
				if(this.useAssetBundle)
				{
					return this.assetBundle.GetAsset<ORKProjectAsset>();
				}
				else
				{
					return this.project;
				}
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "GameStarter.psd");
		}
	}
}
