
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Scenes/Camera Event")]
	public class CameraEvent : MonoBehaviour
	{
		// camera
		public bool mainCamera = true;

		public bool cameraTag = false;

		public string cameraName = "";

		public bool inBlockedControls = true;


		// camera placement
		public bool onObject = false;

		public GameObject placementObject;

		public float foV = 40;

		public bool lookAt = false;

		[ORKEditorInfo(ORKDataType.CameraPosition)]
		public int camPosID = 0;

		public bool resetPosition = false;


		// target object
		public bool useEventObject = false;

		public bool updatePosition = false;


		// interpolation
		public bool interpolate = false;

		public EaseType easeType = EaseType.Linear;

		public float time = 1;


		// ingame
		protected bool eventActive = false;

		protected Camera foundCamera;

		protected CameraPosition cameraPosition;

		protected CameraEventMover mover;


		// initial position
		protected Vector3 initPos = Vector3.zero;

		protected Quaternion initRot = Quaternion.identity;

		protected float initFoV = 40;


		/*
		============================================================================
		Camera functions
		============================================================================
		*/
		protected virtual Camera GetCamera()
		{
			if(this.foundCamera == null)
			{
				if(this.mainCamera)
				{
					this.foundCamera = ORK.Game.Camera;
				}
				else
				{
					Camera[] cams = Camera.allCameras;
					for(int i = 0; i < cams.Length; i++)
					{
						if((this.cameraTag && cams[i].tag == this.cameraName) ||
							(!this.cameraTag && cams[i].name == this.cameraName))
						{
							this.foundCamera = cams[i];
							break;
						}
					}
				}
			}
			return this.foundCamera;
		}

		protected virtual void UseCamPos()
		{
			Camera cam = this.GetCamera();

			if(cam != null)
			{
				if(this.onObject)
				{
					if(this.placementObject != null)
					{
						cam.transform.SetPositionAndRotation(
							this.placementObject.transform.position,
							this.placementObject.transform.rotation);
						cam.fieldOfView = this.foV;

						if(this.lookAt && ORK.Game.ActiveGroup.Leader != null &&
							ORK.Game.ActiveGroup.Leader.GameObject != null)
						{
							cam.transform.LookAt(
								ORK.Game.ActiveGroup.Leader.GameObject.transform);
						}
					}
				}
				else
				{
					if(this.cameraPosition == null)
					{
						this.cameraPosition = ORK.CameraPositions.Get(this.camPosID);
					}
					if(this.useEventObject)
					{
						this.cameraPosition.Use(cam.transform, this.transform);
					}
					else if(ORK.Game.ActiveGroup.Leader != null &&
						ORK.Game.ActiveGroup.Leader.GameObject != null)
					{
						this.cameraPosition.Use(cam.transform,
							ORK.Game.ActiveGroup.Leader.GameObject.transform);
					}
				}
			}
		}

		protected virtual void Update()
		{
			if(this.eventActive && this.updatePosition &&
				(this.inBlockedControls || !ORK.Control.Blocked))
			{
				this.UseCamPos();
			}
		}


		/*
		============================================================================
		Event functions
		============================================================================
		*/
		public virtual void StartEvent()
		{
			if(!this.eventActive)
			{
				ORK.Control.SetBlockCamera(1, true);
				this.eventActive = true;

				Camera cam = this.GetCamera();

				if(cam != null)
				{
					if(this.resetPosition)
					{
						this.initPos = cam.transform.position;
						this.initRot = cam.transform.rotation;
						this.initFoV = cam.fieldOfView;
					}

					if(!this.updatePosition)
					{
						if(this.interpolate && this.time > 0)
						{
							this.mover = ComponentHelper.Get<CameraEventMover>(this.gameObject);
							if(this.mover != null)
							{
								// object position
								if(this.onObject)
								{
									if(this.placementObject != null)
									{
										this.mover.SetTargetData(
											this.placementObject.transform.position,
											this.placementObject.transform.rotation, this.foV,
											cam.transform, this.easeType, this.time);
									}
								}
								// camera position
								else
								{
									if(this.useEventObject)
									{
										this.mover.SetTargetData(
											ORK.CameraPositions.Get(this.camPosID), cam.transform,
											this.transform, this.easeType, this.time);
									}
									else if(ORK.Game.ActiveGroup.Leader != null &&
										ORK.Game.ActiveGroup.Leader.GameObject != null)
									{
										this.mover.SetTargetData(
											ORK.CameraPositions.Get(this.camPosID), cam.transform,
											ORK.Game.ActiveGroup.Leader.GameObject.transform, this.easeType, this.time);
									}
								}
							}
							else
							{
								this.UseCamPos();
							}
						}
						else
						{
							this.UseCamPos();
						}
					}
				}
			}
		}

		public virtual void EndEvent()
		{
			if(this.eventActive)
			{
				if(this.mover != null)
				{
					this.mover.Stop();
				}

				if(this.resetPosition)
				{
					Camera cam = this.GetCamera();

					if(cam != null)
					{
						cam.transform.SetPositionAndRotation(this.initPos, this.initRot);
						cam.fieldOfView = this.initFoV;
					}
				}

				ORK.Control.SetBlockCamera(-1, true);
				this.eventActive = false;
			}
		}

		protected virtual void OnDestroy()
		{
			if(this.eventActive)
			{
				ORK.Control.SetBlockCamera(-1, true);
				this.eventActive = false;
				ORK.Control.RemoveCameraEvent(this);
			}
		}


		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter(Collider other)
		{
			if(other.gameObject == ORK.Game.GetPlayer() &&
				(this.inBlockedControls || !ORK.Control.Blocked))
			{
				ORK.Control.AddCameraEvent(this);
			}
		}

		protected virtual void OnTriggerExit(Collider other)
		{
			if(other.gameObject == ORK.Game.GetPlayer() &&
				(this.inBlockedControls || !ORK.Control.Blocked))
			{
				ORK.Control.RemoveCameraEvent(this);
			}
		}


		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter2D(Collider2D other)
		{
			if(other.gameObject == ORK.Game.GetPlayer() &&
				(this.inBlockedControls || !ORK.Control.Blocked))
			{
				ORK.Control.AddCameraEvent(this);
			}
		}

		protected virtual void OnTriggerExit2D(Collider2D other)
		{
			if(other.gameObject == ORK.Game.GetPlayer() &&
				(this.inBlockedControls || !ORK.Control.Blocked))
			{
				ORK.Control.RemoveCameraEvent(this);
			}
		}


		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "CameraEvent.psd");
		}
	}
}
