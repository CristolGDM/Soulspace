
using UnityEngine;

namespace ORKFramework
{
	public class AttackAttributesSettings : BaseLanguageSettings<AttackAttributeSetting>
	{
		public AttackAttributesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "attackAttributes"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.AttackAttributes; }
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public AttackSubAttribute Get(int index, int index2)
		{
			AttackAttributeSetting list = this.Get(index);
			if(list != null)
			{
				if(index2 >= 0 && index2 < list.attribute.Length)
				{
					return list.attribute[index2];
				}
				else if(list.attribute.Length > 0)
				{
					return list.attribute[0];
				}
			}
			return null;
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string GetName(int index, int index2)
		{
			AttackAttributeSetting list = this.Get(index);
			if(list != null)
			{
				if(index2 >= 0 && index2 < list.attribute.Length)
				{
					return list.attribute[index2].GetName();
				}
				else
				{
					return "AttackAttribute " + index + ", " + index2 + " not found";
				}
			}
			else
			{
				return "AttackAttributes " + index + " not found";
			}
		}

		public string[] GetNames(int index, bool addIndex)
		{
			string[] names = new string[0];
			AttackAttributeSetting list = this.Get(index);
			if(list != null)
			{
				names = new string[list.attribute.Length];
				for(int i = 0; i < names.Length; i++)
				{
					if(addIndex)
					{
						names[i] = i + ": " + this.GetName(index, i);
					}
					else
					{
						names[i] = this.GetName(index, i);
					}
				}
			}
			return names;
		}

		public string GetShortName(int index, int index2)
		{
			AttackAttributeSetting list = this.Get(index);
			if(list != null)
			{
				if(index2 >= 0 && index2 < list.attribute.Length)
				{
					return list.attribute[index2].GetShortName();
				}
				else
				{
					return "AttackAttribute " + index + ", " + index2 + " not found";
				}
			}
			else
			{
				return "AttackAttributes " + index + " not found";
			}
		}

		public int AttributeCount(int index)
		{
			AttackAttributeSetting list = this.Get(index);
			if(list != null)
			{
				return list.attribute.Length;
			}
			else
			{
				return 0;
			}
		}

		public string GetDescription(int index, int index2)
		{
			AttackAttributeSetting list = this.Get(index);
			if(list != null && index2 >= 0 && index2 < list.attribute.Length)
			{
				return list.attribute[index2].GetDescription();
			}
			else
			{
				return "AttackAttribute " + index + ", " + index2 + " not found";
			}
		}

		public Texture GetIcon(int index, int index2)
		{
			Texture tex = null;
			AttackAttributeSetting list = this.Get(index);
			if(list != null && index2 >= 0 && index2 < list.attribute.Length)
			{
				int l = ORK.Game.Language;
				tex = list.attribute[index2].languageInfo[l].GetIcon();
				if(tex == null && l != 0)
				{
					tex = list.attribute[index2].languageInfo[0].GetIcon();
				}
			}
			return tex;
		}

		public GUIContent GetContent(int index, int index2)
		{
			return new GUIContent(this.GetName(index, index2), this.GetIcon(index, index2));
		}
	}
}

