
using UnityEngine;
using ORKFramework.Animations;
using System.Collections.Generic;

namespace ORKFramework
{
	public class SoundTypesSettings : BaseSettings
	{
		[ORKEditorInfo(hide=true)]
		public SoundType[] data = new SoundType[] {
			new SoundType("Damage"), 
			new SoundType("Evade"), 
			new SoundType("Death"), 
			new SoundType("Use 1"), 
			new SoundType("Use 2"), 
			new SoundType("Use 3"), 
			new SoundType("Attack 1"), 
			new SoundType("Attack 2"), 
			new SoundType("Attack 3")
		};
		
		public SoundTypesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}
		
		public override void SetRealIDs()
		{
			this.SetRealIDs(this.data);
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "soundTypes"; }
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].name;
			}
			else
			{
				return "SoundType(" + index + ") not found";
			}
		}

		public override string[] GetNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i=0; i<names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = i + ": " + this.data[i].name;
				}
				else
				{
					names[i] = this.data[i].name;
				}
			}
			return names;
		}
		
		public override int Count
		{
			get{ return this.data.Length;}
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			ArrayHelper.Add(ref this.data, new SoundType("New"));
			DataHelper.Added(ORKDataType.SoundType);
			return this.data.Length - 1;
		}
		
		public override int Copy(int index)
		{
			ArrayHelper.Add(ref this.data, this.GetCopy(index));
			DataHelper.Added(ORKDataType.SoundType);
			return this.data.Length - 1;
		}
		
		public SoundType GetCopy(int index)
		{
			SoundType c = new SoundType();
			if(index >= 0 && index < this.data.Length)
			{
				c.SetData(this.data[index].GetData());
			}
			return c;
		}
		
		public override void Remove(int index)
		{
			ArrayHelper.RemoveAt(ref this.data, index);
			DataHelper.Removed(ORKDataType.SoundType, index);
		}
		
		public SoundType Get(int index)
		{
			if(index >= 0 && index < this.Count)
			{
				return this.data[index];
			}
			else
			{
				return this.data[0];
			}
		}
		
		public override void Move(int index, bool down)
		{
			if(down)
			{
				ArrayHelper.MoveDown(ref this.data, index);
			}
			else
			{
				ArrayHelper.MoveUp(ref this.data, index);
			}
			DataHelper.Moved(ORKDataType.SoundType, down, index);
		}
	}
}
