
using UnityEngine;

namespace ORKFramework
{
	public class StatusEffectsSettings : BaseLanguageSettings<StatusEffectSetting>
	{
		public StatusEffectsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}

		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "statusEffects"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.StatusEffect; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.StatusEffectTypes.GetName(this.data[i].typeID) +
						"/" + i + ": " + this.data[i].GetName();
				}
				else
				{
					names[i] = this.data[i].GetName();
				}
			}
			return names;
		}


		/*
		============================================================================
		Auto apply/remove functions
		============================================================================
		*/
		public void CheckAuto(Combatant c)
		{
			for(int i = 0; i < this.data.Length; i++)
			{
				this.data[i].CheckAuto(c);
			}
		}

		public void RegisterStatusChanges(Combatant c)
		{
			for(int i = 0; i < this.data.Length; i++)
			{
				if(this.data[i].autoApply)
				{
					for(int j = 0; j < this.data[i].applyRequirement.Length; j++)
					{
						this.data[i].applyRequirement[j].RegisterStatusChanges(c, this.data[i]);
					}
				}
				if(this.data[i].autoRemove)
				{
					for(int j = 0; j < this.data[i].removeRequirement.Length; j++)
					{
						this.data[i].removeRequirement[j].RegisterStatusChanges(c, this.data[i]);
					}
				}
			}
		}

		public void UnregisterStatusChanges(Combatant c)
		{
			for(int i = 0; i < this.data.Length; i++)
			{
				if(this.data[i].autoApply)
				{
					for(int j = 0; j < this.data[i].applyRequirement.Length; j++)
					{
						this.data[i].applyRequirement[j].UnregisterStatusChanges(c, this.data[i]);
					}
				}
				if(this.data[i].autoRemove)
				{
					for(int j = 0; j < this.data[i].removeRequirement.Length; j++)
					{
						this.data[i].removeRequirement[j].UnregisterStatusChanges(c, this.data[i]);
					}
				}
			}
		}
	}
}
