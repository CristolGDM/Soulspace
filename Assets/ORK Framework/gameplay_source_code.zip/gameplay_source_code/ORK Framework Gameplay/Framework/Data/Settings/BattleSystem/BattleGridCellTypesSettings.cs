﻿
using UnityEngine;

namespace ORKFramework
{
	public class BattleGridCellTypesSettings : BaseLanguageSettings<BattleGridCellType>
	{
		public BattleGridCellTypesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "battleGridCellTypes"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.BattleGridCellType; }
		}
	}
}
