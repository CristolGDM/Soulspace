﻿
using UnityEngine;
using ORKFramework.UI;
using ORKFramework.Menu;

namespace ORKFramework
{
	public class TextDisplaySettings : BaseSettings
	{
		// combatant choice
		[ORKEditorInfo("Default Combatant Choice Layout", "Define the default layout for combatant choices " +
			"in battle menus or combatant selections.\n" +
			"You can either display  each combatant as a simple button with name and icon, " +
			"or use HUD elements to create more complex choices with status information.\n" +
			"The default layout can be overridden by each battle menu.", "",
			endFoldout=true)]
		public CombatantChoiceLayout combatantChoice = new CombatantChoiceLayout();


		// combatant list displays
		[ORKEditorInfo("Combatant Name List", "Define how the name of multiple combatants will be displayed.\n" +
			"This is e.g. used in console texts when displaying a list of targets or when using the " +
			"'#equipped' text code for abilities to display the names of combatants that know an ability.", "",
			endFoldout=true)]
		public CombatantNamesDisplay combatantNameList = new CombatantNamesDisplay();


		// use costs display
		[ORKEditorInfo("Use Cost Display", "Define how an ability's use costs will be displayed in menus.", "",
			endFoldout=true)]
		public UseCostDisplay useCostDisplay = new UseCostDisplay();


		// bonus display
		[ORKEditorInfo("Bonus Display", "Define how bonuses will be displayed when " +
			"using the '%bonus' text code in the descriptions of status effects, weapons, armors, " +
			"passive abilities, classes and combatants.", "",
			endFoldout=true)]
		public BonusDisplay bonusDisplay = new BonusDisplay();


		// target info display
		[ORKEditorInfo("Target Information Display", "Define how status change information on the " +
			"user and targets of an ability or item will be displayed.\n" +
			"This is used by the target information dialogue and target confirmation dialogue " +
			"and can optionally be overridden there ('Battle System > Battle Settings').", "",
			endFoldout=true)]
		public TargetInformationDisplay targetInfoDisplay = new TargetInformationDisplay();

		public TextDisplaySettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetRealIDs()
		{

		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "textDisplaySettings"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}
	}
}
