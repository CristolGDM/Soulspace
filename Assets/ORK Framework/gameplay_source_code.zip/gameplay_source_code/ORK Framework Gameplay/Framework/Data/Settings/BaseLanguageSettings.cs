
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public abstract class BaseLanguageSettings : BaseSettings
	{
		public abstract IContentSimple GetContentInformation(int index);

		public abstract IContentSimple GetTypeContentInformation(int index);

		public abstract string GetShortName(int index);

		public abstract string GetDescription(int index);

		public abstract Texture GetIcon(int index);

		public abstract GUIContent GetContent(int index);
	}

	public abstract class BaseLanguageSettings<T> : BaseLanguageSettings where T : BaseLanguageData, new()
	{
		[ORKEditorInfo(hide=true)]
		public T[] data = new T[0];

		public virtual ORKDataType DataType
		{
			get;
		}

		public override void SetRealIDs()
		{
			this.SetRealIDs(this.data);
		}

		public override void LoadProject(ORKProjectAsset project)
		{
			this.SetData(project.GetData(this.FILENAME).ToDataObject());

			if(this.data.Length == 0)
			{
				T newData = new T();
				newData.SetLanguageName("Default");
				this.data = new T[] { newData };
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			T newData = new T();
			newData.SetLanguageName("New");
			ArrayHelper.Add(ref this.data, newData);
			DataHelper.Added(this.DataType);
			return this.data.Length - 1;
		}

		public override int Copy(int index)
		{
			T newData = this.GetCopy(index);
			ArrayHelper.Add(ref this.data, newData);
			DataHelper.Added(this.DataType);
			return this.data.Length - 1;
		}

		public virtual T GetCopy(int index)
		{
			T tmp = new T();
			if(index >= 0 &&
				index < this.data.Length)
			{
				tmp.SetData(this.data[index].GetData());
				tmp.RealID = index;
			}
			return tmp;
		}

		public override void Remove(int index)
		{
			ArrayHelper.RemoveAt(ref this.data, index);
			DataHelper.Removed(this.DataType, index);
		}

		public virtual T Get(int index)
		{
			if(index >= 0 &&
				index < this.Count)
			{
				return this.data[index];
			}
			else if(this.data.Length > 0)
			{
				return this.data[0];
			}
			else
			{
				return null;
			}
		}

		public override IContentSimple GetContentInformation(int index)
		{
			return this.Get(index);
		}

		public override IContentSimple GetTypeContentInformation(int index)
		{
			IContent content = this.Get(index) as IContent;
			if(content != null)
			{
				return content.GetTypeContent();
			}
			return null;
		}

		public override void Move(int index, bool down)
		{
			if(down)
			{
				ArrayHelper.MoveDown(ref this.data, index);
			}
			else
			{
				ArrayHelper.MoveUp(ref this.data, index);
			}
			DataHelper.Moved(this.DataType, down, index);
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			if(index >= 0 &&
				index < this.data.Length)
			{
				return this.data[index].GetName();
			}
			else
			{
				return this.DataType + " " + index + " not found";
			}
		}

		public override string[] GetNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < this.data.Length; i++)
			{
				if(addIndex)
				{
					names[i] = i + ": " + this.data[i].GetName();
				}
				else
				{
					names[i] = this.data[i].GetName();
				}
			}
			return names;
		}

		public override string GetShortName(int index)
		{
			if(index >= 0 &&
				index < this.data.Length)
			{
				return this.data[index].GetShortName();
			}
			else
			{
				return this.DataType + " " + index + " not found";
			}
		}

		public override int Count
		{
			get { return this.data.Length; }
		}

		/// <summary>
		/// Gets the description.
		/// </summary>
		/// <returns>
		/// The description.
		/// </returns>
		/// <param name='index'>
		/// The data index.
		/// </param>
		public override string GetDescription(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].GetDescription();
			}
			else
			{
				return this.DataType + " " + index + " not found";
			}
		}

		/// <summary>
		/// Gets the icon of a data.
		/// </summary>
		/// <returns>
		/// The icon.
		/// </returns>
		/// <param name='index'>
		/// The data index.
		/// </param>
		public override Texture GetIcon(int index)
		{
			Texture tex = null;

			if(index >= 0 && index < this.data.Length)
			{
				int language = ORK.Game.Language;
				tex = this.data[index].languageInfo[language].GetIcon();
				if(tex == null && language != 0)
				{
					tex = this.data[index].languageInfo[0].GetIcon();
				}
			}
			return tex;
		}

		/// <summary>
		/// Gets the GUIContent of a data.
		/// </summary>
		/// <returns>
		/// The GUIContent.
		/// </returns>
		/// <param name='index'>
		/// The data index.
		/// </param>
		public override GUIContent GetContent(int index)
		{
			return new GUIContent(this.GetName(index), this.GetIcon(index));
		}
	}
}
