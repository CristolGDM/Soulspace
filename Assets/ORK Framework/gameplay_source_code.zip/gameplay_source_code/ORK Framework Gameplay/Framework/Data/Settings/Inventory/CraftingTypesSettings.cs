
using UnityEngine;

namespace ORKFramework
{
	public class CraftingTypesSettings : BaseLanguageSettings<CraftingType>
	{
		public CraftingTypesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "craftingTypes"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.CraftingType; }
		}
	}
}
