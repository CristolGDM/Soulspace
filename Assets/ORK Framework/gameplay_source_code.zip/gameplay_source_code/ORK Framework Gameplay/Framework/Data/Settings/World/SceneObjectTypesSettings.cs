
using UnityEngine;

namespace ORKFramework
{
	public class SceneObjectTypesSettings : BaseLanguageSettings<SceneObjectType>
	{
		public SceneObjectTypesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "sceneObjectTypes"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.SceneObjectType; }
		}
	}
}

