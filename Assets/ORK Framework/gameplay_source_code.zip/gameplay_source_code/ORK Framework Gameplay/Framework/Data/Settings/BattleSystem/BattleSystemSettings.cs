
using UnityEngine;

namespace ORKFramework
{
	public class BattleSystemSettings : BaseSettings
	{
		public BattleGridSettings gridSettings = new BattleGridSettings();

		public BattleGridHighlightSettings gridHighlights = new BattleGridHighlightSettings();

		public FieldMode fieldMode = new FieldMode();

		public TurnBasedBattle turnBased = new TurnBasedBattle();

		public ActiveTimeBattle activeTime = new ActiveTimeBattle();

		public RealTimeBattle realTime = new RealTimeBattle();

		public PhaseBattle phase = new PhaseBattle();

		public BattleSystemSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetRealIDs()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(!data.Contains<DataObject>("gridHighlights"))
			{
				this.gridHighlights.SetData(data.GetFile("gridSettings"));
			}
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "battleSystem"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}


		/*
		============================================================================
		Event functions
		============================================================================
		*/
		public ORKBattleStartEvent GetStartEvent(BattleSystemType type)
		{
			if(BattleSystemType.TurnBased == type)
			{
				return this.turnBased.startEvent;
			}
			else if(BattleSystemType.ActiveTime == type)
			{
				return this.activeTime.startEvent;
			}
			else if(BattleSystemType.RealTime == type)
			{
				return this.realTime.startEvent;
			}
			else if(BattleSystemType.Phase == type)
			{
				return this.phase.startEvent;
			}
			return null;
		}

		public ORKBattleEndEvent GetVictoryEvent(BattleSystemType type)
		{
			if(BattleSystemType.TurnBased == type)
			{
				return this.turnBased.victoryEvent;
			}
			else if(BattleSystemType.ActiveTime == type)
			{
				return this.activeTime.victoryEvent;
			}
			else if(BattleSystemType.RealTime == type)
			{
				return this.realTime.victoryEvent;
			}
			else if(BattleSystemType.Phase == type)
			{
				return this.phase.victoryEvent;
			}
			return null;
		}

		public ORKBattleEndEvent GetEscapeEvent(BattleSystemType type)
		{
			if(BattleSystemType.TurnBased == type)
			{
				return this.turnBased.escapeEvent;
			}
			else if(BattleSystemType.ActiveTime == type)
			{
				return this.activeTime.escapeEvent;
			}
			else if(BattleSystemType.RealTime == type)
			{
				return this.realTime.escapeEvent;
			}
			else if(BattleSystemType.Phase == type)
			{
				return this.phase.escapeEvent;
			}
			return null;
		}

		public ORKBattleEndEvent GetDefeatEvent(BattleSystemType type)
		{
			if(BattleSystemType.TurnBased == type)
			{
				return this.turnBased.defeatEvent;
			}
			else if(BattleSystemType.ActiveTime == type)
			{
				return this.activeTime.defeatEvent;
			}
			else if(BattleSystemType.RealTime == type)
			{
				return this.realTime.defeatEvent;
			}
			else if(BattleSystemType.Phase == type)
			{
				return this.phase.defeatEvent;
			}
			return null;
		}

		public ORKBattleEndEvent GetLeaveArenaEvent(BattleSystemType type)
		{
			if(BattleSystemType.TurnBased == type)
			{
				return this.turnBased.leaveArenaEvent;
			}
			else if(BattleSystemType.ActiveTime == type)
			{
				return this.activeTime.leaveArenaEvent;
			}
			else if(BattleSystemType.RealTime == type)
			{
				return this.realTime.leaveArenaEvent;
			}
			else if(BattleSystemType.Phase == type)
			{
				return this.phase.leaveArenaEvent;
			}
			return null;
		}


		/*
		============================================================================
		Add, remove callbacks
		============================================================================
		*/
		private void SetBonusType(int index, StatusValueType type, ref BattleBonuses bonus)
		{
			this.SetBonusType(index, type, ref bonus.startSetter);
			this.SetBonusType(index, type, ref bonus.turnSetter);
			this.SetBonusType(index, type, ref bonus.endSetter);
			this.SetBonusType(index, type, ref bonus.reviveSetter);
		}

		private void SetBonusType(int index, StatusValueType type, ref StatusValueSetter[] bonus)
		{
			for(int i = 0; i < bonus.Length; i++)
			{
				if(bonus[i].statusID == index)
				{
					ArrayHelper.RemoveAt(ref bonus, i);
					i--;
				}
			}
		}

		public void SetStatusValueType(int index, StatusValueType type)
		{
			if(StatusValueType.Consumable != type)
			{
				this.SetBonusType(index, type, ref this.turnBased.bonuses);
				this.SetBonusType(index, type, ref this.activeTime.bonuses);
				this.SetBonusType(index, type, ref this.realTime.bonuses);
			}
		}
	}
}
