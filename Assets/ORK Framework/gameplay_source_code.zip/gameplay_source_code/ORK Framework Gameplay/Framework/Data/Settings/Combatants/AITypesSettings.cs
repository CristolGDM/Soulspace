﻿
using UnityEngine;
using ORKFramework.AI;
using System.Collections.Generic;

namespace ORKFramework
{
	public class AITypesSettings : BaseLanguageSettings<AIType>
	{
		public AITypesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "aiTypes"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.AIType; }
		}
	}
}
