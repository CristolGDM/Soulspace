﻿
using UnityEngine;
using ORKFramework.UI;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ShortcutSettings : BaseSettings
	{
		[ORKEditorHelp("Shortcut List Count", "The number of available shortcut lists of a combatant or class.\n" +
			"Each list consists of a variable amount of slots (index based). " +
			"Lists can be switched using the event system.\n" +
			"Combatants and classes can optionally override the shortcut list count.", "")]
		[ORKEditorInfo("Shortcut Settings", "Shortcuts are used to quickly use items or abilities, or equip weapons and armors.\n" +
			"They can be used via control maps or 'Combatant' type HUDs with shortcut elements.\n" +
			"Shortcuts are organized in lists, each list consists of a variable amount of slots (index based). " +
			"Only the currently active list can be used - switching between lists can be done using the event system, " +
			"e.g. with a global event called when pressing an input key.\n" +
			"Combatants can optionally use their own shortcut lists, disabling the class shortcut lists.", "")]
		[ORKEditorLimit(0, false)]
		public int shortcutListCount = 1;

		[ORKEditorHelp("Keep Unavailable", "Keep shortcuts that are currently unavailable.\n" +
			"A shortcut becomes unavailable if the underlying item or action is no longer available, " +
			"e.g. after equipping a weapon or using the last item of that kind.\n" +
			"If disabled, these shortcuts will be overridden or removed.", "")]
		public bool keepUnavailableShortcuts = true;

		[ORKEditorHelp("2nd Call Deactivate", "An active shortcut (i.e. during target selection) is deactivated when used a 2nd time.\n" +
			"This is possible for control maps and click use in shortcut HUDs.", "")]
		public bool deactivateOn2ndCall = false;

		[ORKEditorHelp("HUD Check Timeout (s)", "The time in seconds between checking a shortcut's useable state in HUDs.\n" +
			"The check includes searching for available targets, which can have an impact on performance " +
			"(especially during grid battles) when used each frame (i.e. a timeout of 0)", "")]
		[ORKEditorInfo(endFoldout=true, separator=true)]
		[ORKEditorLimit(0.0f, false)]
		public float hudCheckTimeout = 0.1f;


		// default shortcut assignments
		[ORKEditorInfo("Default Shortcut Assignments", "Shortcuts can be either bound to the combatant or the combatant's class " +
			"(i.e. the shortcuts are changed when changing the class)." +
			"The default shortcut assignments are set up when a combatant or class is first used by a combatant. " +
			"Default shortcuts are used by all combatants/classes, each combatant or class can " +
			"add to or replace the default shortcuts.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Shortcut", "Adds a default shortcut.", "",
			"Remove", "Removes this shortcut.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Shortcut Assignment", "The selected shortcut slot will be assigned with the defined shortcut.", ""
		})]
		public ShortcutSlotAssignment[] defaultShortcut = new ShortcutSlotAssignment[0];


		// auto add shortcuts
		[ORKEditorInfo("Default Auto Add Slots", "Shortcuts can be added automatically to shortcut slots upon getting them.\n" +
			"This is used when a combatant learns a new ability or gets a new item, equipment or currency.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Auto Add Slots", "Adds default auto add slots.", "",
			"Remove", "Removes these auto add slots.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Auto Add Slots", "Define the slot range and used shortcuts that will be added automatically.", ""
		})]
		public AutoShortcutSlots[] autoAddShortcuts = new AutoShortcutSlots[0];


		// auto arrange shortcuts
		[ORKEditorInfo("Default Auto Arrange Slots", "Shortcuts can be arranged automatically to fill empty slots when removing shortcuts.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Auto Arrange Slots", "Adds default auto arrange slots.", "",
			"Remove", "Removes these auto arrange slots.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Auto Arrange Slots", "Define the slot range and used shortcuts that will be arranged automatically.", ""
		})]
		public AutoShortcutSlots[] autoArrangeShortcuts = new AutoShortcutSlots[0];


		// default slot layouts
		[ORKEditorInfo("Default Slot Layouts", "Define the default layouts for displaying shortcut slots.", "",
			endFoldout=true)]
		public ShortcutSlotLayout defaultSlotLayouts = new ShortcutSlotLayout();

		public ShortcutSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetRealIDs()
		{

		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "shortcutSettings"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}
	}
}
