
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TeleportsSettings : BaseLanguageSettings<Teleport>
	{
		public TeleportsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "teleports"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.Teleport; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.AreaTypes.GetName(this.data[i].typeID) +
						"/" + i + ": " + this.data[i].GetName();
				}
				else
				{
					names[i] = this.data[i].GetName();
				}
			}
			return names;
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public List<int> GetTeleportIDs(bool ignoreConditions)
		{
			List<int> ids = new List<int>();
			for(int i = 0; i < this.data.Length; i++)
			{
				if(ignoreConditions || this.data[i].Available())
				{
					ids.Add(i);
				}
			}
			return ids;
		}

		public List<ChoiceContent> GetChoicesForIDs(List<int> ids, ContentLayout layout)
		{
			List<ChoiceContent> cc = new List<ChoiceContent>();
			for(int i = 0; i < ids.Count; i++)
			{
				cc.Add(layout.GetChoiceContent(this.data[ids[i]]));
			}
			return cc;
		}
	}
}

