
using System.Collections.Generic;

namespace ORKFramework
{
	public class TurnSorter : IComparer<Combatant>
	{
		private bool inverse = false;

		private bool leadersFirst = false;

		public TurnSorter(bool inverse)
		{
			this.inverse = inverse;
		}

		public TurnSorter(bool inverse, bool leadersFirst)
		{
			this.inverse = inverse;
			this.leadersFirst = leadersFirst;
		}

		public int Compare(Combatant x, Combatant y)
		{
			// leaders first
			if(this.leadersFirst)
			{
				if(x.IsLeader &&
					!y.IsLeader)
				{
					return this.inverse ? 1 : -1;
				}
				else if(!x.IsLeader &&
					y.IsLeader)
				{
					return this.inverse ? -1 : 1;
				}
			}

			// regular sort
			if(x.Battle.TurnValue < y.Battle.TurnValue)
			{
				return this.inverse ? -1 : 1;
			}
			else if(x.Battle.TurnValue > y.Battle.TurnValue)
			{
				return this.inverse ? 1 : -1;
			}
			else
			{
				return 0;
			}
		}
	}

	public class DummyTurnSorter : IComparer<Combatant>
	{
		private bool inverse = false;

		private bool leadersFirst = false;

		public DummyTurnSorter(bool inverse)
		{
			this.inverse = inverse;
		}

		public DummyTurnSorter(bool inverse, bool leadersFirst)
		{
			this.inverse = inverse;
			this.leadersFirst = leadersFirst;
		}

		public int Compare(Combatant x, Combatant y)
		{
			// leaders first
			if(this.leadersFirst)
			{
				if(x.IsLeader &&
					!y.IsLeader)
				{
					return this.inverse ? 1 : -1;
				}
				else if(!x.IsLeader &&
					y.IsLeader)
				{
					return this.inverse ? -1 : 1;
				}
			}

			// regular sort
			if(x.Battle.TurnValueDummy < y.Battle.TurnValueDummy)
			{
				return this.inverse ? -1 : 1;
			}
			else if(x.Battle.TurnValueDummy > y.Battle.TurnValueDummy)
			{
				return this.inverse ? 1 : -1;
			}
			else
			{
				return 0;
			}
		}
	}

	public class GroupLeaderSorter : IComparer<Combatant>
	{
		private bool inverse = false;

		public GroupLeaderSorter(bool inverse)
		{
			this.inverse = inverse;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(x.IsLeader &&
				!y.IsLeader)
			{
				return this.inverse ? 1 : -1;
			}
			else if(!x.IsLeader &&
				y.IsLeader)
			{
				return this.inverse ? -1 : 1;
			}
			return 0;
		}
	}
}
