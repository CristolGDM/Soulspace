﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class AddContentSorter : BaseData
	{
		[ORKEditorHelp("Sort By", "Select how the data will be sorted:\n" +
			"- None: The data isn't sorted and will be listet as it appears.\n" +
			"- Name: The data is sorted by name (e.g. item name, ability name).\n" +
			"- ID: The data is sorted by ID (i.e. the index of the data).\n" +
			"- Type: The data is sorted by type (e.g. item type, ability type).\n" +
			"- Type Name: The data is first sorted by type, then by name.\n" +
			"- Type ID: The data is first sorted by type, then by ID.\n" +
			"- Added: The data is sorted by the time it was added.", "")]
		public AddContentSorting sorting = AddContentSorting.Name;

		[ORKEditorHelp("Invert Order", "The data is sorted in inverted order.", "")]
		public bool invert = false;

		public AddContentSorter()
		{

		}


		/*
		============================================================================
		Sort functions
		============================================================================
		*/
		public void SortContent(ref List<IContent> list)
		{
			if(AddContentSorting.Name == this.sorting)
			{
				list.Sort(new NameContentSorter(this.invert));
			}
			else if(AddContentSorting.ID == this.sorting)
			{
				list.Sort(new IDContentSorter(this.invert));
			}
			else if(AddContentSorting.Type == this.sorting)
			{
				list.Sort(new TypeContentSorter(this.invert));
			}
			else if(AddContentSorting.TypeName == this.sorting)
			{
				list.Sort(new TypeNameContentSorter(this.invert));
			}
			else if(AddContentSorting.TypeID == this.sorting)
			{
				list.Sort(new TypeIDContentSorter(this.invert));
			}
		}

		public void Sort<T>(ref List<T> list) where T : IContent
		{
			if(AddContentSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else if(AddContentSorting.Added == this.sorting)
			{
				List<ITimestamp> tmpList = new List<ITimestamp>(list.Count);
				for(int i = 0; i < list.Count; i++)
				{
					tmpList.Add((ITimestamp)list[i]);
				}

				tmpList.Sort(new TimestampSorter(this.invert));

				list.Clear();
				for(int i = 0; i < tmpList.Count; i++)
				{
					list.Add((T)tmpList[i]);
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				for(int i = 0; i < list.Count; i++)
				{
					tmpList.Add((IContent)list[i]);
				}

				this.SortContent(ref tmpList);

				list.Clear();
				for(int i = 0; i < tmpList.Count; i++)
				{
					list.Add((T)tmpList[i]);
				}
			}
		}
	}
}
