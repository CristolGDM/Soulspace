﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class SortIDDataType
	{
		public ChoiceContent content;

		public int id;

		public ORKDataType type;

		public SortIDDataType(ChoiceContent content, int id, ORKDataType type)
		{
			this.content = content;
			this.id = id;
			this.type = type;
		}
	}
}
