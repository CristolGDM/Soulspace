﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantPositionDistanceSorter : IComparer<Combatant>
	{
		private Vector3 position;

		private bool ignoreHeightDistance = false;

		private bool inverse = false;

		public CombatantPositionDistanceSorter(Vector3 position, bool ignoreHeightDistance, bool inverse)
		{
			this.position = position;
			this.ignoreHeightDistance = ignoreHeightDistance;
			this.inverse = inverse;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(inverse)
			{
				if(x.GameObject == null &&
					y.GameObject == null)
				{
					return 0;
				}
				else if(x.GameObject != null &&
					y.GameObject == null)
				{
					return 1;
				}
				else if(x.GameObject == null &&
					y.GameObject != null)
				{
					return -1;
				}
				else
				{
					return VectorHelper.Distance(this.position, y.GameObject.transform.position, this.ignoreHeightDistance).CompareTo(
						VectorHelper.Distance(this.position, x.GameObject.transform.position, this.ignoreHeightDistance));
				}
			}
			else
			{
				if(x.GameObject == null &&
					y.GameObject == null)
				{
					return 0;
				}
				else if(x.GameObject != null &&
					y.GameObject == null)
				{
					return -1;
				}
				else if(x.GameObject == null &&
					y.GameObject != null)
				{
					return 1;
				}
				else
				{
					return VectorHelper.Distance(this.position, x.GameObject.transform.position, this.ignoreHeightDistance).CompareTo(
						VectorHelper.Distance(this.position, y.GameObject.transform.position, this.ignoreHeightDistance));
				}
			}
		}
	}
}
