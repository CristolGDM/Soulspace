﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GroupGridFormationSorter : IComparer<GroupGridFormationPosition>
	{
		public GroupGridFormationSorter()
		{

		}

		public int Compare(GroupGridFormationPosition x, GroupGridFormationPosition y)
		{
			if(x == null &&
				y == null)
			{
				return 0;
			}
			else if(x != null &&
				y == null)
			{
				return -1;
			}
			else if(x == null &&
				y != null)
			{
				return 1;
			}
			else
			{
				int compare = y.Settings.priority.CompareTo(x.Settings.priority);

				if(compare == 0)
				{
					if(x.Settings.fromPositions &&
						!y.Settings.fromPositions)
					{
						return -1;
					}
					else if(!x.Settings.fromPositions &&
						y.Settings.fromPositions)
					{
						return 1;
					}
					else
					{
						return x.Index.CompareTo(y.Index);
					}
				}
				else
				{
					return compare;
				}
			}
		}
	}
}
