﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class InventoryAccessHandler
	{
		public InventoryAccessHandler()
		{

		}


		/*
		============================================================================
		Crafting recipe functions
		============================================================================
		*/
		/// <summary>
		/// Creates the outcome of a crafting recipe.
		/// </summary>
		/// <param name="combatant">The combatant used to craft.</param>
		/// <param name="recipeID">The ID/index of the crafting recipe.</param>
		/// <param name="notify">A callback function taking a bool parameter (<c>true</c> if crafting was successful).</param>
		public virtual void UseCraftingRecipe(Combatant combatant, int recipeID, NotifyBool notify)
		{
			ORK.CraftingRecipes.Get(recipeID).CreateItem(combatant, notify);
		}

		/// <summary>
		/// Adds an item to the crafting list of a combatant.
		/// </summary>
		/// <param name="combatant">The used combatant.</param>
		/// <param name="item">The item that will be added.</param>
		public virtual void AddToCraftingList(Combatant combatant, IShortcut item)
		{
			combatant.Inventory.Crafting.AddToCraftingList(item, true);
		}

		/// <summary>
		/// Removes an item from the crafting list of a combatant.
		/// </summary>
		/// <param name="combatant">The used combatant.</param>
		/// <param name="item">The item that will be removed.</param>
		public virtual void RemoveFromCraftingList(Combatant combatant, IShortcut item)
		{
			combatant.Inventory.Crafting.RemoveFromCraftingList(item, true);
		}

		/// <summary>
		/// Removes all items in a combatant's crafting list and returns them to the inventory.
		/// </summary>
		/// <param name="combatant">The used combatant.</param>
		public virtual void ClearCraftingList(Combatant combatant)
		{
			combatant.Inventory.Crafting.ClearCraftingList(true);
		}

		/// <summary>
		/// Creates the outcome of a crafting recipe matching the items in the crafting list of a combatant.
		/// </summary>
		/// <param name="combatant">The used combatant.</param>
		/// <param name="creationType">The creation type used (Exact, One, Multi).</param>
		/// <param name="consumeUnused"><c>true</c> if unused items in the crafting list should be consumed.</param>
		/// <param name="onlyKnownRecipes"><c>true</c> if only crafting recipes that are known to the combatant should be used.</param>
		public virtual void CreateFromCraftingList(Combatant combatant, CraftingListCreationType creationType, 
			bool consumeUnused, bool onlyKnownRecipes, Notify finished)
		{
			combatant.Inventory.Crafting.CreateFromCraftingList(combatant,
				creationType, consumeUnused, onlyKnownRecipes, finished);
		}


		/*
		============================================================================
		Inventory functions
		============================================================================
		*/
		/// <summary>
		/// Adds an item to an inventory.
		/// </summary>
		/// <param name="inventory">The inventory that will be used.</param>
		/// <param name="item">The item that will be added.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		/// <param name="markNewContent"><c>true</c> if the item should be marked as new content.</param>
		/// <returns><c>true</c> if the item was added.</returns>
		public virtual bool Add(Inventory inventory, IShortcut item,
			bool showNotification, bool showConsole, bool markNewContent)
		{
			return inventory.Add(item, showNotification, showConsole, markNewContent);
		}

		/// <summary>
		/// Removes an item from an inventory
		/// </summary>
		/// <param name="inventory">The inventory that will be used.</param>
		/// <param name="item">The item that will be removed.</param>
		/// <param name="quantity">The quantity that will be removed.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		public virtual void Remove(Inventory inventory, IShortcut item,
			int quantity, bool showNotification, bool showConsole)
		{
			inventory.Remove(item, quantity, showNotification, showConsole);
		}

		/// <summary>
		/// Drops an item from an inventory into the game world.
		/// </summary>
		/// <param name="inventory">The inventory that will be used.</param>
		/// <param name="item">The item that will be dropped.</param>
		/// <param name="quantity">The quantity that will be dropped.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		public virtual void Drop(Inventory inventory, IShortcut item,
			int quantity, bool showNotification, bool showConsole)
		{
			inventory.Drop(item, quantity, showNotification, showConsole);
		}

		/// <summary>
		/// Sets the amount of money in an inventory.
		/// </summary>
		/// <param name="inventory">The inventory that will be used.</param>
		/// <param name="id">The ID/index of the currency.</param>
		/// <param name="quantity">The quantity the currency will be set to.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		public virtual void SetMoney(Inventory inventory, int id, int quantity, bool showNotification, bool showConsole)
		{
			inventory.SetMoney(id, quantity, showNotification, showConsole);
		}

		/// <summary>
		/// Adds money to an inventory.
		/// </summary>
		/// <param name="inventory">The inventory that will be used.</param>
		/// <param name="id">The ID/index of the currency.</param>
		/// <param name="quantity">The quantity that will be added.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		public virtual void AddMoney(Inventory inventory, int id, int quantity, bool showNotification, bool showConsole)
		{
			inventory.AddMoney(id, quantity, showNotification, showConsole);
		}

		/// <summary>
		/// Removes money from an inventory.
		/// </summary>
		/// <param name="inventory">The inventory that will be used.</param>
		/// <param name="id">The ID/index of the currency.</param>
		/// <param name="quantity">The quantity that will be removed.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		public virtual void SubMoney(Inventory inventory, int id, int quantity, bool showNotification, bool showConsole)
		{
			inventory.SubMoney(id, quantity, showNotification, showConsole);
		}

		/// <summary>
		/// Removes items of an item type from an inventory.
		/// </summary>
		/// <param name="inventory">The inventory that will be used.</param>
		/// <param name="typeID">The ID/index of the item type that will be removed.</param>
		/// <param name="removeSubTypes"><c>true</c> if sub types of the item type should be removed.</param>
		/// <param name="removeMoney"><c>true</c> if money should be removed.</param>
		/// <param name="removeItems"><c>true</c> if items should be removed.</param>
		/// <param name="removeWeapons"><c>true</c> if weapons should be removed.</param>
		/// <param name="removeArmor"><c>true</c> if armors should be removed.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		public virtual void RemoveItemType(Inventory inventory, int typeID, bool removeSubTypes,
			bool removeMoney, bool removeItems, bool removeWeapons, bool removeArmor,
			bool showNotification, bool showConsole)
		{
			inventory.RemoveItemType(typeID, removeSubTypes,
				removeMoney, removeItems, removeWeapons, removeArmor,
				showNotification, showConsole);
		}
	}
}
