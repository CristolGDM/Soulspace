﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantAccessHandler
	{
		public CombatantAccessHandler()
		{

		}


		/*
		============================================================================
		Instance functions
		============================================================================
		*/
		/// <summary>
		/// Creates a new instance of a combatant and initializes it with the combatant's start levels and class.
		/// </summary>
		/// <param name="index">The ID/index of the combatant that will be created.</param>
		/// <param name="group">The group the combatant will join.</param>
		/// <returns>A new combatant instance initialized with the combatant's start levels and class.</returns>
		public virtual Combatant CreateInstance(int index, Group group, bool showNotification, bool showConsole)
		{
			Combatant combatant = ORK.Combatants.Create(index, group, showNotification, showConsole);
			combatant.Init();
			return combatant;
		}

		/// <summary>
		/// Creates a new instance of a combatant and initializes it with the passed on data.
		/// </summary>
		/// <param name="index">The ID/index of the combatant that will be created.</param>
		/// <param name="group">The group the combatant will join.</param>
		/// <param name="level">The base level used to initialize the combatant.</param>
		/// <param name="classLevel">The class level used to initialize the combatant.</param>
		/// <param name="classID">The ID/index of the class the combatant will have.</param>
		/// <param name="loadGame"><c>true</c> if this comes from loading a game.</param>
		/// <param name="learnAbilities"><c>true</c> if the combatant should learn abilities for the level.</param>
		/// <param name="useStartInventory"><c>true</c> if the combatant should receive the defined start inventory.</param>
		/// <param name="useStartEquipment"><c>true</c> if the combatant should receive the defined start equipment.</param>
		/// <param name="useInitEvent"><c>true</c> if the combatant should use the init game event.</param>
		/// <param name="useStatusEffects"><c>true</c> if the combatant should use auto status effects when initialized.</param>
		/// <returns>A new combatant instance initialized with the passed on data.</returns>
		public virtual Combatant CreateInstance(int index, Group group, bool showNotification, bool showConsole,
			int level, int classLevel, int classID, bool loadGame,
			bool learnAbilities, bool useStartInventory, bool useStartEquipment,
			bool useInitEvent, bool useStatusEffects)
		{
			Combatant combatant = ORK.Combatants.Create(index, group, showNotification, showConsole);
			combatant.Init(level, classLevel, classID, loadGame,
				learnAbilities, useStartInventory, useStartEquipment,
				useInitEvent, useStatusEffects);
			return combatant;
		}


		/*
		============================================================================
		Status value functions
		============================================================================
		*/
		/// <summary>
		/// Sets the value of a status value of the user.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="valueID">The ID/index of the status value.</param>
		/// <param name="newValue">The new value that will be used.</param>
		/// <param name="isCritical"><c>true</c> if this is a critical value change.</param>
		/// <param name="ignoreBarrier"><c>true</c> if the change should ignore barrier status values.</param>
		/// <param name="showFlyingText"><c>true</c> if the change should display flying texts.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		/// <param name="source">The source of the value change (e.g. combatant causing the change).</param>
		public virtual void SetStatusValue(Combatant user, int valueID,
			int newValue, bool isCritical, bool ignoreBarrier,
			bool showFlyingText, bool showConsole, StatusValueChangeSource source)
		{
			user.Status[valueID].SetValue(newValue, isCritical, ignoreBarrier,
				showFlyingText, showConsole, source);
		}

		/// <summary>
		/// Adds a value to a status value of the user.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="valueID">The ID/index of the status value.</param>
		/// <param name="addValue">The value that will be added.</param>
		/// <param name="isCritical"><c>true</c> if this is a critical value change.</param>
		/// <param name="checkDeath"><c>true</c> if the combatant should check for death.</param>
		/// <param name="checkLevelUp"><c>true</c> if the combatant should check for level up.</param>
		/// <param name="ignoreBarrier"><c>true</c> if the change should ignore barrier status values.</param>
		/// <param name="showFlyingText"><c>true</c> if the change should display flying texts.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		/// <param name="source">The source of the value change (e.g. combatant causing the change).</param>
		public virtual void AddStatusValue(Combatant user, int valueID,
			int addValue, bool isCritical, bool checkDeath, bool checkLevelUp,
			bool ignoreBarrier, bool showFlyingText, bool showConsole, StatusValueChangeSource source)
		{
			user.Status[valueID].AddValue(addValue, isCritical, checkDeath, checkLevelUp,
				ignoreBarrier, showFlyingText, showConsole, source);
		}

		/// <summary>
		/// Sets the base value of a status value of the user.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="valueID">The ID/index of the status value.</param>
		/// <param name="newValue">The new value that will be used.</param>
		public virtual void SetBaseStatusValue(Combatant user, int valueID, int newValue)
		{
			user.Status[valueID].SetBaseValue(newValue);
		}

		/// <summary>
		/// Adds a value to the base value of a status value of the user.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="valueID">The ID/index of the status value.</param>
		/// <param name="addValue">The value that will be added.</param>
		public virtual void AddBaseStatusValue(Combatant user, int valueID, int addValue)
		{
			user.Status[valueID].AddBaseValue(addValue);
		}

		/// <summary>
		/// Sets the 'Consumable' type status values of a combatant to their maximum value.
		/// </summary>
		/// <param name="user">The combatant that will be used.</param>
		/// <param name="revive"><c>true</c> if a dead combatant should be revived.</param>
		public virtual void Regenerate(Combatant user, bool revive)
		{
			user.Status.Regenerate(revive);
		}


		/*
		============================================================================
		Ability functions
		============================================================================
		*/
		/// <summary>
		/// Lets the user learn an ability.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="isGroupAbility"><c>true</c> if the ability should be learned by the entire group.</param>
		/// <param name="id">The ID/index of the ability.</param>
		/// <param name="level">The level of the ability.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		/// <returns><c>true</c> if the ability was learned.</returns>
		public virtual bool LearnAbility(Combatant user, bool isGroupAbility,
			int id, int level, bool showNotification, bool showConsole)
		{
			if(isGroupAbility)
			{
				return user.Group.Abilities.Learn(id, level, showNotification, showConsole);
			}
			else
			{
				return user.Abilities.Learn(id, level, showNotification, showConsole);
			}
		}

		/// <summary>
		/// Lets the user learn an ability.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="isGroupAbility"><c>true</c> if the ability is learned as a group ability.</param>
		/// <param name="ability">The ability that will be learned.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		/// <returns><c>true</c> if the ability was learned.</returns>
		public virtual bool LearnAbility(Combatant user, bool isGroupAbility,
			AbilityShortcut ability, bool showNotification, bool showConsole)
		{
			if(isGroupAbility)
			{
				return user.Group.Abilities.Learn(ability, showNotification, showConsole);
			}
			else
			{
				return user.Abilities.Learn(ability, showNotification, showConsole);
			}
		}

		/// <summary>
		/// Lets the user forget an ability.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="isGroupAbility"><c>true</c> if a group ability is forgotten.</param>
		/// <param name="id">The ID/index of the ability.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		/// <returns><c>true</c> if the ability was forgotten.</returns>
		public virtual bool ForgetAbility(Combatant user, bool isGroupAbility,
			int id, bool showNotification, bool showConsole)
		{
			if(isGroupAbility)
			{
				return user.Group.Abilities.Forget(id, showNotification, showConsole);
			}
			else
			{
				return user.Abilities.Forget(id, showNotification, showConsole);
			}
		}

		/// <summary>
		/// Lets the user learn an ability tree.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="abilityTreeID">The ID/index of the ability tree.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		/// <returns><c>true</c> if the ability tree was learned.</returns>
		public virtual bool LearnAbilityTree(Combatant user, int abilityTreeID, bool showConsole)
		{
			return user.Abilities.LearnTree(abilityTreeID, showConsole);
		}

		/// <summary>
		/// Lets the user forget an ability tree.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="abilityTreeID">The ID/index of the ability tree.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		public virtual void ForgetAbilityTree(Combatant user, int abilityTreeID, bool showConsole)
		{
			user.Abilities.ForgetTree(abilityTreeID, showConsole);
		}


		/*
		============================================================================
		Equipment functions
		============================================================================
		*/
		/// <summary>
		/// Equips an equipment on a combatant.
		/// </summary>
		/// <param name="user">The combatant that will equip the equipment.</param>
		/// <param name="partID">The ID/index of the equipment part it will be equipped on.
		/// Use <c>-1</c> if a matching equipment part should be searched.</param>
		/// <param name="equip">The <c>EquipShortcut</c> that will be equipped.</param>
		/// <param name="fromInventory">The combatant who's inventory should remove the equipment.</param>
		/// <param name="unequipToInventory">The combatant who's inventory should add equipment currently equipped on the used equipment part.</param>
		/// <param name="reset"><c>true</c> if the user's status system should be reset (i.e. checking for bonuses, etc.).</param>
		/// <returns><c>true</c> if the equipment was equipped.</returns>
		public virtual bool Equip(Combatant user, int partID, EquipShortcut equip,
			Combatant fromInventory, Combatant unequipToInventory, bool reset)
		{
			return user.Equipment.Equip(partID, equip, fromInventory, unequipToInventory, reset);
		}

		/// <summary>
		/// Unequips all currently equipped equipment of the user.
		/// </summary>
		/// <param name="user">The combatant that will unequip the equipment.</param>
		/// <param name="toInventory">The combatant who's inventory should add the unequipped equipment.</param>
		public virtual void UnequipAll(Combatant user, Combatant toInventory)
		{
			user.Equipment.UnequipAll(toInventory);
		}

		/// <summary>
		/// Unequips an equipment from the user.
		/// </summary>
		/// <param name="user">The combatant that will unequip the equipment.</param>
		/// <param name="equip">The equipment that will be unequiped.</param>
		/// <param name="toInventory">The combatant who's inventory should add the unequipped equipment.</param>
		public virtual void Unequip(Combatant user, EquipShortcut equip, Combatant toInventory)
		{
			user.Equipment.Unequip(equip, toInventory);
		}

		/// <summary>
		/// Unequips equipment currently equipped on a defined equipment part of the user.
		/// </summary>
		/// <param name="user">The combatant that will unequip the equipment.</param>
		/// <param name="partID">The ID/index of the equipment part that will be unequipped.</param>
		/// <param name="toInventory">The combatant who's inventory should add the unequipped equipment.</param>
		/// <param name="reset"><c>true</c> if the user's status system should be reset (i.e. checking for bonuses, etc.).</param>
		/// <param name="force"><c>true</c> if unequipping should be forced.</param>
		public virtual void Unequip(Combatant user, int partID, Combatant toInventory, bool reset, bool force)
		{
			user.Equipment.Unequip(partID, toInventory, reset, force);
		}


		/*
		============================================================================
		AI functions
		============================================================================
		*/
		/// <summary>
		/// Equips an AI behaviour on the user.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="aiBehaviourID">The ID/index of the AI behaviour.</param>
		/// <param name="slotIndex">The index of the AI behaviour slot.</param>
		/// <param name="toInventory"><c>true</c> if the currently equipped AI behaviour should be returned to the inventory.</param>
		/// <param name="fromInventory"><c>true</c> if the AI behaviour should be taken from the inventory.</param>
		/// <param name="notifyChange"><c>true</c> if the listeners should be notified of the change.</param>
		public virtual void EquipAIBehaviour(Combatant user, int aiBehaviourID, int slotIndex,
			bool toInventory, bool fromInventory, bool notifyChange)
		{
			user.AI.EquipAIBehaviour(aiBehaviourID, slotIndex, toInventory, fromInventory, notifyChange);
		}

		/// <summary>
		/// Unequips an AI behaviour from the user.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="slotIndex">The index of the AI behaviour slot.</param>
		/// <param name="toInventory"><c>true</c> if it should be returned to the inventory.</param>
		/// <param name="notifyChange"><c>true</c> if the listeners should be notified of the change.</param>
		public virtual void UnequipAIBehaviour(Combatant user, int slotIndex, bool toInventory, bool notifyChange)
		{
			user.AI.UnequipAIBehaviour(slotIndex, toInventory, notifyChange);
		}

		/// <summary>
		/// Equips an AI ruleset on the user.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="aiRulesetID">The ID/index of the AI ruleset.</param>
		/// <param name="slotIndex">The index of the AI behaviour slot.</param>
		/// <param name="toInventory"><c>true</c> if the currently equipped AI ruleset should be returned to the inventory.</param>
		/// <param name="fromInventory"><c>true</c> if the AI ruleset should be taken from the inventory.</param>
		/// <param name="notifyChange"><c>true</c> if the listeners should be notified of the change.</param>
		public virtual void EquipAIRuleset(Combatant user, int aiRulesetID, int slotIndex,
			bool toInventory, bool fromInventory, bool notifyChange)
		{
			user.AI.EquipAIRuleset(aiRulesetID, slotIndex, toInventory, fromInventory, notifyChange);
		}

		/// <summary>
		/// Unequips an AI ruleset from the user.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="slotIndex">The index of the AI ruleset slot.</param>
		/// <param name="toInventory"><c>true</c> if it should be returned to the inventory.</param>
		/// <param name="notifyChange"><c>true</c> if the listeners should be notified of the change.</param>
		public virtual void UnequipAIRuleset(Combatant user, int slotIndex, bool toInventory, bool notifyChange)
		{
			user.AI.UnequipAIRuleset(slotIndex, toInventory, notifyChange);
		}


		/*
		============================================================================
		Research functions
		============================================================================
		*/
		/// <summary>
		/// Starts research on a research item.
		/// </summary>
		/// <param name="researchItem">The research item.</param>
		public virtual void StartResearch(ResearchItem researchItem)
		{
			researchItem.StartResearch();
		}

		/// <summary>
		/// Cancels research on a research item.
		/// </summary>
		/// <param name="researchItem">The research item.</param>
		public virtual void CancelResearch(ResearchItem researchItem)
		{
			researchItem.CancelResearch();
		}
	}
}
