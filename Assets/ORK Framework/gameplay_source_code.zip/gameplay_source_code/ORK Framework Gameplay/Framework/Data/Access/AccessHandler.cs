﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[ORKEditorSettingInfo("Default", "Uses default access functionality for single player games.", "")]
	public class AccessHandler : BaseTypeData
	{
		protected ActionAccessHandler actionAccess;

		protected CombatantAccessHandler combatantAccess;

		protected GroupAccessHandler groupAccess;

		protected InventoryAccessHandler inventoryAccess;

		public AccessHandler()
		{
			this.actionAccess = new ActionAccessHandler();
			this.combatantAccess = new CombatantAccessHandler();
			this.groupAccess = new GroupAccessHandler();
			this.inventoryAccess = new InventoryAccessHandler();
		}

		public virtual ActionAccessHandler Action
		{
			get { return this.actionAccess; }
		}

		public virtual CombatantAccessHandler Combatant
		{
			get { return this.combatantAccess; }
		}

		public virtual GroupAccessHandler Group
		{
			get { return this.groupAccess; }
		}

		public virtual InventoryAccessHandler Inventory
		{
			get { return this.inventoryAccess; }
		}

		/// <summary>
		/// Called before ORK registers update handlers.
		/// </summary>
		public virtual void InitBeforeRegister()
		{

		}

		/// <summary>
		/// Called after ORK registers update handlers.
		/// </summary>
		public virtual void InitAfterRegister()
		{

		}
	}
}
