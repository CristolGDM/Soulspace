
using System.Reflection;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ORKFramework.Bonus;
using ORKFramework.Events.Steps;
using ORKFramework.Formulas.Steps;
using ORKFramework.AI.Steps;
using ORKFramework.Menu.Parts;

namespace ORKFramework
{
	public static class DataHelper
	{
		/*
		============================================================================
		Data callback functions
		============================================================================
		*/
		public static int Add(ORKDataType type)
		{
			// editor
			if(ORKDataType.Plugin == type)
			{
				return ORK.Plugins.Add();
			}

			// base data
			else if(ORKDataType.Language == type)
			{
				return ORK.Languages.Add();
			}
			else if(ORKDataType.Color == type)
			{
				return ORK.Colors.Add();
			}
			else if(ORKDataType.Difficulty == type)
			{
				return ORK.Difficulties.Add();
			}
			else if(ORKDataType.InputKey == type)
			{
				return ORK.InputKeys.Add();
			}
			else if(ORKDataType.ControlMap == type)
			{
				return ORK.ControlMaps.Add();
			}
			else if(ORKDataType.FormulaType == type)
			{
				return ORK.FormulaTypes.Add();
			}
			else if(ORKDataType.Formula == type)
			{
				return ORK.Formulas.Add();
			}
			else if(ORKDataType.Requirement == type)
			{
				return ORK.Requirements.Add();
			}
			else if(ORKDataType.AnimationType == type)
			{
				return ORK.AnimationTypes.Add();
			}
			else if(ORKDataType.Animation == type)
			{
				return ORK.Animations.Add();
			}
			else if(ORKDataType.DamageType == type)
			{
				return ORK.DamageTypes.Add();
			}
			else if(ORKDataType.SoundType == type)
			{
				return ORK.SoundTypes.Add();
			}
			else if(ORKDataType.PortraitType == type)
			{
				return ORK.PortraitTypes.Add();
			}
			else if(ORKDataType.VariableConditionTemplate == type)
			{
				return ORK.VariableConditionTemplates.Add();
			}
			else if(ORKDataType.StatusRequirementTemplate == type)
			{
				return ORK.StatusRequirementTemplates.Add();
			}

			// game data
			else if(ORKDataType.ConsoleType == type)
			{
				return ORK.ConsoleTypes.Add();
			}
			else if(ORKDataType.AreaType == type)
			{
				return ORK.AreaTypes.Add();
			}
			else if(ORKDataType.Area == type)
			{
				return ORK.Areas.Add();
			}
			else if(ORKDataType.Teleport == type)
			{
				return ORK.Teleports.Add();
			}
			else if(ORKDataType.CameraPosition == type)
			{
				return ORK.CameraPositions.Add();
			}
			else if(ORKDataType.MusicClip == type)
			{
				return ORK.MusicClips.Add();
			}
			else if(ORKDataType.GlobalEvent == type)
			{
				return ORK.GlobalEvents.Add();
			}

			// world data
			else if(ORKDataType.LogType == type)
			{
				return ORK.LogTypes.Add();
			}
			else if(ORKDataType.Log == type)
			{
				return ORK.Logs.Add();
			}
			else if(ORKDataType.LogText == type)
			{
				return ORK.LogTexts.Add();
			}
			else if(ORKDataType.SceneObjectType == type)
			{
				return ORK.SceneObjectTypes.Add();
			}
			else if(ORKDataType.SceneObject == type)
			{
				return ORK.SceneObjects.Add();
			}
			else if(ORKDataType.QuestType == type)
			{
				return ORK.QuestTypes.Add();
			}
			else if(ORKDataType.Quest == type)
			{
				return ORK.Quests.Add();
			}
			else if(ORKDataType.QuestTask == type)
			{
				return ORK.QuestTasks.Add();
			}

			// status data
			else if(ORKDataType.AttackAttributes == type)
			{
				return ORK.AttackAttributes.Add();
			}
			else if(ORKDataType.DefenceAttributes == type)
			{
				return ORK.DefenceAttributes.Add();
			}
			else if(ORKDataType.StatusType == type)
			{
				return ORK.StatusTypes.Add();
			}
			else if(ORKDataType.StatusValue == type)
			{
				return ORK.StatusValues.Add();
			}
			else if(ORKDataType.StatusEffectType == type)
			{
				return ORK.StatusEffectTypes.Add();
			}
			else if(ORKDataType.StatusEffect == type)
			{
				return ORK.StatusEffects.Add();
			}
			else if(ORKDataType.StatusBonus == type)
			{
				return ORK.StatusBonuses.Add();
			}
			else if(ORKDataType.AbilityType == type)
			{
				return ORK.AbilityTypes.Add();
			}
			else if(ORKDataType.Ability == type)
			{
				return ORK.Abilities.Add();
			}
			else if(ORKDataType.StatusDevelopment == type)
			{
				return ORK.StatusDevelopments.Add();
			}
			else if(ORKDataType.AbilityDevelopment == type)
			{
				return ORK.AbilityDevelopments.Add();
			}
			else if(ORKDataType.AbilityTree == type)
			{
				return ORK.AbilityTrees.Add();
			}

			// inventory
			else if(ORKDataType.ItemType == type)
			{
				return ORK.ItemTypes.Add();
			}
			else if(ORKDataType.Currency == type)
			{
				return ORK.Currencies.Add();
			}
			else if(ORKDataType.Item == type)
			{
				return ORK.Items.Add();
			}
			else if(ORKDataType.EquipmentPart == type)
			{
				return ORK.EquipmentParts.Add();
			}
			else if(ORKDataType.Weapon == type)
			{
				return ORK.Armors.Add();
			}
			else if(ORKDataType.CraftingType == type)
			{
				return ORK.CraftingTypes.Add();
			}
			else if(ORKDataType.CraftingRecipe == type)
			{
				return ORK.CraftingRecipes.Add();
			}

			// combat
			else if(ORKDataType.Faction == type)
			{
				return ORK.Factions.Add();
			}
			else if(ORKDataType.FactionBenefit == type)
			{
				return ORK.FactionBenefits.Add();
			}
			else if(ORKDataType.Class == type)
			{
				return ORK.Classes.Add();
			}
			else if(ORKDataType.BattleAI == type)
			{
				return ORK.BattleAIs.Add();
			}
			else if(ORKDataType.ActionCombo == type)
			{
				return ORK.ActionCombos.Add();
			}
			else if(ORKDataType.AIType == type)
			{
				return ORK.AITypes.Add();
			}
			else if(ORKDataType.AIBehaviour == type)
			{
				return ORK.AIBehaviours.Add();
			}
			else if(ORKDataType.AIRuleset == type)
			{
				return ORK.AIRulesets.Add();
			}
			else if(ORKDataType.BattleGridCellType == type)
			{
				return ORK.BattleGridCellTypes.Add();
			}
			else if(ORKDataType.BattleRangeTemplate == type)
			{
				return ORK.BattleRangeTemplates.Add();
			}
			else if(ORKDataType.BattleGridFormation == type)
			{
				return ORK.BattleGridFormations.Add();
			}
			else if(ORKDataType.CombatantType == type)
			{
				return ORK.CombatantTypes.Add();
			}
			else if(ORKDataType.Combatant == type)
			{
				return ORK.Combatants.Add();
			}
			else if(ORKDataType.CombatantGroup == type)
			{
				return ORK.CombatantGroups.Add();
			}
			else if(ORKDataType.MoveAI == type)
			{
				return ORK.MoveAIs.Add();
			}
			else if(ORKDataType.BattleMenu == type)
			{
				return ORK.BattleMenus.Add();
			}
			else if(ORKDataType.Loot == type)
			{
				return ORK.Loot.Add();
			}
			else if(ORKDataType.ResearchType == type)
			{
				return ORK.ResearchTypes.Add();
			}
			else if(ORKDataType.ResearchTree == type)
			{
				return ORK.ResearchTrees.Add();
			}

			// menu
			else if(ORKDataType.GUILayer == type)
			{
				return ORK.GUILayers.Add();
			}
			else if(ORKDataType.GUILayout == type)
			{
				return ORK.GUILayouts.Add();
			}
			else if(ORKDataType.GUIBox == type)
			{
				return ORK.GUIBoxes.Add();
			}
			else if(ORKDataType.CombatantSelection == type)
			{
				return ORK.CombatantSelections.Add();
			}
			else if(ORKDataType.QuantitySelection == type)
			{
				return ORK.QuantitySelections.Add();
			}
			else if(ORKDataType.MenuScreen == type)
			{
				return ORK.MenuScreens.Add();
			}
			else if(ORKDataType.HUD == type)
			{
				return ORK.HUDs.Add();
			}
			else if(ORKDataType.ShopLayout == type)
			{
				return ORK.ShopLayouts.Add();
			}
			else if(ORKDataType.Shop == type)
			{
				return ORK.Shops.Add();
			}
			return -1;
		}


		// add/remove data
		public static void Added(ORKDataType type)
		{
			DataHelper.Added(type, -1);
		}

		public static void Added(ORKDataType type, int index)
		{
			CoreSettings[] setting = ORK.Data.All;
			for(int i = 0; i < setting.Length; i++)
			{
				setting[i].DataAdded(type, index);
			}

			// add list for event files
			if(ORK.Data.addList == null)
			{
				ORK.Data.addList = new List<KeyValuePair<ORKDataType, int>>();
			}
			ORK.Data.addList.Add(new KeyValuePair<ORKDataType, int>(type, index));
		}

		public static void Removed(ORKDataType type, int index)
		{
			DataHelper.Removed(type, index, -1);
		}

		public static void Removed(ORKDataType type, int index, int index2)
		{
			CoreSettings[] setting = ORK.Data.All;
			for(int i = 0; i < setting.Length; i++)
			{
				setting[i].DataRemoved(type, index, index2);
			}

			// remove list for event files
			if(ORK.Data.removeList == null)
			{
				ORK.Data.removeList = new List<KeyValuePair<ORKDataType, KeyValuePair<int, int>>>();
			}
			ORK.Data.removeList.Add(new KeyValuePair<ORKDataType, KeyValuePair<int, int>>(type,
				new KeyValuePair<int, int>(index, index2)));
		}

		public static void Moved(ORKDataType type, bool down, int index)
		{
			DataHelper.Moved(type, down, index, -1);
		}

		public static void Moved(ORKDataType type, bool down, int index, int index2)
		{
			CoreSettings[] setting = ORK.Data.All;
			for(int i = 0; i < setting.Length; i++)
			{
				setting[i].DataMoved(type, down, index, index2);
			}

			if(ORK.Data.moveList == null)
			{
				ORK.Data.moveList = new List<KeyValuePair<ORKDataType, DataMoveInformation>>();
			}
			ORK.Data.moveList.Add(new KeyValuePair<ORKDataType, DataMoveInformation>(type,
				new DataMoveInformation(down, index, index2)));
		}


		// status data
		public static void SetStatusValueType(int index, StatusValueType type)
		{
			ORK.Difficulties.SetStatusValueType(index, type);
			ORK.StatusValues.SetStatusValueType(index, type);
			ORK.StatusDevelopments.SetStatusValueType(index, type);
			ORK.AbilityTrees.SetStatusValueType(index, type);
			ORK.Combatants.SetStatusValueType(index, type);
			ORK.Battle.SystemSettings.SetStatusValueType(index, type);
		}

		public static void StatusValueMinMaxChanged(int index, int min, int max)
		{
			ORK.StatusDevelopments.StatusValueMinMaxChanged(index, min, max);
		}

		// developments
		public static void StatusDevelopmentLevels(int index)
		{
			ORK.Combatants.StatusDevelopmentLevels(index);
		}


		// inventory
		public static void WeaponEPChanged(int index)
		{
			//ORK.Classes.WeaponEPChanged(index);
			//ORK.Combatants.WeaponEPChanged(index);
		}

		public static void ArmorEPChanged(int index)
		{
			//ORK.Classes.ArmorEPChanged(index);
			//ORK.Combatants.ArmorEPChanged(index);
		}


		/*
		============================================================================
		Data loaded check functions
		============================================================================
		*/
		public static void DataLoaded<T>(T instance)
		{
			if(instance != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					System.Object value = field[i].GetValue(instance);

					if(value != null)
					{
						if(value.GetType().IsArray)
						{
							ORKEditorArrayAttribute arrayInfo = null;
							System.Object[] attr = field[i].GetCustomAttributes(typeof(ORKEditorArrayAttribute), true);
							if(attr.Length > 0)
							{
								arrayInfo = attr[0] as ORKEditorArrayAttribute;
							}

							if(arrayInfo != null &&
								arrayInfo.dataType != ORKDataType.None)
							{
								int count = ORK.Count(arrayInfo.dataType);

								System.Array tmp = value as System.Array;
								if(tmp.Length != count)
								{
									System.Array newArray = System.Array.CreateInstance(value.GetType().GetElementType(), count);
									System.Array.Copy(tmp, newArray, Mathf.Min(count, tmp.Length));

									if(tmp.Length < newArray.Length)
									{
										for(int j = tmp.Length; j < newArray.Length; j++)
										{
											newArray.SetValue(ReflectionTypeHandler.Instance.CreateInstance(value.GetType().GetElementType()), j);
										}
									}
									value = System.Convert.ChangeType(newArray, value.GetType());
									field[i].SetValue(instance, value);
								}
							}
						}

						if(typeof(IBaseData).IsAssignableFrom(field[i].FieldType))
						{
							DataHelper.DataLoaded(value as IBaseData);
						}
						else if(typeof(IBaseData[]).IsAssignableFrom(field[i].FieldType))
						{
							IBaseData[] tmp = (IBaseData[])(System.Array)value;
							for(int j = 0; j < tmp.Length; j++)
							{
								DataHelper.DataLoaded(tmp[j]);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Automatic data update functions
		============================================================================
		*/
		/// <summary>
		/// Processes adding data.
		/// </summary>
		/// <param name='instance'>
		/// Instance of the class.
		/// </param>
		/// <param name='type'>
		/// ORKDataType defining the changed data.
		/// </param>
		/// <param name='index'>
		/// Index of the attack/defence attributes an attribute was added to.
		/// -1 if no attack/defence attribute was added.
		/// </param>
		/// <typeparam name='T'>
		/// The class must implement the <see cref="ORKFramework.IBaseData"> or 
		/// descend from <see cref="ORKFramework.BaseData">.
		/// </typeparam>
		public static void DataAdded<T>(T instance, ORKDataType type, int index)
		{
			if(instance != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					System.Object value = field[i].GetValue(instance);

					if(value != null)
					{
						if(value.GetType().IsArray)
						{
							ORKEditorArrayAttribute arrayInfo = null;
							System.Object[] attr = field[i].GetCustomAttributes(typeof(ORKEditorArrayAttribute), true);
							if(attr.Length > 0)
							{
								arrayInfo = attr[0] as ORKEditorArrayAttribute;
							}

							if(arrayInfo != null &&
								type == arrayInfo.dataType)
							{
								if(index == -1)
								{
									ArrayList tmp = new ArrayList(value as System.Array);
									if(arrayInfo.defaultAddValue == null)
									{
										tmp.Add(ReflectionTypeHandler.Instance.CreateInstance(value.GetType().GetElementType()));
									}
									else
									{
										tmp.Add(arrayInfo.defaultAddValue);
									}
									value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
									field[i].SetValue(instance, value);
								}
							}
							else if(index != -1)
							{
								if(ORKDataType.AttackAttributes == type &&
									value.GetType().GetElementType().Equals(typeof(AtkAttrBonus)))
								{
									AtkAttrBonus[] tmp = value as AtkAttrBonus[];
									for(int j = 0; j < tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											ArrayHelper.Add<float>(ref tmp[j].bonus, 0);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(ORKDataType.DefenceAttributes == type &&
									value.GetType().GetElementType().Equals(typeof(DefAttrBonus)))
								{
									DefAttrBonus[] tmp = value as DefAttrBonus[];
									for(int j = 0; j < tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											ArrayHelper.Add<float>(ref tmp[j].bonus, 0);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(ORKDataType.AttackAttributes == type &&
									value.GetType().GetElementType().Equals(typeof(AtkAttrStartValue)))
								{
									AtkAttrStartValue[] tmp = value as AtkAttrStartValue[];
									for(int j = 0; j < tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											ArrayHelper.Add<float>(ref tmp[j].startValue, 100);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(ORKDataType.DefenceAttributes == type &&
									value.GetType().GetElementType().Equals(typeof(DefAttrStartValue)))
								{
									DefAttrStartValue[] tmp = value as DefAttrStartValue[];
									for(int j = 0; j < tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											ArrayHelper.Add<float>(ref tmp[j].startValue, 100);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
							}
							else
							{
								ORKEditorInfoAttribute info = null;
								attr = field[i].GetCustomAttributes(typeof(ORKEditorInfoAttribute), true);
								if(attr.Length > 0)
								{
									info = attr[0] as ORKEditorInfoAttribute;
								}

								if(info != null && info.isPopup && type == info.popupType &&
									!info.noAutoData && !info.noAutoAdd &&
									value.GetType().GetElementType().Equals(typeof(int)))
								{
									ArrayList tmp = new ArrayList(value as System.Array);
									tmp.Add(0);
									value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
									field[i].SetValue(instance, value);
								}
							}
						}

						if(typeof(IBaseData).IsAssignableFrom(field[i].FieldType))
						{
							DataHelper.DataAdded(value as IBaseData, type, index);
						}
						else if(typeof(IBaseData[]).IsAssignableFrom(field[i].FieldType))
						{
							IBaseData[] tmp = (IBaseData[])(System.Array)value;
							for(int j = 0; j < tmp.Length; j++)
							{
								DataHelper.DataAdded(tmp[j], type, index);
							}
						}
					}
				}
			}
		}

		/// <summary>
		/// Processes removing data.
		/// </summary>
		/// <param name='instance'>
		/// Instance of the class.
		/// </param>
		/// <param name='type'>
		/// ORKDataType defining the changed data.
		/// </param>
		/// <param name='index'>
		/// The index of the removed data.
		/// </param>
		/// <param name='index2'>
		/// The index of the removed attack/defence attribute.
		/// -1 if other data has been removed.
		/// </param>
		/// <typeparam name='T'>
		/// The class must implement the <see cref="ORKFramework.IBaseData"> or 
		/// descend from <see cref="ORKFramework.BaseData">.
		/// </typeparam>
		public static void DataRemoved<T>(T instance, ORKDataType type, int index, int index2)
		{
			if(instance != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					System.Object value = field[i].GetValue(instance);

					if(value != null)
					{
						if(value is int)
						{
							ORKEditorInfoAttribute editorInfo = null;
							System.Object[] attr = field[i].GetCustomAttributes(typeof(ORKEditorInfoAttribute), true);
							if(attr.Length > 0)
							{
								editorInfo = attr[0] as ORKEditorInfoAttribute;
							}

							if(editorInfo != null &&
								(editorInfo.isPopup || editorInfo.isLimitedPopup))
							{
								ORKDataType type2 = editorInfo.popupType;

								// get type from other enum field
								if(editorInfo.isPopup && editorInfo.itemFieldName != "")
								{
									FieldInfo itemField = instance.GetType().GetField(editorInfo.itemFieldName);
									if(itemField != null)
									{
										EnumConverter.Convert(ref type2, itemField.GetValue(instance));
									}
								}

								if(type == type2)
								{
									// default
									if(index2 == -1 && (editorInfo.isLimitedPopup || editorInfo.idFieldName == ""))
									{
										int tmp = (int)value;
										if(tmp == index)
										{
											tmp = 0;
										}
										else if(tmp > index)
										{
											tmp--;
										}
										value = tmp;
										field[i].SetValue(instance, value);
									}
									// special type popup (attack/defence attribute, research items)
									else if(index2 != -1 && editorInfo.idFieldName != "")
									{
										FieldInfo itemField = instance.GetType().GetField(editorInfo.idFieldName);
										if(itemField != null)
										{
											System.Object value2 = itemField.GetValue(instance);
											if(value2 is int && index == (int)value2)
											{
												int tmp = (int)value;
												if(tmp == index2)
												{
													tmp = 0;
												}
												else if(tmp > index2)
												{
													tmp--;
												}
												value = tmp;
												field[i].SetValue(instance, value);
											}
										}
									}
								}
							}
						}
						else if(value is string)
						{
							string tmp = (string)value;
							DataHelper.RemoveFromString(ref tmp, type, index, index2);
							value = tmp;
							field[i].SetValue(instance, value);
						}
						else if(value.GetType().IsArray)
						{
							ORKEditorArrayAttribute arrayInfo = null;
							System.Object[] attr = field[i].GetCustomAttributes(typeof(ORKEditorArrayAttribute), true);
							if(attr.Length > 0)
							{
								arrayInfo = attr[0] as ORKEditorArrayAttribute;
							}

							if(arrayInfo != null)
							{
								if(value.GetType().GetElementType().Equals(typeof(ItemGain)))
								{
									ItemGain[] tmp = value as ItemGain[];
									if(tmp.Length > arrayInfo.noRemoveCount)
									{
										for(int j = 0; j < tmp.Length; j++)
										{
											if(tmp[j] != null &&
												type == EnumConverter.Convert(tmp[j].type) &&
												tmp[j].id == index)
											{
												ArrayHelper.RemoveAt(ref tmp, j);
												j--;
											}
										}
										value = tmp;
										field[i].SetValue(instance, value);
									}
								}
								else if(value.GetType().GetElementType().Equals(typeof(ItemGainSimple)))
								{
									ItemGainSimple[] tmp = value as ItemGainSimple[];
									if(tmp.Length > arrayInfo.noRemoveCount)
									{
										for(int j = 0; j < tmp.Length; j++)
										{
											if(tmp[j] != null &&
												type == EnumConverter.Convert(tmp[j].type) &&
												tmp[j].id == index)
											{
												ArrayHelper.RemoveAt(ref tmp, j);
												j--;
											}
										}
										value = tmp;
										field[i].SetValue(instance, value);
									}
								}
								// remove attribute bonus index
								else if(index2 != -1 && ORKDataType.AttackAttributes == type &&
									value.GetType().GetElementType().Equals(typeof(AtkAttrBonus)))
								{
									AtkAttrBonus[] tmp = value as AtkAttrBonus[];
									for(int j = 0; j < tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											ArrayHelper.RemoveAt(ref tmp[j].bonus, index2);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(index2 != -1 && ORKDataType.DefenceAttributes == type &&
									value.GetType().GetElementType().Equals(typeof(DefAttrBonus)))
								{
									DefAttrBonus[] tmp = value as DefAttrBonus[];
									for(int j = 0; j < tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											ArrayHelper.RemoveAt(ref tmp[j].bonus, index2);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								// remove attribute start value index
								else if(index2 != -1 && ORKDataType.AttackAttributes == type &&
									value.GetType().GetElementType().Equals(typeof(AtkAttrStartValue)))
								{
									AtkAttrStartValue[] tmp = value as AtkAttrStartValue[];
									for(int j = 0; j < tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											ArrayHelper.RemoveAt(ref tmp[j].startValue, index2);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(index2 != -1 && ORKDataType.DefenceAttributes == type &&
									value.GetType().GetElementType().Equals(typeof(DefAttrStartValue)))
								{
									DefAttrStartValue[] tmp = value as DefAttrStartValue[];
									for(int j = 0; j < tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											ArrayHelper.RemoveAt(ref tmp[j].startValue, index2);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(index2 == -1)
								{
									if(arrayInfo.removeCheckField != "" &&
										(type == arrayInfo.removeType ||
										arrayInfo.typeCheckField != ""))
									{
										ArrayList tmp = new ArrayList(value as System.Array);
										if(tmp.Count > arrayInfo.noRemoveCount)
										{
											for(int j = 0; j < tmp.Count; j++)
											{
												if(tmp[j] != null)
												{
													System.Object value2 = null;
													ORKDataType type2 = arrayInfo.removeType;
													if(arrayInfo.typeCheckField != "" &&
														ReflectionTypeHandler.GetFieldValue(out value2, tmp[j], arrayInfo.typeCheckField))
													{
														EnumConverter.Convert(ref type2, value2);
													}

													value2 = null;
													if(type == type2 &&
														ReflectionTypeHandler.GetFieldValue(out value2, tmp[j], arrayInfo.removeCheckField) &&
														value2 is int &&
														index == (int)value2)
													{
														tmp.RemoveAt(j);
														j--;
													}
												}
											}
											value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
											field[i].SetValue(instance, value);
										}
									}
									else if(type == arrayInfo.dataType)
									{
										ArrayList tmp = new ArrayList(value as System.Array);
										if(tmp.Count > arrayInfo.noRemoveCount)
										{
											tmp.RemoveAt(index);
											value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
											field[i].SetValue(instance, value);
										}
									}
									else
									{
										ORKEditorInfoAttribute info = null;
										attr = field[i].GetCustomAttributes(typeof(ORKEditorInfoAttribute), true);
										if(attr.Length > 0)
										{
											info = attr[0] as ORKEditorInfoAttribute;
										}

										if(info != null && info.isPopup && type == info.popupType &&
											!info.noAutoData && !info.noAutoRemove &&
											value.GetType().GetElementType().Equals(typeof(int)) && index2 == -1)
										{
											ArrayList tmp = new ArrayList(value as System.Array);
											for(int j = 0; j < tmp.Count; j++)
											{
												int tmpVal = (int)tmp[j];
												if(tmpVal == index)
												{
													tmp.RemoveAt(j--);
												}
												else if(tmpVal > index)
												{
													tmpVal--;
													tmp[j] = tmpVal;
												}
											}
											value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
											field[i].SetValue(instance, value);
										}
									}
								}

								// check language strings
								if(ORKDataType.Language == arrayInfo.dataType &&
									value.GetType().GetElementType().Equals(typeof(string)))
								{
									ArrayList tmp = new ArrayList(value as System.Array);
									for(int j = 0; j < tmp.Count; j++)
									{
										string tmpVal = (string)tmp[j];
										DataHelper.RemoveFromString(ref tmpVal, type, index, index2);
										tmp[j] = tmpVal;

									}
									value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
									field[i].SetValue(instance, value);
								}
							}
							else
							{
								ORKEditorInfoAttribute info = null;
								attr = field[i].GetCustomAttributes(typeof(ORKEditorInfoAttribute), true);
								if(attr.Length > 0)
								{
									info = attr[0] as ORKEditorInfoAttribute;
								}

								if(info != null && info.isPopup && type == info.popupType &&
									!info.noAutoData && !info.noAutoRemove &&
									value.GetType().GetElementType().Equals(typeof(int)))
								{
									ArrayList tmp = new ArrayList(value as System.Array);
									if(index2 == -1)
									{
										for(int j = 0; j < tmp.Count; j++)
										{
											int tmpVal = (int)tmp[j];
											if(tmpVal == index)
											{
												tmp.RemoveAt(j--);
											}
											else if(tmpVal > index)
											{
												tmpVal--;
												tmp[j] = tmpVal;
											}
										}
									}
									else
									{
										int tmpVal = (int)tmp[index];
										if(tmpVal == index2)
										{
											tmpVal = 0;
										}
										else if(tmpVal > index2)
										{
											tmpVal--;
										}
										tmp[index] = tmpVal;
									}
									value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
									field[i].SetValue(instance, value);
								}
							}
						}

						if(typeof(IBaseData).IsAssignableFrom(field[i].FieldType))
						{
							DataHelper.DataRemoved(value as IBaseData, type, index, index2);
						}
						else if(typeof(IBaseData[]).IsAssignableFrom(field[i].FieldType))
						{
							IBaseData[] tmp = (IBaseData[])(System.Array)value;
							for(int j = 0; j < tmp.Length; j++)
							{
								DataHelper.DataRemoved(tmp[j], type, index, index2);
							}
						}
					}
				}
			}
		}

		public static void DataMoved<T>(T instance, ORKDataType type, bool down, int index, int index2)
		{
			if(instance != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					System.Object value = field[i].GetValue(instance);

					if(value != null)
					{
						if(value is int)
						{
							ORKEditorInfoAttribute editorInfo = null;
							System.Object[] attr = field[i].GetCustomAttributes(typeof(ORKEditorInfoAttribute), true);
							if(attr.Length > 0)
							{
								editorInfo = attr[0] as ORKEditorInfoAttribute;
							}

							if(editorInfo != null &&
								(editorInfo.isPopup || editorInfo.isLimitedPopup))
							{
								ORKDataType type2 = editorInfo.popupType;

								// get type from other enum field
								if(editorInfo.isPopup && editorInfo.itemFieldName != "")
								{
									FieldInfo itemField = instance.GetType().GetField(editorInfo.itemFieldName);
									if(itemField != null)
									{
										EnumConverter.Convert(ref type2, itemField.GetValue(instance));
									}
								}

								if(type == type2)
								{
									// default
									if(index2 == -1 && (editorInfo.isLimitedPopup || editorInfo.idFieldName == ""))
									{
										int tmp = (int)value;
										DataHelper.SwapIndex(ref tmp, index, down);
										value = tmp;
										field[i].SetValue(instance, value);
									}
									// special type popup (attack/defence attribute, research items)
									else if(index2 != -1 && editorInfo.idFieldName != "")
									{
										FieldInfo itemField = instance.GetType().GetField(editorInfo.idFieldName);
										if(itemField != null)
										{
											System.Object value2 = itemField.GetValue(instance);
											if(value2 is int && index == (int)value2)
											{
												int tmp = (int)value;
												DataHelper.SwapIndex(ref tmp, index2, down);
												value = tmp;
												field[i].SetValue(instance, value);
											}
										}
									}
								}
							}
						}
						else if(value is string)
						{
							string tmp = (string)value;
							DataHelper.SwapInString(ref tmp, type, down, index, index2);
							value = tmp;
							field[i].SetValue(instance, value);
						}
						else if(value.GetType().IsArray)
						{
							ORKEditorArrayAttribute arrayInfo = null;
							System.Object[] attr = field[i].GetCustomAttributes(typeof(ORKEditorArrayAttribute), true);
							if(attr.Length > 0)
							{
								arrayInfo = attr[0] as ORKEditorArrayAttribute;
							}

							if(arrayInfo != null)
							{
								if(value.GetType().GetElementType().Equals(typeof(ItemGain)))
								{
									ItemGain[] tmp = value as ItemGain[];
									for(int j = 0; j < tmp.Length; j++)
									{
										if(tmp[j] != null &&
											type == EnumConverter.Convert(tmp[j].type))
										{
											DataHelper.SwapIndex(ref tmp[j].id, index, down);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								// move attribute bonus index
								else if(index2 != -1 && ORKDataType.AttackAttributes == type &&
									value.GetType().GetElementType().Equals(typeof(AtkAttrBonus)))
								{
									AtkAttrBonus[] tmp = value as AtkAttrBonus[];
									for(int j = 0; j < tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											if(down)
											{
												ArrayHelper.MoveDown(ref tmp[j].bonus, index2);
											}
											else
											{
												ArrayHelper.MoveUp(ref tmp[j].bonus, index2);
											}
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(index2 != -1 && ORKDataType.DefenceAttributes == type &&
									value.GetType().GetElementType().Equals(typeof(DefAttrBonus)))
								{
									DefAttrBonus[] tmp = value as DefAttrBonus[];
									for(int j = 0; j < tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											if(down)
											{
												ArrayHelper.MoveDown(ref tmp[j].bonus, index2);
											}
											else
											{
												ArrayHelper.MoveUp(ref tmp[j].bonus, index2);
											}
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								// move attribute start value index
								else if(index2 != -1 && ORKDataType.AttackAttributes == type &&
									value.GetType().GetElementType().Equals(typeof(AtkAttrStartValue)))
								{
									AtkAttrStartValue[] tmp = value as AtkAttrStartValue[];
									for(int j = 0; j < tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											if(down)
											{
												ArrayHelper.MoveDown(ref tmp[j].startValue, index2);
											}
											else
											{
												ArrayHelper.MoveUp(ref tmp[j].startValue, index2);
											}
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(index2 != -1 && ORKDataType.DefenceAttributes == type &&
									value.GetType().GetElementType().Equals(typeof(DefAttrStartValue)))
								{
									DefAttrStartValue[] tmp = value as DefAttrStartValue[];
									for(int j = 0; j < tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											if(down)
											{
												ArrayHelper.MoveDown(ref tmp[j].startValue, index2);
											}
											else
											{
												ArrayHelper.MoveUp(ref tmp[j].startValue, index2);
											}
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(index2 == -1)
								{
									if(type == arrayInfo.dataType)
									{
										ArrayList tmp = new ArrayList(value as System.Array);
										DataHelper.SwapArrayList(ref tmp, index, down);
										value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
										field[i].SetValue(instance, value);
									}
									else
									{
										ORKEditorInfoAttribute info = null;
										attr = field[i].GetCustomAttributes(typeof(ORKEditorInfoAttribute), true);
										if(attr.Length > 0)
										{
											info = attr[0] as ORKEditorInfoAttribute;
										}

										if(info != null && info.isPopup && type == info.popupType &&
											!info.noAutoData && !info.noAutoMove &&
											value.GetType().GetElementType().Equals(typeof(int)) && index2 == -1)
										{
											ArrayList tmp = new ArrayList(value as System.Array);
											for(int j = 0; j < tmp.Count; j++)
											{
												int tmpVal = (int)tmp[j];
												DataHelper.SwapIndex(ref tmpVal, index, down);
												tmp[j] = tmpVal;
											}
											value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
											field[i].SetValue(instance, value);
										}
									}
								}

								// check language strings
								if(ORKDataType.Language == arrayInfo.dataType &&
									value.GetType().GetElementType().Equals(typeof(string)))
								{
									ArrayList tmp = new ArrayList(value as System.Array);
									for(int j = 0; j < tmp.Count; j++)
									{
										string tmpVal = (string)tmp[j];
										DataHelper.SwapInString(ref tmpVal, type, down, index, index2);
										tmp[j] = tmpVal;

									}
									value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
									field[i].SetValue(instance, value);
								}
							}
							else
							{
								ORKEditorInfoAttribute info = null;
								attr = field[i].GetCustomAttributes(typeof(ORKEditorInfoAttribute), true);
								if(attr.Length > 0)
								{
									info = attr[0] as ORKEditorInfoAttribute;
								}

								if(info != null && info.isPopup && type == info.popupType &&
									!info.noAutoData && !info.noAutoMove &&
									value.GetType().GetElementType().Equals(typeof(int)))
								{
									ArrayList tmp = new ArrayList(value as System.Array);
									if(index2 == -1)
									{
										for(int j = 0; j < tmp.Count; j++)
										{
											int tmpVal = (int)tmp[j];
											DataHelper.SwapIndex(ref tmpVal, index, down);
											tmp[j] = tmpVal;
										}
									}
									else
									{
										int tmpVal = (int)tmp[index];
										DataHelper.SwapIndex(ref tmpVal, index2, down);
										tmp[index] = tmpVal;
									}
									value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
									field[i].SetValue(instance, value);
								}
							}
						}

						if(typeof(IBaseData).IsAssignableFrom(field[i].FieldType))
						{
							DataHelper.DataMoved(value as IBaseData, type, down, index, index2);
						}
						else if(typeof(IBaseData[]).IsAssignableFrom(field[i].FieldType))
						{
							IBaseData[] tmp = (IBaseData[])(System.Array)value;
							for(int j = 0; j < tmp.Length; j++)
							{
								DataHelper.DataMoved(tmp[j], type, down, index, index2);
							}
						}
					}
				}
			}
		}

		private static void SwapIndex(ref int tmp, int index, bool down)
		{
			if(down)
			{
				if(tmp == index)
				{
					tmp++;
				}
				else if(tmp == index + 1)
				{
					tmp--;
				}
			}
			else
			{
				if(tmp == index)
				{
					tmp--;
				}
				else if(tmp == index - 1)
				{
					tmp++;
				}
			}
		}

		private static void SwapArrayList(ref ArrayList tmp, int index, bool down)
		{
			if(down ? index + 1 < tmp.Count : index < tmp.Count)
			{
				System.Object obj = tmp[index];
				if(down)
				{
					tmp[index] = tmp[index + 1];
					tmp[index + 1] = obj;
				}
				else
				{
					tmp[index] = tmp[index - 1];
					tmp[index - 1] = obj;
				}
			}
		}

		private static string[] ReplaceNoType = new string[] {
				TextCode.Name, TextCode.ShortName, TextCode.Description, TextCode.Icon
		};

		private static string[] ReplaceWithType = new string[] {
				TextCode.Name, TextCode.ShortName, TextCode.Description, TextCode.Icon,
				TextCode.TypeName, TextCode.TypeShortName, TextCode.TypeDescription, TextCode.TypeIcon
		};

		private static string[] ReplaceInInventory = new string[] {
				TextCode.Name, TextCode.ShortName, TextCode.Description, TextCode.Icon,
				TextCode.TypeName, TextCode.TypeShortName, TextCode.TypeDescription, TextCode.TypeIcon,
				TextCode.InInventory
		};

		private static string[] ReplaceInInventoryEquipped = new string[] {
				TextCode.Name, TextCode.ShortName, TextCode.Description, TextCode.Icon,
				TextCode.TypeName, TextCode.TypeShortName, TextCode.TypeDescription, TextCode.TypeIcon,
				TextCode.InInventory, TextCode.IsEquipped
		};

		private static void RemoveFromString(ref string text, ORKDataType type, int index, int index2)
		{
			if(ORKDataType.Area == type)
			{
				if(text.Contains(TextCode.Area))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.Area,
						DataHelper.ReplaceWithType, index, ORK.Areas.Count);
				}
			}
			else if(ORKDataType.AreaType == type)
			{
				if(text.Contains(TextCode.AreaType))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.AreaType,
						DataHelper.ReplaceNoType, index, ORK.AreaTypes.Count);
				}
			}
			else if(ORKDataType.Teleport == type)
			{
				if(text.Contains(TextCode.Teleport))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.Teleport,
						DataHelper.ReplaceWithType, index, ORK.Teleports.Count);
				}
			}
			else if(ORKDataType.Currency == type)
			{
				if(text.Contains(TextCode.Currency))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.Currency,
						DataHelper.ReplaceInInventory, index, ORK.Currencies.Count);
				}
			}
			else if(ORKDataType.Item == type)
			{
				if(text.Contains(TextCode.Item))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.Item,
						DataHelper.ReplaceInInventory, index, ORK.Items.Count);
				}
			}
			else if(ORKDataType.ItemType == type)
			{
				if(text.Contains(TextCode.ItemType))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.ItemType,
						DataHelper.ReplaceNoType, index, ORK.ItemTypes.Count);
				}
			}
			else if(ORKDataType.CraftingRecipe == type)
			{
				if(text.Contains(TextCode.CraftingRecipe))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.CraftingRecipe,
						DataHelper.ReplaceWithType, index, ORK.CraftingRecipes.Count);
				}
			}
			else if(ORKDataType.CraftingType == type)
			{
				if(text.Contains(TextCode.CraftingType))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.CraftingType,
						DataHelper.ReplaceNoType, index, ORK.CraftingTypes.Count);
				}
			}
			else if(ORKDataType.Weapon == type)
			{
				if(text.Contains(TextCode.Weapon))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.Weapon,
						DataHelper.ReplaceInInventoryEquipped, index, ORK.Weapons.Count);
				}
			}
			else if(ORKDataType.Armor == type)
			{
				if(text.Contains(TextCode.Armor))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.Armor,
						DataHelper.ReplaceInInventoryEquipped, index, ORK.Armors.Count);
				}
			}
			else if(ORKDataType.EquipmentPart == type)
			{
				if(text.Contains(TextCode.EquipmentPart))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.EquipmentPart,
						DataHelper.ReplaceNoType, index, ORK.EquipmentParts.Count);
				}
			}
			else if(ORKDataType.Ability == type)
			{
				if(text.Contains(TextCode.Ability))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.Ability,
						DataHelper.ReplaceWithType, index, ORK.Abilities.Count);
				}
			}
			else if(ORKDataType.AbilityType == type)
			{
				if(text.Contains(TextCode.AbilityType))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.AbilityType,
						DataHelper.ReplaceNoType, index, ORK.AbilityTypes.Count);
				}
			}
			else if(ORKDataType.AbilityTree == type)
			{
				if(text.Contains(TextCode.AbilityTree))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.AbilityTree,
						DataHelper.ReplaceNoType, index, ORK.AbilityTrees.Count);
				}
			}
			else if(ORKDataType.Log == type)
			{
				if(text.Contains(TextCode.Log))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.Log,
						DataHelper.ReplaceWithType, index, ORK.Logs.Count);
				}
			}
			else if(ORKDataType.LogType == type)
			{
				if(text.Contains(TextCode.LogType))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.LogType,
						DataHelper.ReplaceNoType, index, ORK.LogTypes.Count);
				}
			}
			else if(ORKDataType.LogText == type)
			{
				if(text.Contains(TextCode.LogText))
				{
					DataHelper.DoRemoveFromString(ref text, new string[] { TextCode.LogText },
						index, ORK.LogTexts.Count);
				}
			}
			else if(ORKDataType.Quest == type)
			{
				if(text.Contains(TextCode.Quest))
				{
					DataHelper.DoRemoveFromString(ref text, new string[] {
						TextCode.QuestName, TextCode.QuestShortName, TextCode.QuestDescription, TextCode.QuestIcon,
						TextCode.Quest_TypeName, TextCode.Quest_TypeShortName, TextCode.Quest_TypeDescription, TextCode.Quest_TypeIcon,
						TextCode.QuestText
					}, index, ORK.Quests.Count);
				}
			}
			else if(ORKDataType.QuestType == type)
			{
				if(text.Contains(TextCode.QuestType))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.QuestType,
						DataHelper.ReplaceNoType, index, ORK.QuestTypes.Count);
				}
			}
			else if(ORKDataType.QuestTask == type)
			{
				if(text.Contains(TextCode.QuestTask))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.QuestTask,
						DataHelper.ReplaceNoType, index, ORK.QuestTasks.Count);
				}
			}
			else if(ORKDataType.SceneObjectType == type)
			{
				if(text.Contains(TextCode.SceneObjectType))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.SceneObjectType,
						DataHelper.ReplaceNoType, index, ORK.SceneObjectTypes.Count);
				}
			}
			else if(ORKDataType.SceneObject == type)
			{
				if(text.Contains(TextCode.SceneObject))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.SceneObject,
						DataHelper.ReplaceWithType, index, ORK.SceneObjects.Count);
				}
			}
			else if(ORKDataType.Shop == type)
			{
				if(text.Contains(TextCode.Shop))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.Shop,
						DataHelper.ReplaceNoType, index, ORK.Shops.Count);
				}
			}
			else if(ORKDataType.StatusType == type)
			{
				if(text.Contains(TextCode.StatusType))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.StatusType,
						DataHelper.ReplaceNoType, index, ORK.StatusTypes.Count);
				}
			}
			else if(ORKDataType.StatusValue == type)
			{
				if(text.Contains(TextCode.StatusValue))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.StatusValue,
						DataHelper.ReplaceWithType, index, ORK.StatusValues.Count);
				}
			}
			else if(ORKDataType.StatusEffectType == type)
			{
				if(text.Contains(TextCode.StatusEffectType))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.StatusEffectType,
						DataHelper.ReplaceNoType, index, ORK.StatusEffectTypes.Count);
				}
			}
			else if(ORKDataType.StatusEffect == type)
			{
				if(text.Contains(TextCode.StatusEffect))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.StatusEffect,
						DataHelper.ReplaceWithType, index, ORK.StatusEffects.Count);
				}
			}
			else if(ORKDataType.AttackAttributes == type)
			{
				if(text.Contains(TextCode.AttackAttribute))
				{
					if(index2 == -1)
					{
						DataHelper.DoRemoveFromString(ref text, new string[] {
							TextCode.AttackAttributeName, TextCode.AttackAttributeShortName,
							TextCode.AttackAttributeDescription, TextCode.AttackAttributeIcon,
							TextCode.AttackAttributeSubName, TextCode.AttackAttributeSubShortName,
							TextCode.AttackAttributeSubDescription, TextCode.AttackAttributeSubIcon
						}, index, ORK.AttackAttributes.Count);
					}
					else
					{
						DataHelper.DoRemoveFromString(ref text, new string[] {
							TextCode.AttackAttributeSubName + index + "#",
							TextCode.AttackAttributeSubShortName + index + "#",
							TextCode.AttackAttributeSubDescription + index + "#",
							TextCode.AttackAttributeSubIcon + index + "#"
						}, index2, ORK.AttackAttributes.AttributeCount(index));
					}
				}
			}
			else if(ORKDataType.DefenceAttributes == type)
			{
				if(text.Contains(TextCode.DefenceAttribute))
				{
					if(index2 == -1)
					{
						DataHelper.DoRemoveFromString(ref text, new string[] {
							TextCode.DefenceAttributeName, TextCode.DefenceAttributeShortName,
							TextCode.DefenceAttributeDescription, TextCode.DefenceAttributeIcon,
							TextCode.DefenceAttributeSubName, TextCode.DefenceAttributeSubShortName,
							TextCode.DefenceAttributeSubDescription, TextCode.DefenceAttributeSubIcon
						}, index, ORK.DefenceAttributes.Count);
					}
					else
					{
						DataHelper.DoRemoveFromString(ref text, new string[] {
							TextCode.DefenceAttributeSubName + index + "#",
							TextCode.DefenceAttributeSubShortName + index + "#",
							TextCode.DefenceAttributeSubDescription + index + "#",
							TextCode.DefenceAttributeSubIcon + index + "#"
						}, index2, ORK.DefenceAttributes.AttributeCount(index));
					}
				}
			}
			else if(ORKDataType.Class == type)
			{
				if(text.Contains(TextCode.Class))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.Class,
						DataHelper.ReplaceNoType, index, ORK.Classes.Count);
				}
			}
			else if(ORKDataType.CombatantType == type)
			{
				if(text.Contains(TextCode.CombatantType))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.CombatantType,
						DataHelper.ReplaceNoType, index, ORK.CombatantTypes.Count);
				}
			}
			else if(ORKDataType.Combatant == type)
			{
				if(text.Contains(TextCode.Combatant))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.Combatant,
						DataHelper.ReplaceWithType, index, ORK.Combatants.Count);
				}
			}
			else if(ORKDataType.AIType == type)
			{
				if(text.Contains(TextCode.AIType))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.AIType,
						DataHelper.ReplaceNoType, index, ORK.AITypes.Count);
				}
			}
			else if(ORKDataType.AIBehaviour == type)
			{
				if(text.Contains(TextCode.AIBehaviour))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.AIBehaviour,
						DataHelper.ReplaceInInventoryEquipped, index, ORK.AIBehaviours.Count);
				}
			}
			else if(ORKDataType.AIRuleset == type)
			{
				if(text.Contains(TextCode.AIRuleset))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.AIRuleset,
						DataHelper.ReplaceInInventoryEquipped, index, ORK.AIRulesets.Count);
				}
			}
			else if(ORKDataType.BattleGridCellType == type)
			{
				if(text.Contains(TextCode.BattleGridCell))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.BattleGridCell,
						DataHelper.ReplaceNoType, index, ORK.BattleGridCellTypes.Count);
				}
			}
			else if(ORKDataType.ResearchType == type)
			{
				if(text.Contains(TextCode.ResearchType))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.ResearchType,
						DataHelper.ReplaceNoType, index, ORK.ResearchTypes.Count);
				}
			}
			else if(ORKDataType.ResearchTree == type)
			{
				if(text.Contains(TextCode.ResearchTree))
				{
					if(index2 == -1)
					{
						DataHelper.DoRemoveFromString(ref text, new string[] {
							TextCode.ResearchTreeName, TextCode.ResearchTreeShortName,
							TextCode.ResearchTreeDescription, TextCode.ResearchTreeIcon,
							TextCode.ResearchTree_TypeName, TextCode.ResearchTree_TypeShortName,
							TextCode.ResearchTree_TypeDescription, TextCode.ResearchTree_TypeIcon,
							TextCode.ResearchItemName, TextCode.ResearchItemShortName,
							TextCode.ResearchItemDescription, TextCode.ResearchItemIcon
						}, index, ORK.AttackAttributes.Count);
					}
					else
					{
						DataHelper.DoRemoveFromString(ref text, new string[] {
							TextCode.ResearchItemName + index + "#",
							TextCode.ResearchItemShortName + index + "#",
							TextCode.ResearchItemDescription + index + "#",
							TextCode.ResearchItemIcon + index + "#"
						}, index2, ORK.AttackAttributes.AttributeCount(index));
					}
				}
			}
			else if(ORKDataType.Faction == type)
			{
				if(text.Contains(TextCode.Faction))
				{
					DataHelper.DoRemoveFromString(ref text, new string[] {
						TextCode.FactionName, TextCode.FactionShortName,
						TextCode.FactionDescription, TextCode.FactionIcon,
						TextCode.FactionSympathy, TextCode.FactionISympathy,
						TextCode.Faction_BenefitName, TextCode.Faction_BenefitShortName,
						TextCode.Faction_BenefitDescription, TextCode.Faction_BenefitIcon
					}, index, ORK.Factions.Count);
					for(int i = 0; i < ORK.Factions.Count; i++)
					{
						DataHelper.DoRemoveFromString(ref text, new string[] {
							TextCode.FactionSympathy + i + "#",
							TextCode.FactionISympathy + i + "#",
							TextCode.Faction_BenefitName + i + "#",
							TextCode.Faction_BenefitShortName + i + "#",
							TextCode.Faction_BenefitDescription + i + "#",
							TextCode.Faction_BenefitIcon + i + "#"
						}, index, ORK.Factions.Count);
					}
				}
			}
			else if(ORKDataType.FactionBenefit == type)
			{
				if(text.Contains(TextCode.FactionBenefit))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.FactionBenefit,
						DataHelper.ReplaceNoType, index, ORK.FactionBenefits.Count);
				}
			}
			else if(ORKDataType.ConsoleType == type)
			{
				if(text.Contains(TextCode.ConsoleType))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.ConsoleType,
						DataHelper.ReplaceNoType, index, ORK.ConsoleTypes.Count);
				}
			}
			else if(ORKDataType.Difficulty == type)
			{
				if(text.Contains(TextCode.Difficulty))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.Difficulty,
						DataHelper.ReplaceNoType, index, ORK.Difficulties.Count);
				}
			}
			else if(ORKDataType.Language == type)
			{
				if(text.Contains(TextCode.Language))
				{
					DataHelper.DoRemoveFromString(ref text, TextCode.Language,
						DataHelper.ReplaceNoType, index, ORK.Languages.Count);
				}
			}
		}

		private static void DoRemoveFromString(ref string text, string[] code, int index, int count)
		{
			for(int i = 0; i < code.Length; i++)
			{
				text = text.Replace(code[i] + index + "#", code[i] + "0#");
				for(int j = index + 1; j <= count; j++)
				{
					text = text.Replace(code[i] + j + "#", code[i] + (j - 1) + "#");
				}
			}
		}

		private static void DoRemoveFromString(ref string text, string header, string[] code, int index, int count)
		{
			for(int i = 0; i < code.Length; i++)
			{
				text = text.Replace(header + code[i] + index + "#", header + code[i] + "0#");
				for(int j = index + 1; j <= count; j++)
				{
					text = text.Replace(header + code[i] + j + "#", header + code[i] + (j - 1) + "#");
				}
			}
		}

		private static void SwapInString(ref string text, ORKDataType type, bool down, int index, int index2)
		{
			if(ORKDataType.Area == type)
			{
				if(text.Contains(TextCode.Area))
				{
					DataHelper.DoSwapInString(ref text, TextCode.Area,
						DataHelper.ReplaceWithType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.AreaType == type)
			{
				if(text.Contains(TextCode.AreaType))
				{
					DataHelper.DoSwapInString(ref text, TextCode.AreaType,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.Teleport == type)
			{
				if(text.Contains(TextCode.Teleport))
				{
					DataHelper.DoSwapInString(ref text, TextCode.Teleport,
						DataHelper.ReplaceWithType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.Currency == type)
			{
				if(text.Contains(TextCode.Currency))
				{
					DataHelper.DoSwapInString(ref text, TextCode.Currency,
						DataHelper.ReplaceInInventory, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.Item == type)
			{
				if(text.Contains(TextCode.Item))
				{
					DataHelper.DoSwapInString(ref text, TextCode.Item,
						DataHelper.ReplaceInInventory, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.ItemType == type)
			{
				if(text.Contains(TextCode.ItemType))
				{
					DataHelper.DoSwapInString(ref text, TextCode.ItemType,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.CraftingRecipe == type)
			{
				if(text.Contains(TextCode.CraftingRecipe))
				{
					DataHelper.DoSwapInString(ref text, TextCode.CraftingRecipe,
						DataHelper.ReplaceWithType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.CraftingType == type)
			{
				if(text.Contains(TextCode.CraftingType))
				{
					DataHelper.DoSwapInString(ref text, TextCode.CraftingType,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.Weapon == type)
			{
				if(text.Contains(TextCode.Weapon))
				{
					DataHelper.DoSwapInString(ref text, TextCode.Weapon,
						DataHelper.ReplaceInInventoryEquipped, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.Armor == type)
			{
				if(text.Contains(TextCode.Armor))
				{
					DataHelper.DoSwapInString(ref text, TextCode.Armor,
						DataHelper.ReplaceInInventoryEquipped, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.EquipmentPart == type)
			{
				if(text.Contains(TextCode.EquipmentPart))
				{
					DataHelper.DoSwapInString(ref text, TextCode.EquipmentPart,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.Ability == type)
			{
				if(text.Contains(TextCode.Ability))
				{
					DataHelper.DoSwapInString(ref text, TextCode.Ability,
						DataHelper.ReplaceWithType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.AbilityType == type)
			{
				if(text.Contains(TextCode.AbilityType))
				{
					DataHelper.DoSwapInString(ref text, TextCode.AbilityType,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.AbilityTree == type)
			{
				if(text.Contains(TextCode.AbilityTree))
				{
					DataHelper.DoSwapInString(ref text, TextCode.AbilityTree,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.Log == type)
			{
				if(text.Contains(TextCode.Log))
				{
					DataHelper.DoSwapInString(ref text, TextCode.Log,
						DataHelper.ReplaceWithType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.LogType == type)
			{
				if(text.Contains(TextCode.LogType))
				{
					DataHelper.DoSwapInString(ref text, TextCode.LogType,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.LogText == type)
			{
				if(text.Contains(TextCode.LogText))
				{
					DataHelper.DoSwapInString(ref text, new string[] { TextCode.LogText },
						index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.Quest == type)
			{
				if(text.Contains(TextCode.Quest))
				{
					DataHelper.DoSwapInString(ref text, new string[] {
						TextCode.QuestName, TextCode.QuestShortName, TextCode.QuestDescription, TextCode.QuestIcon,
						TextCode.Quest_TypeName, TextCode.Quest_TypeShortName, TextCode.Quest_TypeDescription, TextCode.Quest_TypeIcon,
						TextCode.QuestText
					}, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.QuestType == type)
			{
				if(text.Contains(TextCode.QuestType))
				{
					DataHelper.DoSwapInString(ref text, TextCode.QuestType,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.QuestTask == type)
			{
				if(text.Contains(TextCode.QuestTask))
				{
					DataHelper.DoSwapInString(ref text, TextCode.QuestTask,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.SceneObjectType == type)
			{
				if(text.Contains(TextCode.SceneObjectType))
				{
					DataHelper.DoSwapInString(ref text, TextCode.SceneObjectType,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.SceneObject == type)
			{
				if(text.Contains(TextCode.SceneObject))
				{
					DataHelper.DoSwapInString(ref text, TextCode.SceneObject,
						DataHelper.ReplaceWithType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.Shop == type)
			{
				if(text.Contains(TextCode.Shop))
				{
					DataHelper.DoSwapInString(ref text, TextCode.Shop,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.StatusType == type)
			{
				if(text.Contains(TextCode.StatusType))
				{
					DataHelper.DoSwapInString(ref text, TextCode.StatusType,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.StatusValue == type)
			{
				if(text.Contains(TextCode.StatusValue))
				{
					DataHelper.DoSwapInString(ref text, TextCode.StatusValue,
						DataHelper.ReplaceWithType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.StatusEffectType == type)
			{
				if(text.Contains(TextCode.StatusEffectType))
				{
					DataHelper.DoSwapInString(ref text, TextCode.StatusEffectType,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.StatusEffect == type)
			{
				if(text.Contains(TextCode.StatusEffect))
				{
					DataHelper.DoSwapInString(ref text, TextCode.StatusEffect,
						DataHelper.ReplaceWithType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.AttackAttributes == type)
			{
				if(text.Contains(TextCode.AttackAttribute))
				{
					if(index2 == -1)
					{
						DataHelper.DoSwapInString(ref text, new string[] {
							TextCode.AttackAttributeName, TextCode.AttackAttributeShortName,
							TextCode.AttackAttributeDescription, TextCode.AttackAttributeIcon,
							TextCode.AttackAttributeSubName, TextCode.AttackAttributeSubShortName,
							TextCode.AttackAttributeSubDescription, TextCode.AttackAttributeSubIcon
						}, index, down ? index + 1 : index - 1);
					}
					else
					{
						DataHelper.DoSwapInString(ref text, new string[] {
							TextCode.AttackAttributeSubName + index + "#",
							TextCode.AttackAttributeSubShortName + index + "#",
							TextCode.AttackAttributeSubDescription + index + "#",
							TextCode.AttackAttributeSubIcon + index + "#"
						}, index2, down ? index2 + 1 : index2 - 1);
					}
				}
			}
			else if(ORKDataType.DefenceAttributes == type)
			{
				if(text.Contains(TextCode.DefenceAttribute))
				{
					if(index2 == -1)
					{
						DataHelper.DoSwapInString(ref text, new string[] {
							TextCode.DefenceAttributeName, TextCode.DefenceAttributeShortName,
							TextCode.DefenceAttributeDescription, TextCode.DefenceAttributeIcon,
							TextCode.DefenceAttributeSubName, TextCode.DefenceAttributeSubShortName,
							TextCode.DefenceAttributeSubDescription, TextCode.DefenceAttributeSubIcon
						}, index, down ? index + 1 : index - 1);
					}
					else
					{
						DataHelper.DoSwapInString(ref text, new string[] {
							TextCode.DefenceAttributeSubName + index + "#",
							TextCode.DefenceAttributeSubShortName + index + "#",
							TextCode.DefenceAttributeSubDescription + index + "#",
							TextCode.DefenceAttributeSubIcon + index + "#"
						}, index2, down ? index2 + 1 : index2 - 1);
					}
				}
			}
			else if(ORKDataType.Class == type)
			{
				if(text.Contains(TextCode.Class))
				{
					DataHelper.DoSwapInString(ref text, TextCode.Class,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.CombatantType == type)
			{
				if(text.Contains(TextCode.CombatantType))
				{
					DataHelper.DoSwapInString(ref text, TextCode.CombatantType,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.Combatant == type)
			{
				if(text.Contains(TextCode.Combatant))
				{
					DataHelper.DoSwapInString(ref text, TextCode.Combatant,
						DataHelper.ReplaceWithType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.ResearchType == type)
			{
				if(text.Contains(TextCode.ResearchType))
				{
					DataHelper.DoSwapInString(ref text, TextCode.ResearchType,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.ResearchTree == type)
			{
				if(text.Contains(TextCode.ResearchTree))
				{
					DataHelper.DoSwapInString(ref text, TextCode.ResearchTree,
						DataHelper.ReplaceWithType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.ResearchTree == type)
			{
				if(text.Contains(TextCode.ResearchTree))
				{
					if(index2 == -1)
					{
						DataHelper.DoSwapInString(ref text, new string[] {
							TextCode.ResearchTreeName, TextCode.ResearchTreeShortName,
							TextCode.ResearchTreeDescription, TextCode.ResearchTreeIcon,
							TextCode.ResearchTree_TypeName, TextCode.ResearchTree_TypeShortName,
							TextCode.ResearchTree_TypeDescription, TextCode.ResearchTree_TypeIcon,
							TextCode.ResearchItemName, TextCode.ResearchItemShortName,
							TextCode.ResearchItemDescription, TextCode.ResearchItemIcon
						}, index, down ? index + 1 : index - 1);
					}
					else
					{
						DataHelper.DoSwapInString(ref text, new string[] {
							TextCode.ResearchItemName + index + "#",
							TextCode.ResearchItemShortName + index + "#",
							TextCode.ResearchItemDescription + index + "#",
							TextCode.ResearchItemIcon + index + "#"
						}, index2, down ? index2 + 1 : index2 - 1);
					}
				}
			}
			else if(ORKDataType.AIType == type)
			{
				if(text.Contains(TextCode.AIType))
				{
					DataHelper.DoSwapInString(ref text, TextCode.AIType,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.AIBehaviour == type)
			{
				if(text.Contains(TextCode.AIBehaviour))
				{
					DataHelper.DoSwapInString(ref text, TextCode.AIBehaviour,
						DataHelper.ReplaceInInventoryEquipped, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.AIRuleset == type)
			{
				if(text.Contains(TextCode.AIRuleset))
				{
					DataHelper.DoSwapInString(ref text, TextCode.AIRuleset,
						DataHelper.ReplaceInInventoryEquipped, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.BattleGridCellType == type)
			{
				if(text.Contains(TextCode.BattleGridCell))
				{
					DataHelper.DoSwapInString(ref text, TextCode.BattleGridCell,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.Faction == type)
			{
				if(text.Contains(TextCode.Faction))
				{
					DataHelper.DoSwapInString(ref text, new string[] {
						TextCode.FactionName, TextCode.FactionShortName,
						TextCode.FactionDescription, TextCode.FactionIcon,
						TextCode.FactionSympathy, TextCode.FactionISympathy,
						TextCode.Faction_BenefitName, TextCode.Faction_BenefitShortName,
						TextCode.Faction_BenefitDescription, TextCode.Faction_BenefitIcon
					}, index, down ? index + 1 : index - 1);
					for(int i = 0; i < ORK.Factions.Count; i++)
					{
						DataHelper.DoSwapInString(ref text, new string[] {
							TextCode.FactionSympathy + i + "#",
							TextCode.FactionISympathy + i + "#",
							TextCode.Faction_BenefitName + i + "#",
							TextCode.Faction_BenefitShortName + i + "#",
							TextCode.Faction_BenefitDescription + i + "#",
							TextCode.Faction_BenefitIcon + i + "#"
						}, index, down ? index + 1 : index - 1);
					}
				}
			}
			else if(ORKDataType.FactionBenefit == type)
			{
				if(text.Contains(TextCode.FactionBenefit))
				{
					DataHelper.DoSwapInString(ref text, TextCode.FactionBenefit,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.ConsoleType == type)
			{
				if(text.Contains(TextCode.ConsoleType))
				{
					DataHelper.DoSwapInString(ref text, TextCode.ConsoleType,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.Difficulty == type)
			{
				if(text.Contains(TextCode.Difficulty))
				{
					DataHelper.DoSwapInString(ref text, TextCode.Difficulty,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.Language == type)
			{
				if(text.Contains(TextCode.Language))
				{
					DataHelper.DoSwapInString(ref text, TextCode.Language,
						DataHelper.ReplaceNoType, index, down ? index + 1 : index - 1);
				}

			}
		}

		private static void DoSwapInString(ref string text, string[] code, int index, int index2)
		{
			for(int i = 0; i < code.Length; i++)
			{
				text = text.Replace(code[i] + index + "#", "#TMP#");
				text = text.Replace(code[i] + index2 + "#", code[i] + index + "#");
				text = text.Replace("#TMP#", code[i] + index2 + "#");
			}
		}

		private static void DoSwapInString(ref string text, string header, string[] code, int index, int index2)
		{
			for(int i = 0; i < code.Length; i++)
			{
				text = text.Replace(header + code[i] + index + "#", "#TMP#");
				text = text.Replace(header + code[i] + index2 + "#", header + code[i] + index + "#");
				text = text.Replace("#TMP#", header + code[i] + index2 + "#");
			}
		}
	}
}
