
using UnityEngine;
using ORKFramework.Events;
using System.Reflection;

namespace ORKFramework.Reflection
{
	public class EventCheckMethod : BaseData
	{
		[ORKEditorHelp("Function Name", "The name of the function that will be called.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string functionName = "";


		// return value
		[ORKEditorHelp("Return Value Type", "Select the type of the return value.", "")]
		public ParameterType type = ParameterType.String;

		[ORKEditorInfo(separator=true, labelText="String Value", expandWidth=true)]
		[ORKEditorLayout("type", ParameterType.String, endCheckGroup=true)]
		public EventString stringValue = new EventString();

		[ORKEditorHelp("Bool Value", "Define the bool the field will be set to.", "")]
		[ORKEditorLayout("type", ParameterType.Bool, endCheckGroup=true)]
		public bool boolValue = false;

		[ORKEditorInfo(separator=true, labelText="Int Value")]
		[ORKEditorLayout("type", ParameterType.Int, endCheckGroup=true)]
		public EventInteger intValue = new EventInteger();

		[ORKEditorInfo(separator=true, labelText="Float Value")]
		[ORKEditorLayout("type", ParameterType.Float, endCheckGroup=true)]
		public EventFloat floatValue = new EventFloat();

		[ORKEditorInfo(separator=true, labelText="Vector Value")]
		[ORKEditorLayout(new string[] { "type", "type" },
			new object[] { ParameterType.Vector2, ParameterType.Vector3 },
			needed=Needed.One, endCheckGroup=true)]
		public EventVector3 vectorValue = new EventVector3();


		// parameters
		[ORKEditorArray(false, "Add Parameter", "Adds a parameter that will be used when calling the function.", "",
			"Remove", "Removes this parameter.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {"Parameter", "The parameter will be used when calling the function.", ""})]
		public EventCallParameter[] parameter = new EventCallParameter[0];

		public EventCheckMethod()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<string>("stringValue"))
			{
				if(ParameterType.String == this.type)
				{
					data.Get("stringValue", ref this.stringValue.value);
				}
				else if(ParameterType.Int == this.type)
				{
					data.Get("intValue", ref this.intValue.value);
				}
				else if(ParameterType.Float == this.type)
				{
					data.Get("floatValue", ref this.floatValue.value);
				}
				else if(ParameterType.Vector2 == this.type)
				{
					float[] tmp;
					data.Get("vector2Value", out tmp);
					if(tmp != null)
					{
						this.vectorValue.value = ArrayHelper.GetVector2(tmp);
					}
				}
				else if(ParameterType.Vector3 == this.type)
				{
					float[] tmp;
					data.Get("vector3Value", out tmp);
					if(tmp != null)
					{
						this.vectorValue.value = ArrayHelper.GetVector3(tmp);
					}
				}
			}
		}

		public object GetValue(BaseEvent baseEvent)
		{
			if(ParameterType.String == this.type)
			{
				return this.stringValue.GetValue(baseEvent);
			}
			else if(ParameterType.Bool == this.type)
			{
				return this.boolValue;
			}
			else if(ParameterType.Int == this.type)
			{
				return this.intValue.GetValue(baseEvent);
			}
			else if(ParameterType.Float == this.type)
			{
				return this.floatValue.GetValue(baseEvent); ;
			}
			else if(ParameterType.Vector2 == this.type)
			{
				return this.vectorValue.GetValue(baseEvent);
			}
			else if(ParameterType.Vector3 == this.type)
			{
				return this.vectorValue.GetValue(baseEvent);
			}
			return null;
		}

		public bool Check(object instance, BaseEvent baseEvent)
		{
			if(instance != null && this.functionName != "")
			{
				if(this.parameter.Length > 0)
				{
					System.Type[] types = new System.Type[this.parameter.Length];
					object[] values = new object[this.parameter.Length];

					for(int i = 0; i < this.parameter.Length; i++)
					{
						types[i] = this.parameter[i].GetType();
						values[i] = this.parameter[i].GetValue(baseEvent);
					}

					MethodInfo methodInfo = instance.GetType().GetMethod(this.functionName, types);
					if(methodInfo != null)
					{
						try
						{
							object value = methodInfo.Invoke(instance, values);
							return value != null && value.Equals(this.GetValue(baseEvent));
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Method call failed (" + instance.GetType() + "): " +
								this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Method not found (" + instance.GetType() + "): " + this.functionName);
					}
				}
				else
				{
					MethodInfo methodInfo = instance.GetType().GetMethod(this.functionName, new System.Type[] {});
					if(methodInfo != null)
					{
						try
						{
							object value = methodInfo.Invoke(instance, null);
							return value != null && value.Equals(this.GetValue(baseEvent));
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Method call failed (" + instance.GetType() + "): " +
								this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Method not found (" + instance.GetType() + "): " + this.functionName);
					}
				}
			}
			return false;
		}

		public bool CheckStatic(string className, BaseEvent baseEvent)
		{
			if(className != "" && this.functionName != "")
			{
				System.Type classType = ORK.Core.TypeHandler.GetType(className);
				if(classType != null)
				{
					if(this.parameter.Length > 0)
					{
						System.Type[] types = new System.Type[this.parameter.Length];
						object[] values = new object[this.parameter.Length];

						for(int i = 0; i < this.parameter.Length; i++)
						{
							types[i] = this.parameter[i].GetType();
							values[i] = this.parameter[i].GetValue(baseEvent);
						}

						MethodInfo methodInfo = classType.GetMethod(this.functionName, types);
						if(methodInfo != null)
						{
							try
							{
								object value = methodInfo.Invoke(null, values);
								return value != null && value.Equals(this.GetValue(baseEvent));
							}
							catch(System.Exception ex)
							{
								Debug.LogWarning("Method call failed (" + classType + "): " +
									this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
							}
						}
						else
						{
							Debug.LogWarning("Method not found (" + classType + "): " + this.functionName);
						}
					}
					else
					{
						MethodInfo methodInfo = classType.GetMethod(this.functionName, new System.Type[] {});
						if(methodInfo != null)
						{
							try
							{
								object value = methodInfo.Invoke(null, null);
								return value != null && value.Equals(this.GetValue(baseEvent));
							}
							catch(System.Exception ex)
							{
								Debug.LogWarning("Method call failed (" + classType + "): " +
									this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
							}
						}
						else
						{
							Debug.LogWarning("Method not found (" + classType + "): " + this.functionName);
						}
					}
				}
				else
				{
					Debug.LogWarning("Class not found: " + className);
				}
			}
			return false;
		}
	}
}
