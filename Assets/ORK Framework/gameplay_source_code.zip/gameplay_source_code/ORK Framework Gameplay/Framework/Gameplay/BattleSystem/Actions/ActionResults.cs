
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ActionResults
	{
		public int hit = 0;

		public int critical = 0;

		public int miss = 0;

		public int block = 0;

		public List<Combatant> counter;

		public ActionResults()
		{

		}

		public BattleActionResult GetResult()
		{
			if(this.critical > 0 &&
				this.critical >= this.hit &&
				this.critical >= this.miss &&
				this.critical >= this.block)
			{
				return BattleActionResult.Critical;
			}
			else if(this.miss > 0 &&
				this.miss >= this.hit &&
				this.miss >= this.critical &&
				this.miss >= this.block)
			{
				return BattleActionResult.Miss;
			}
			else if(this.block > 0 &&
				this.block >= this.hit &&
				this.block >= this.critical &&
				this.block >= this.miss)
			{
				return BattleActionResult.Block;
			}
			return BattleActionResult.Hit;
		}

		public void AddCounter(Combatant combatant)
		{
			if(this.counter == null)
			{
				this.counter = new List<Combatant>();
			}
			if(!this.counter.Contains(combatant))
			{
				this.counter.Add(combatant);
			}
		}

		public void GetCounter(List<Combatant> list)
		{
			if(this.counter != null)
			{
				for(int i = 0; i < this.counter.Count; i++)
				{
					if(this.counter[i] != null &&
						!list.Contains(this.counter[i]))
					{
						list.Add(this.counter[i]);
					}
				}
			}
		}
	}
}
