
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ChangeMemberAction : BaseAction
	{
		private Combatant newUser = null;

		private bool membersChanged = false;

		public ChangeMemberAction(Combatant user, Combatant newUser)
		{
			this.user = user;
			this.newUser = newUser;
			this.target = new List<Combatant>();
			this.target.Add(user);

			this.actionCost = ORK.Battle.GetChangeMemberActionCost(this.user);

			this.CheckActionAffiliation();
		}

		public override bool IsType(ActionType t)
		{
			return ActionType.ChangeMember == t;
		}

		public override bool CanTarget(Combatant combatant)
		{
			return this.user == combatant ||
				this.newUser == combatant;
		}


		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		public override bool CanUse()
		{
			return this.user != null && !this.user.Status.IsDead &&
				!this.user.Status.Effects.BlockAllActions &&
				this.newUser != null && !this.newUser.Status.IsDead &&
				!this.newUser.Status.Effects.BlockAllActions;
		}

		public override void ActionAdded()
		{
			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleAddChangeMember)
				{
					this.user.Setting.consoleAddChangeMember.Print(this.user, this.newUser);
				}
				else
				{
					ORK.ConsoleSettings.actionAddChangeMember.Print(this.user, this.newUser);
				}
			}
		}

		protected override void ActionStartSetup()
		{
			if(ORK.BattleTexts.showInfo)
			{
				ORK.BattleTexts.changeMemberInfo.Show(this.user, this.newUser.GetName(), null);
			}

			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleChangeMember)
				{
					this.user.Setting.consoleChangeMember.Print(this.user, this.newUser);
				}
				else
				{
					ORK.ConsoleSettings.actionChangeMember.Print(this.user, this.newUser);
				}
			}

			this.newUser.Battle.StartBattle();

			this.user.GetBattleAnimation(BattleAnimationType.Retreat, ref this.events);
			this.newUser.GetBattleAnimation(BattleAnimationType.EnterBattle, ref this.events);
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate, ActionCalculationFinished notify)
		{
			if(!this.membersChanged && this.newUser != null)
			{
				if(ORK.Battle.BattleArena != null)
				{
					ORK.Battle.BattleArena.SetSpot(this.user, this.newUser);
				}
				this.newUser.Object.BattleSpot = this.user.Object.BattleSpot;
				this.newUser.Battle.ActionBar = this.user.Battle.ActionBar;
				this.newUser.Battle.UsedActionBar = this.user.Battle.UsedActionBar;
				this.newUser.Battle.TurnValue = this.user.Battle.TurnValue;
				this.newUser.Battle.TurnValueDummy = this.user.Battle.TurnValueDummy;

				ORK.Access.Group.ChangeBattle(this.user.Group, this.user, this.newUser);
				this.user.Battle.EndBattle();

				// notify battle
				ORK.Battle.CombatantChanged(this.user, this.newUser);

				this.membersChanged = true;

				Combatant tmp = this.user;
				this.user = this.newUser;
				this.newUser = tmp;
			}

			if(notify != null)
			{
				notify(null);
			}
		}

		protected override void ActionEndSetup()
		{

		}
	}
}
