﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public abstract class TargetRangeAction : BaseAction, ITargetRange
	{
		protected TargetRange targetRange = TargetRange.None;

		public virtual void SetTargetRange(ITargetRange targetRange)
		{
			if(targetRange.IsNoneTarget())
			{
				this.targetRange = TargetRange.None;
			}
			else if(targetRange.IsSingleTarget())
			{
				this.targetRange = TargetRange.Single;
			}
			else if(targetRange.IsGroupTarget())
			{
				this.targetRange = TargetRange.Group;
			}
		}


		/*
		============================================================================
		Target range functions
		============================================================================
		*/
		public bool IsNoneTarget()
		{
			return TargetRange.None == this.targetRange;
		}

		public bool IsSingleTarget()
		{
			return TargetRange.Single == this.targetRange;
		}

		public bool IsGroupTarget()
		{
			return TargetRange.Group == this.targetRange;
		}

		public bool ToggleTargetRange()
		{
			return false;
		}
	}
}
