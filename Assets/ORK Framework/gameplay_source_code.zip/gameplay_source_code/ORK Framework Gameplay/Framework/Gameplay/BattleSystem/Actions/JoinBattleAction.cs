
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class JoinBattleAction : BaseAction
	{
		public JoinBattleAction(Combatant user)
		{
			this.user = user;
			this.target = new List<Combatant>();
			this.target.Add(user);

			this.CheckActionAffiliation();
		}

		public override bool IsType(ActionType t)
		{
			return ActionType.Join == t;
		}


		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		public override bool CanUse()
		{
			return this.user != null;
		}

		public override void ActionAdded()
		{
			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleAddJoinBattle)
				{
					this.user.Setting.consoleAddJoinBattle.Print(this.user);
				}
				else
				{
					ORK.ConsoleSettings.actionAddJoinBattle.Print(this.user);
				}
			}
		}

		protected override void ActionStartSetup()
		{
			if(ORK.BattleTexts.showInfo)
			{
				ORK.BattleTexts.joinBattleInfo.Show(this.user, "", null);
			}

			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleJoinBattle)
				{
					this.user.Setting.consoleJoinBattle.Print(this.user);
				}
				else
				{
					ORK.ConsoleSettings.actionJoinBattle.Print(this.user);
				}
			}

			this.user.GetBattleAnimation(BattleAnimationType.JoinBattle, ref this.events);
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate, ActionCalculationFinished notify)
		{
			if(notify != null)
			{
				notify(null);
			}
		}

		protected override void ActionEndSetup()
		{

		}
	}
}
