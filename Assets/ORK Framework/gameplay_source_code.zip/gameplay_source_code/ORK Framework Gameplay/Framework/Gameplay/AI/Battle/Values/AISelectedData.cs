﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AISelectedData : AISelectedDataOrigin
	{
		[ORKEditorInfo(labelText="Selected Key")]
		public StringValue selectedKey = new StringValue();

		public AISelectedData()
		{

		}

		public string GetInfoText()
		{
			return this.selectedKey.GetInfoText() + "(" + this.origin.ToString() + ")";
		}

		public int GetCount(BattleAICall call)
		{
			return this.GetCount(call, this.selectedKey.GetValue());
		}

		public List<object> GetSelectedData(BattleAICall call)
		{
			return this.GetSelectedData(call, this.selectedKey.GetValue());
		}

		public void Change(BattleAICall call, object data, ListChangeType changeType)
		{
			this.Change(call, this.selectedKey.GetValue(), data, changeType);
		}
	}
}
