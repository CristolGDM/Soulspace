
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class IdleBehaviour : BaseData
	{
		[ORKEditorHelp("Move Event", "Select the move event that will be performed.", "")]
		public AssetSource<ORKMoveEvent> eventAsset = new AssetSource<ORKMoveEvent>();
		
		[ORKEditorHelp("Chance", "The chance this move event will be performed.\n" +
			"If the chance fails, no move event will be performed " +
			"(i.e. no other event will be selected out of the list)", "")]
		public float chance = 100;
		
		public IdleBehaviour()
		{
			
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			this.eventAsset.Upgrade(data, "eventAsset");
		}

		public ORKMoveEvent GetEvent()
		{
			if(ORK.GameSettings.CheckRandom(this.chance))
			{
				return this.eventAsset;
			}
			return null;
		}
	}
}
