
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class MoveDetection : BaseData
	{
		[ORKEditorHelp("Type", "Select how movement will be detected within the defined settings:\n" +
			"- Sight: The combatant only needs to be present.\n" +
			"- Movement: The combatants needs to move (requires a CharacterController or Rigidbody component).\n" +
			"- Combatant Trigger: The combatant needs to be within a combatant trigger of the user.", "")]
		public MoveDetectionType type = MoveDetectionType.Sight;


		// combatant triggers
		[ORKEditorLayout("type", MoveDetectionType.CombatantTrigger, autoInit=true)]
		public CombatantTriggerCheck combatantTrigger;


		// others
		[ORKEditorHelp("From Child", "The position of the defined child of the user's game object " +
			"will be used for range and angle checks.\n" +
			"If the child can't be found, the game object itself will be used.\n" +
			"Define the child as Path/To/Child, use / to separate game objects in the hierarchy.\n" +
			"Leave empty if no child object should be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true)]
		public string fromChild = "";


		// sight
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", MoveDetectionType.Sight, endCheckGroup=true)]
		public RaycastLOS raycastLOS = new RaycastLOS();


		// movement
		[ORKEditorHelp("Minimum Speed", "The minimum speed at which the combatant must move to be detected.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", MoveDetectionType.Movement)]
		[ORKEditorLimit(0.0f, false)]
		public float minSpeed = 1;

		[ORKEditorHelp("Horizontal Speed", "Only the horizontal speed will be used for the check.\n" +
			"If disabled, also the vertical speed (e.g. jumping) will be used.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool horizontalSpeed = false;


		// range
		[ORKEditorInfo(separator=true, labelText="Range Settings")]
		public Range range = new Range(20);


		// radius
		[ORKEditorHelp("Angle", "The angle (0 to 360) at which a combatant will be detected.\n" +
			"E.g. 180 will detect combatants at an angle of 90 degree to the left and right.", "")]
		[ORKEditorInfo(separator=true, labelText="Angle Settings")]
		[ORKEditorLimit(0.0f, 360.0f)]
		public float angle = 360;

		[ORKEditorHelp("Angle Offset", "The offset (-180 to 180) added to the angle, e.g.:\n" +
			"- 0 is front" +
			"- -90 is left" +
			"- 90 is right" +
			"- 180/-180 is back", "")]
		[ORKEditorLimit(-180.0f, 180.0f)]
		public float angleOffset = 0;

		[ORKEditorHelp("Horizontal Plane", "Select the horizontal plane (i.e. which axes are used for horizontal movement):\n" +
			"- XZ: The game objects are moving on the XZ plane horizontally, i.e. default 3D behaviour.\n" +
			"- XY: The game objects are moving on the XY plane horizontally, i.e. default 2D behaviour.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public HorizontalPlaneType horizontalPlane = HorizontalPlaneType.XZ;

		public MoveDetection()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useRaycast"))
			{
				data.Get("useRaycast", ref this.raycastLOS.useRaycast);
				int tmp = -1;
				data.Get("rayLayerMask", ref tmp);
				this.raycastLOS.layerMask.value = tmp;
				data.Get("rayChildName", ref this.raycastLOS.childNameUser);
				data.Get("rayChildTarget", ref this.raycastLOS.childNameTarget);
			}
		}


		/*
		============================================================================
		Detection functions
		============================================================================
		*/
		public bool Detected(Combatant owner, Combatant target)
		{
			if(owner != null && owner.GameObject != null &&
				target != null && target.GameObject != null)
			{
				if(MoveDetectionType.CombatantTrigger == this.type)
				{
					return this.combatantTrigger.Check(owner, target);
				}
				else
				{
					Transform ownerTransform = TransformHelper.GetChild(this.fromChild, owner.GameObject.transform);
					if(this.range.InRange(ownerTransform.position, target))
					{
						// absolute value of the angle
						float tmpAngle = Mathf.Abs(VectorHelper.HorizontalAngle(ownerTransform,
						target.GameObject.transform.position, this.horizontalPlane) - this.angleOffset);
						// angle to the left and right
						if(tmpAngle <= this.angle / 2)
						{
							if(MoveDetectionType.Sight == this.type)
							{
								return this.raycastLOS.Check(owner.GameObject, target.GameObject);
							}
							else if(MoveDetectionType.Movement == this.type)
							{
								CharacterController cc = target.GameObject.GetComponent<CharacterController>();
								if(cc != null)
								{
									if(this.horizontalSpeed)
									{
										return new Vector3(cc.velocity.x, 0, cc.velocity.z).magnitude >= this.minSpeed;
									}
									else
									{
										return cc.velocity.magnitude >= this.minSpeed;
									}
								}
								else
								{
									Rigidbody rb = target.GameObject.GetComponent<Rigidbody>();
									if(rb != null)
									{
										if(this.horizontalSpeed)
										{
											return new Vector3(rb.velocity.x, 0, rb.velocity.z).magnitude >= this.minSpeed;
										}
										else
										{
											return rb.velocity.magnitude >= this.minSpeed;
										}
									}
								}
							}
						}
					}
				}
			}
			return false;
		}
	}
}
