
using UnityEngine;
using ORKFramework.AI.Steps;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AIFloat : BaseData
	{
		[ORKEditorHelp("Value Type", "Select which kind of value will be used:\n" +
			"- Value: A defined value.\n" +
			"- Game Variable: The value of a game variable (float).\n" +
			"- Player Prefs: The value of a PlayerPrefs (int or float) variable.\n" +
			"- Formula: The result of a formula.\n" +
			"- Game Time: The current game time in seconds (time since 'New Game').\n" +
			"- Time Of Day: The current real time since midnight in seconds.\n" +
			"- Date And Time: The current real date and time in seconds (since 1-1-1970).\n" +
			"- Random: A random value between two defined values.", "")]
		public NumberValueType type = NumberValueType.Value;


		// variable
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("type", NumberValueType.GameVariable)]
		public AIVariableOrigin variableOrigin = new AIVariableOrigin();

		[ORKEditorHelp("Multi Value Use", "Select how values of multiple variable sources will be used:\n" +
			"- First: Use the first available value.\n" +
			"- Lowest: Use the lowest available value.\n" +
			"- Highest: Use the highest available value.\n" +
			"- Average: Use the average of all available values.\n" +
			"- Add: Sum all available values (i.e. value1 + value 2 + value3 ...).\n" +
			"- Sub: Subtract all available values (i.e. value1 - value2 - value3 ...).\n" +
			"- Multiply: Multiply all available values (i.e. value1 * value2 * value3 ...).\n" +
			"- Divide: Divide all available values (i.e. value1 / value2 / value3 ...).", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout(new string[] { "variableOrigin.origin", "variableOrigin.origin"},
			new System.Object[] { VariableOrigin.Object, VariableOrigin.Selected},
			needed=Needed.One, endCheckGroup=true, endGroups=2)]
		public MultiFloatValueUse multiVariableUseType = MultiFloatValueUse.First;


		// variable and player prefs
		[ORKEditorHelp("Variable Key", "The key (name) of the game variable (float) or PlayerPrefs that contains the value.", "")]
		[ORKEditorInfo(indent=true, expandWidth=true, isVariableField=true)]
		[ORKEditorLayout(new string[] { "type", "type" },
			new System.Object[] { NumberValueType.GameVariable, NumberValueType.PlayerPrefs },
			needed=Needed.One, endCheckGroup=true)]
		public string name = "";

		[ORKEditorHelp("Is Int", "The value will be taken from an Integer PlayerPrefs (using GetInt).\n" +
			"If disabled, the value will be taken from a Float PlayerPrefs (using GetFloat).", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("type", NumberValueType.PlayerPrefs, endCheckGroup=true)]
		public bool isInt = false;


		// formula
		[ORKEditorHelp("Formula", "Select the formula used for calculation.", "")]
		[ORKEditorInfo(ORKDataType.Formula)]
		[ORKEditorLayout("type", NumberValueType.Formula)]
		public int id = 0;

		[ORKEditorHelp("Initial Value", "The initial value passed to the formula.\n" +
			"The formula will use the initial value as it's base and start the calculation with that value.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float initialValue = 0;


		// game time offset
		[ORKEditorHelp("Time Offset (s)", "The offset time in seconds that will be added to the current game time.", "")]
		[ORKEditorLayout(new string[] { "type", "type", "type", "type" },
			new System.Object[] { NumberValueType.GameTime, NumberValueType.TimeOfDay,
				NumberValueType.DateAndTime, NumberValueType.DeltaTime },
			needed=Needed.One, endCheckGroup=true)]
		public float offset = 0;

		[ORKEditorHelp("Is UTC", "The date and time are in UTC format.\n" +
			"If disabled, the local date and time is used.", "")]
		[ORKEditorLayout("type", NumberValueType.DateAndTime, endCheckGroup=true)]
		public bool isUTC = false;


		// value
		[ORKEditorHelp("Value", "Define the value that will be used.", "")]
		[ORKEditorLayout(new string[] {"type", "type"},
			new System.Object[] {NumberValueType.Value, NumberValueType.Random},
			needed=Needed.One, endCheckGroup=true)]
		public float value = 0;

		[ORKEditorHelp("Value 2", "Define the value that will be used.", "")]
		[ORKEditorLimit("value", false)]
		[ORKEditorLayout("type", NumberValueType.Random, endCheckGroup=true)]
		public float value2 = 0;


		// rounding
		[ORKEditorHelp("Rounding", "Rounds the value of the formula or game variable.\n"+
			"- None: No rounding.\n"+
			"- Ceil: The value will be rounded up (e.g. 14.2 will become 15).\n"+
			"- Floor: The value will be rounded down (e.g. 14.8 will become 14).\n"+
			"- Round: The value will be rounded to the nearest integer (e.g. 14.2 will become 14, 14.8 will become 15).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("type", NumberValueType.Value, elseCheckGroup=true, endCheckGroup=true)]
		public Rounding rounding = Rounding.None;

		public AIFloat()
		{

		}

		public AIFloat(float value)
		{
			this.value = value;
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("origin"))
			{
				this.variableOrigin.SetData(data);
			}
		}

		public float GetValue(BattleAICall call, Combatant user, Combatant target)
		{
			if(NumberValueType.Value == this.type)
			{
				return this.value;
			}
			else if(NumberValueType.GameVariable == this.type)
			{
				if(this.variableOrigin.IsSingle)
				{
					VariableHandler handler = this.variableOrigin.GetSingle(call);
					if(handler != null)
					{
						return ValueHelper.GetRounded(handler.GetFloat(this.name), this.rounding);
					}
				}
				else
				{
					return ValueHelper.GetRounded(
						VariableHandler.GetMultiFloat(this.name,
							this.variableOrigin.GetMulti(call), this.multiVariableUseType),
						this.rounding);
				}
			}
			else if(NumberValueType.PlayerPrefs == this.type)
			{
				if(this.isInt)
				{
					return ValueHelper.GetRounded(PlayerPrefs.GetInt(this.name), this.rounding);
				}
				else
				{
					return ValueHelper.GetRounded(PlayerPrefs.GetFloat(this.name), this.rounding);
				}
			}
			else if(NumberValueType.Formula == this.type)
			{
				if(user != null && target != null)
				{
					return ValueHelper.GetRounded(ORK.Formulas.Get(this.id).Calculate(
						new FormulaCall(this.initialValue, user, target)), this.rounding);
				}
			}
			else if(NumberValueType.GameTime == this.type)
			{
				return ValueHelper.GetRounded(ORK.Game.GameTime + this.offset, this.rounding);
			}
			else if(NumberValueType.TimeOfDay == this.type)
			{
				return ValueHelper.GetRounded((float)(System.DateTime.Now.TimeOfDay.TotalSeconds) + this.offset, this.rounding);
			}
			else if(NumberValueType.DateAndTime == this.type)
			{
				return ValueHelper.GetRounded(
					(float)(((this.isUTC ? System.DateTime.UtcNow : System.DateTime.Now) -
						new System.DateTime(1970, 1, 1, 0, 0, 0, this.isUTC ? System.DateTimeKind.Utc : System.DateTimeKind.Local)).TotalSeconds) +
					this.offset, this.rounding);
			}
			else if(NumberValueType.Random == this.type)
			{
				return ValueHelper.GetRounded(UnityWrapper.Range(this.value, this.value2), this.rounding);
			}
			else if(NumberValueType.DeltaTime == this.type)
			{
				return ValueHelper.GetRounded(Time.deltaTime + this.offset, this.rounding);
			}
			return 0;
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			if(NumberValueType.Value == this.type)
			{
				return this.value.ToString();
			}
			else if(NumberValueType.Formula == this.type)
			{
				return ORK.Formulas.GetName(this.id);
			}
			else if(NumberValueType.GameTime == this.type)
			{
				return "Game time + " + this.offset;
			}
			else if(NumberValueType.TimeOfDay == this.type)
			{
				return "Real time since midnight + " + this.offset;
			}
			else if(NumberValueType.DateAndTime == this.type)
			{
				return "Real date/time + " + this.offset;
			}
			else if(NumberValueType.Random == this.type)
			{
				return this.value.ToString() + "~" + this.value2.ToString();
			}
			else if(NumberValueType.DeltaTime == this.type)
			{
				return "Delta time + " + this.offset;
			}
			return this.name;
		}
	}
}
