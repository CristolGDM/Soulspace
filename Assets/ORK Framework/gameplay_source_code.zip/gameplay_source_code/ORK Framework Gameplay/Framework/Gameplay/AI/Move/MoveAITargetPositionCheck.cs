﻿
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class MoveAITargetPositionCheck : BaseData
	{
		// target check intervalls
		[ORKEditorHelp("Ignore Height Distance", "The distance along the height axis will be ignored when " +
			"calculating the distance for the check.\n" +
			"Depending on the 'Horizontal Plane' defined by the move AI, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		public bool ignoreHeightDistance = true;

		[ORKEditorHelp("No Combatant Radius", "The combatant radius setting of the combatants will " +
			"be ignored when calculating the distance for the check.", "")]
		public bool ignoreCombatantRadius = false;


		// lose target settings
		[ORKEditorHelp("Target Lost Interval (s)", "The time in seconds until the target is lost after leaving the detection area.\n" +
			"If the target leaves the detection area (i.e. no move detections can detect the target), " +
			"the combatant will still follow the target for the defined time.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float targetLostInterval = 1;

		[ORKEditorHelp("Lost Position Check", "Check the target's position while the target is lost " +
			"(i.e. the target left the detection area, but the 'target lost interval' is still running).\n" +
			"If disabled, the target's position wont be checked, " +
			"resulting in the combatant moving to the last known position of the target.", "")]
		public bool lostPositionCheck = false;


		// target checks
		[ORKEditorArray(false, "Add Target Check", "Adds a target check to this move AI.", "",
			"Remove", "Removes this target check.", "", noRemoveCount=1, isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {"Check",
				"Define the minimum distance to the target to use this interval.", ""})]
		public MoveTargetCheck[] targetCheck = new MoveTargetCheck[] {new MoveTargetCheck()};

		public MoveAITargetPositionCheck()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("tcIgnYDist"))
			{
				data.Get("tcIgnYDist", ref this.ignoreHeightDistance);
				data.Get("tcIgnComRad", ref this.ignoreCombatantRadius);
				data.Get("huntingLostInterval", ref this.targetLostInterval);
				data.Get("huntingLostUpdate", ref this.lostPositionCheck);
			}
		}


		/*
		============================================================================
		Target distance check functions
		============================================================================
		*/
		public float GetTargetCheckInterval(Combatant combatant, Combatant target, HorizontalPlaneType horizontalPlane)
		{
			float distance = combatant.Object.DistanceTo(target,
				this.ignoreHeightDistance, this.ignoreCombatantRadius, horizontalPlane);
			for(int i = this.targetCheck.Length - 1; i >= 0; i--)
			{
				if(distance >= this.targetCheck[i].distance)
				{
					return this.targetCheck[i].interval;
				}
			}
			return 0;
		}

		public float GetTargetCheckInterval(GameObject combatant, GameObject target, HorizontalPlaneType horizontalPlane)
		{
			float distance = VectorHelper.Distance(combatant.transform.position,
				target.transform.position, this.ignoreHeightDistance, horizontalPlane);
			for(int i = this.targetCheck.Length - 1; i >= 0; i--)
			{
				if(distance >= this.targetCheck[i].distance)
				{
					return this.targetCheck[i].interval;
				}
			}
			return 0;
		}
	}
}
