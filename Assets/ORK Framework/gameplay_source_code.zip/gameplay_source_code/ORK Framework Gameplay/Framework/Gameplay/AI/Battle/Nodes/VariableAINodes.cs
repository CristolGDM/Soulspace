
using ORKFramework;
using ORKFramework.AI;
using ORKFramework.Behaviours;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI.Steps
{
	[ORKEditorHelp("Check Object Variables", "Checks a combatant's object variables " +
		"(requires an 'Object Variables' component attached to the combatant's game object).\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Variable", "Check")]
	public class CheckObjectVariablesStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// variables
		[ORKEditorInfo(separator=true)]
		public VariableCondition condition = new VariableCondition();

		public CheckObjectVariablesStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(ref any, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(ref any,
				BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check object variables of all possible targets, add to found targets
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.condition.CheckVariables(list[i].Variables))
					{
						any = true;
						if(!this.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found";
		}
	}

	[ORKEditorHelp("Change Game Variables", "Changes game variables.", "")]
	[ORKNodeInfo("Variable")]
	public class ChangeGameVariablesStep : BaseAIStep
	{
		public AIVariableOrigin variableOrigin = new AIVariableOrigin();


		// variables
		[ORKEditorInfo(separator=true)]
		public VariableSetter change = new VariableSetter();

		public ChangeGameVariablesStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("origin"))
			{
				this.variableOrigin.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(this.variableOrigin.IsSingle)
			{
				VariableHandler handler = this.variableOrigin.GetSingle(call);
				if(handler != null)
				{
					this.change.SetVariables(handler, call.Variables, call.SelectedData);
				}
			}
			else
			{
				List<VariableHandler> handlers = this.variableOrigin.GetMulti(call);
				if(handlers != null)
				{
					for(int i = 0; i < handlers.Count; i++)
					{
						this.change.SetVariables(handlers[i], call.Variables, call.SelectedData);
					}
				}
			}

			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variableOrigin.GetInfoText();
		}
	}

	[ORKEditorHelp("Check Game Variables", "Checks game variable conditions.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Doesn't influence the target list.", "")]
	[ORKNodeInfo("Variable", "Check")]
	public class CheckGameVariablesStep : BaseAICheckStep
	{
		public AIVariableOrigin variableOrigin = new AIVariableOrigin();


		// variables
		[ORKEditorInfo(separator=true)]
		public VariableCondition condition = new VariableCondition();

		public CheckGameVariablesStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("origin"))
			{
				this.variableOrigin.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool check = false;

			if(this.variableOrigin.IsSingle)
			{
				check = this.condition.CheckVariables(this.variableOrigin.GetSingle(call));
			}
			else
			{
				List<VariableHandler> handlers = this.variableOrigin.GetMulti(call);
				if(handlers != null)
				{
					for(int i = 0; i < handlers.Count; i++)
					{
						if(this.condition.CheckVariables(handlers[i]))
						{
							check = true;
						}
						else
						{
							check = false;
							break;
						}
					}
				}
			}

			if(check)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variableOrigin.GetInfoText();
		}
	}

	[ORKEditorHelp("Game Variable Fork", "Checks a single game variable for certain values.\n" +
		"If a variable condition is valid, it's next step will be executed.\n" +
		"If no variable condition is valid, 'Failed' will be executed.", "")]
	[ORKNodeInfo("Check", "Variable")]
	public class GameVariableForkStep : BaseAIStep
	{
		// variable
		[ORKEditorInfo(labelText="Variable Key")]
		public StringValue key = new StringValue();

		[ORKEditorArray(false, "Add Condition", "Adds a new game variable condition.", "",
			"Remove", "Removes the game variable condition.", "", isMove=true, isCopy=true,
			noRemoveCount=1, foldout=true, foldoutText=new string[] {
				"Variable Condition", "Define the game variable condition that must be valid.", ""
		})]
		public CheckVariableAINextNode[] condition = new CheckVariableAINextNode[] {new CheckVariableAINextNode()};

		public GameVariableForkStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			currentStep = this.next;

			string varKey = this.key.GetValue();

			for(int i = 0; i < this.condition.Length; i++)
			{
				if(this.condition[i].Check(varKey, ORK.Game.Variables))
				{
					currentStep = this.condition[i].next;
					break;
				}
			}

			return null;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.key.GetInfoText();
		}

		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1) + ": " + this.condition[index - 1].GetInfoText();
			}
			return "";
		}

		public override int GetNextCount()
		{
			return this.condition.Length + 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.condition[index - 1].next;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.condition[index - 1].next = next;
			}
		}
	}

	[ORKEditorHelp("Get Object Variable", "The combatant with the highest or lowest " +
		"float object variable will be added to the target list.\n" +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Variable")]
	public class GetObjectVariableStep : BaseAIStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// status
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue key = new StringValue();

		[ORKEditorHelp("Highest/Lowest", "If enabled, the combatant with the highest value of the " +
			"defined float object variable will be added to the target list.\n" +
			"If disabled, the combatant with the lowest value of the " +
			"defined float object variable will be added to the target list.", "")]
		public bool getHighest = false;

		[ORKEditorHelp("Variable Must Exist", "The float object variable must exist on the combatant. " +
			"If the variable doesn't exist, the combatant wont be added to the list.\n" +
			"If disabled, the default value (0) will be used.", "")]
		public bool variableMustExist = false;

		public GetObjectVariableStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(call.user,
				BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			currentStep = this.next;
			return null;
		}

		private void Check(Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			int found = -1;
			float tmpVal = this.getHighest ? float.MinValue : float.MaxValue;
			string tmpKey = this.key.GetValue();

			// check for highest/lowest status value
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(!this.variableMustExist ||
						list[i].Variables.GetFloatKeys().Contains(tmpKey))
					{
						float objValue = list[i].Variables.GetFloat(tmpKey);
						if((this.getHighest && tmpVal < objValue) ||
							(!this.getHighest && tmpVal > objValue))
						{
							tmpVal = objValue;
							found = i;
						}
					}
				}
			}

			if(found >= 0 && !foundTargets.Contains(list[found]))
			{
				foundTargets.Add(list[found]);
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.getHighest ? "Highest " : "Lowest ") +
				this.key.GetInfoText();
		}
	}
}
