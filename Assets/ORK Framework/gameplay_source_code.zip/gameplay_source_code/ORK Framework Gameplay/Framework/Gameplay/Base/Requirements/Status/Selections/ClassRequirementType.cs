﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Class", "The combatant must or mustn't be of the selected class.", "")]
	public class ClassRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Class", "Select the class that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Class)]
		public int classID = 0;

		[ORKEditorHelp("Is Class", "The combatant must be the defined class.\n" +
			"If disabled, the combatant mustn't be the defined class.", "")]
		public bool isClass = true;

		public ClassRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.classID);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return (combatant.Class.ID == this.classID) == this.isClass;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Class.Changed += notify.ClassChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Class.Changed -= notify.ClassChanged;
		}
	}
}
