﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Status Effect", "The selected status effect must or mustn't be applied to the combatant.", "")]
	public class StatusEffectRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Status Effect", "Select the status effect that will be used.", "")]
		[ORKEditorInfo(ORKDataType.StatusEffect)]
		public int statusEffectID = 0;

		[ORKEditorHelp("Is Applied", "The selected status effect must be applied.\n" +
			"If disabled, the effect mustn't be applied.", "")]
		public bool applied = false;

		[ORKEditorHelp("Check Stacked Quantity", "Check the quantity the status effect is stacked on the combatant.", "")]
		[ORKEditorLayout("applied", true)]
		public bool checkStacked = false;

		[ORKEditorLayout("checkStacked", true, endCheckGroup=true, endGroups=2)]
		public ValueCheck check = new ValueCheck();

		public StatusEffectRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.statusEffectID);
			}
			this.check.UpgradeInt(data, "stackComparison", "stackedQuantity");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.applied == combatant.Status.Effects.IsApplied(this.statusEffectID) &&
				(!this.checkStacked ||
					this.check.Check(
						combatant.Status.Effects.GetStackedCount(this.statusEffectID),
						combatant));
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Status.Effects.Added += notify.StatusEffectChanged;
			combatant.Status.Effects.Removed += notify.StatusEffectChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Status.Effects.Added -= notify.StatusEffectChanged;
			combatant.Status.Effects.Removed -= notify.StatusEffectChanged;
		}
	}
}
