﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class AssetSourceCache
	{
		private static AssetSourceCache instance;

		private static object instanceLock = new object();


		// resources
		private Dictionary<string, Object> resourcesCache = new Dictionary<string, Object>();


		// asset bundles
		private Dictionary<string, AssetBundle> assetBundleCache = new Dictionary<string, AssetBundle>();

		private Dictionary<string, Dictionary<string, Object>> assetBundleAssetCache = new Dictionary<string, Dictionary<string, Object>>();

		private AssetSourceCache()
		{
			if(instance != null)
			{
				Debug.LogError("You can't create two instances of AssetSourceCache!");
			}
			else
			{
				instance = this;
			}
		}

		public static AssetSourceCache Instance
		{
			get
			{
				if(instance == null)
				{
					lock(instanceLock)
					{
						if(instance == null)
						{
							new AssetSourceCache();
						}
					}
				}
				return instance;
			}
		}

		public void Clear(bool unloadResources, bool unloadAssetBundles)
		{
			// resources
			if(unloadResources)
			{
				this.resourcesCache.Clear();
				Resources.UnloadUnusedAssets();
			}

			// asset bundles
			if(unloadAssetBundles)
			{
				foreach(KeyValuePair<string, AssetBundle> pair in this.assetBundleCache)
				{
					pair.Value.Unload(false);
				}
				this.assetBundleCache.Clear();
			}
		}


		/*
		============================================================================
		Asset functions
		============================================================================
		*/
		public T GetFromResources<T>(string resourcePath) where T : Object
		{
			Object asset;
			if(!this.resourcesCache.TryGetValue(resourcePath, out asset))
			{
				T tmp = Resources.Load<T>(resourcePath);
				this.resourcesCache.Add(resourcePath, tmp);
				return tmp;
			}
			return asset as T;
		}

		public T GetFromAssetBundle<T>(string bundlePath, string assetName, AssetBundleLoadType loadType) where T : Object
		{
			AssetBundle bundle = this.LoadAssetBundle(bundlePath, loadType);
			if(bundle != null)
			{
				return bundle.LoadAsset<T>(assetName);
			}
			return null;
		}

		public AssetBundle LoadAssetBundle(string bundlePath, AssetBundleLoadType loadType)
		{
			AssetBundle bundle;
			if(!this.assetBundleCache.TryGetValue(bundlePath, out bundle))
			{
				try
				{
					if(AssetBundleLoadType.LoadFromFile == loadType)
					{
						bundle = AssetBundle.LoadFromFile(bundlePath);
					}
					else if(AssetBundleLoadType.LoadFromMemory == loadType)
					{
						byte[] data = System.IO.File.ReadAllBytes(bundlePath);
						if(data != null)
						{
							bundle = AssetBundle.LoadFromMemory(data);
						}
					}
					this.assetBundleCache.Add(bundlePath, bundle);
				}
				catch(System.Exception ex)
				{
					Debug.LogWarning("Couldn't load asset bundle at path: " +
						bundlePath + "\n" + ex.StackTrace);
				}
			}
			return bundle;
		}
	}
}
