
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class MoveSpeed : BaseData
	{
		[ORKEditorHelp("Speed Type", "Select the speed used to move:\n" +
			"- Walk: The combatant's walk speed.\n" +
			"- Run: The combatant's run speed.\n" +
			"- Sprint: The combatant's sprint speed.\n" +
			"- Value: A defined value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public MoveSpeedType type = MoveSpeedType.Run;

		[ORKEditorHelp("Speed", "The speed in world units per second used to move.", "")]
		[ORKEditorLayout("type", MoveSpeedType.Value, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float speed = 5;

		public MoveSpeed()
		{

		}

		public MoveSpeed(MoveSpeedType type, float speed)
		{
			this.type = type;
			this.speed = speed;
		}


		/*
		============================================================================
		Speed functions
		============================================================================
		*/
		public float GetSpeed(Combatant combatant)
		{
			if(MoveSpeedType.Value == this.type)
			{
				return this.speed;
			}
			else
			{
				return combatant.Object.GetMoveSpeed(this.type);
			}
		}
	}
}
