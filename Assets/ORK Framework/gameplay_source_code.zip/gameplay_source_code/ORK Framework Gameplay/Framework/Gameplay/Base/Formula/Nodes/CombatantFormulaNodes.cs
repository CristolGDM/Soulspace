
using UnityEngine;
using ORKFramework.Combatants;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework.Formulas.Steps
{
	[ORKEditorHelp("Status Value", "A combatant's current, base or maximum status value is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class StatusValueStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("From All", "Use all combatants stored in selected data.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin.origin", StatusOrigin.Selected, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool fromAllSelectedData = false;

		[ORKEditorHelp("Status Value", "Select the status value that will be used as value.\n" +
			"You can use the current value or maximum value of the status value.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue, separator=true)]
		public int id = 0;

		[ORKEditorHelp("Value Origin", "Select which value will be used:\n" +
			"- Base: The base value, without any bonuses.\n" +
			"- Current: The actual/real value (including bonuses).\n" +
			"- Maximum: The maximum value the status value can reach.", "")]
		public StatusValueOrigin svOrigin = StatusValueOrigin.Current;

		[ORKEditorHelp("Whole Group", "Use status values from all members of the combatant's group.", "")]
		public bool wholeGroup = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("wholeGroup", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		[ORKEditorHelp("Multi Value Use", "Select how values of multiple combatants will be used:\n" +
			"- First: Use the first available value.\n" +
			"- Lowest: Use the lowest available value.\n" +
			"- Highest: Use the highest available value.\n" +
			"- Average: Use the average of all available values.\n" +
			"- Add: Sum all available values (i.e. value1 + value 2 + value3 ...).\n" +
			"- Sub: Subtract all available values (i.e. value1 - value2 - value3 ...).\n" +
			"- Multiply: Multiply all available values (i.e. value1 * value2 * value3 ...).\n" +
			"- Divide: Divide all available values (i.e. value1 / value2 / value3 ...).", "")]
		[ORKEditorLayout(new string[] { "wholeGroup", "fromAllSelectedData" },
			new object[] { true, true },
			needed=Needed.One, endCheckGroup=true)]
		public MultiFloatValueUse multiValueType = MultiFloatValueUse.Add;

		public StatusValueStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(StatusOrigin.Selected == this.origin.origin &&
				this.fromAllSelectedData)
			{
				List<Combatant> combatants = SelectedDataHelper.GetCombatants(
					this.origin.selectedData.GetSelectedData(call));
				List<float> values = new List<float>();

				for(int i = 0; i < combatants.Count; i++)
				{
					if(combatants[i] != null)
					{
						if(this.wholeGroup)
						{
							List<Combatant> group = this.onlyBattle ?
								combatants[i].Group.GetBattle() :
								combatants[i].Group.GetGroup();
							for(int j = 0; j < group.Count; j++)
							{
								if(group[j] != null)
								{
									if(StatusValueOrigin.Base == this.svOrigin)
									{
										values.Add(group[j].Status[this.id].GetBaseValue());
									}
									else if(StatusValueOrigin.Current == this.svOrigin)
									{
										values.Add(group[j].Status[this.id].GetValue());
									}
									else if(StatusValueOrigin.Maximum == this.svOrigin)
									{
										values.Add(group[j].Status[this.id].GetMaxValue());
									}
								}
							}
						}
						else
						{
							if(StatusValueOrigin.Base == this.svOrigin)
							{
								values.Add(combatants[i].Status[this.id].GetBaseValue());
							}
							else if(StatusValueOrigin.Current == this.svOrigin)
							{
								values.Add(combatants[i].Status[this.id].GetValue());
							}
							else if(StatusValueOrigin.Maximum == this.svOrigin)
							{
								values.Add(combatants[i].Status[this.id].GetMaxValue());
							}
						}
					}
				}

				float value = 0;
				if(values.Count > 0)
				{
					value = ValueHelper.GetMultiValue(values, this.multiValueType);
				}
				ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			}
			else
			{
				Combatant c = this.origin.GetCombatant(call);
				if(c != null)
				{
					float value = 0;
					if(this.wholeGroup)
					{
						value = this.GetGroupValue(this.onlyBattle ?
							c.Group.GetBattle() : c.Group.GetGroup());
					}
					else
					{
						if(StatusValueOrigin.Base == this.svOrigin)
						{
							value = c.Status[this.id].GetBaseValue();
						}
						else if(StatusValueOrigin.Current == this.svOrigin)
						{
							value = c.Status[this.id].GetValue();
						}
						else if(StatusValueOrigin.Maximum == this.svOrigin)
						{
							value = c.Status[this.id].GetMaxValue();
						}
					}
					ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
				}
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			if(StatusOrigin.Selected == this.origin.origin &&
				this.fromAllSelectedData)
			{
				List<Combatant> combatants = SelectedDataHelper.GetCombatants(
					this.origin.selectedData.GetSelectedData(call));
				List<float> values = new List<float>();

				for(int i = 0; i < combatants.Count; i++)
				{
					if(combatants[i] != null)
					{
						if(this.wholeGroup)
						{
							List<Combatant> group = this.onlyBattle ?
								combatants[i].Group.GetBattle() :
								combatants[i].Group.GetGroup();
							for(int j = 0; j < group.Count; j++)
							{
								if(group[j] != null)
								{
									if(StatusValueOrigin.Base == this.svOrigin)
									{
										values.Add(group[j].Status[this.id].GetBaseValue());
									}
									else if(StatusValueOrigin.Current == this.svOrigin)
									{
										values.Add(group[j].Status[this.id].GetPreviewValue(false));
									}
									else if(StatusValueOrigin.Maximum == this.svOrigin)
									{
										values.Add(group[j].Status[this.id].GetPreviewMaxValue());
									}
								}
							}
						}
						else
						{
							if(StatusValueOrigin.Base == this.svOrigin)
							{
								values.Add(combatants[i].Status[this.id].GetBaseValue());
							}
							else if(StatusValueOrigin.Current == this.svOrigin)
							{
								values.Add(combatants[i].Status[this.id].GetPreviewValue(false));
							}
							else if(StatusValueOrigin.Maximum == this.svOrigin)
							{
								values.Add(combatants[i].Status[this.id].GetPreviewMaxValue());
							}
						}
					}
				}

				float value = 0;
				if(values.Count > 0)
				{
					value = ValueHelper.GetMultiValue(values, this.multiValueType);
				}
				ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			}
			else
			{
				Combatant c = this.origin.GetCombatant(call);
				if(c != null)
				{
					float value = 0;
					if(this.wholeGroup)
					{
						value = this.GetGroupValuePreview(this.onlyBattle ?
							c.Group.GetBattle() : c.Group.GetGroup());
					}
					else
					{
						if(StatusValueOrigin.Base == this.svOrigin)
						{
							value = c.Status[this.id].GetBaseValue();
						}
						else if(StatusValueOrigin.Current == this.svOrigin)
						{
							value = c.Status[this.id].GetPreviewValue(false);
						}
						else if(StatusValueOrigin.Maximum == this.svOrigin)
						{
							value = c.Status[this.id].GetPreviewMaxValue();
						}
					}
					ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
				}
			}
			return this.next;
		}

		private float GetGroupValue(List<Combatant> list)
		{
			List<float> values = new List<float>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(StatusValueOrigin.Base == this.svOrigin)
					{
						values.Add(list[i].Status[this.id].GetBaseValue());
					}
					else if(StatusValueOrigin.Current == this.svOrigin)
					{
						values.Add(list[i].Status[this.id].GetValue());
					}
					else if(StatusValueOrigin.Maximum == this.svOrigin)
					{
						values.Add(list[i].Status[this.id].GetMaxValue());
					}
				}
			}

			if(values.Count > 0)
			{
				return ValueHelper.GetMultiValue(values, this.multiValueType);
			}
			return 0;
		}

		private float GetGroupValuePreview(List<Combatant> list)
		{
			List<float> values = new List<float>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(StatusValueOrigin.Base == this.svOrigin)
					{
						values.Add(list[i].Status[this.id].GetBaseValue());
					}
					else if(StatusValueOrigin.Current == this.svOrigin)
					{
						values.Add(list[i].Status[this.id].GetPreviewValue(false));
					}
					else if(StatusValueOrigin.Maximum == this.svOrigin)
					{
						values.Add(list[i].Status[this.id].GetPreviewMaxValue());
					}
				}
			}

			if(values.Count > 0)
			{
				return ValueHelper.GetMultiValue(values, this.multiValueType);
			}
			return 0;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() + " " +
				this.svOrigin + " " + ORK.StatusValues.GetName(this.id);
		}
	}

	[ORKEditorHelp("Random Status Value", "A random value between two status values of combatants is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class RandomStatusValueStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorHelp("As Int", "The random value will be used as an integer (i.e. whole number).\n" +
			"If disabled, the random value will be a float.", "")]
		public bool asInt = false;


		// value 1
		[ORKEditorInfo("Status Value 1", "Settings for the 1st status value.", "")]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Status Value 1", "Select the status value that will be used as value.\n" +
			"You can use the current value, base value or maximum value of the status value.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue, separator=true)]
		public int id = 0;

		[ORKEditorHelp("Value Origin 1", "Select which value will be used:\n" +
			"- Base: The base value, without any bonuses.\n" +
			"- Current: The actual/real value (including bonuses).\n" +
			"- Maximum: The maximum value the status value can reach.", "")]
		public StatusValueOrigin svOrigin = StatusValueOrigin.Current;

		[ORKEditorHelp("Whole Group", "Use status values from all members of the combatant's group.", "")]
		public bool wholeGroup = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("wholeGroup", true)]
		public bool onlyBattle = true;

		[ORKEditorHelp("Multi Value Use", "Select how values of multiple combatants will be used:\n" +
			"- First: Use the first available value.\n" +
			"- Lowest: Use the lowest available value.\n" +
			"- Highest: Use the highest available value.\n" +
			"- Average: Use the average of all available values.\n" +
			"- Add: Sum all available values (i.e. value1 + value 2 + value3 ...).\n" +
			"- Sub: Subtract all available values (i.e. value1 - value2 - value3 ...).\n" +
			"- Multiply: Multiply all available values (i.e. value1 * value2 * value3 ...).\n" +
			"- Divide: Divide all available values (i.e. value1 / value2 / value3 ...).", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public MultiFloatValueUse multiValueType = MultiFloatValueUse.Add;


		// value 2
		[ORKEditorInfo("Status Value 2", "Settings for the 2nd status value.", "")]
		public FormulaStatusOrigin origin2 = new FormulaStatusOrigin();

		[ORKEditorHelp("Status Value 2", "Select the status value that will be used as value.\n" +
			"You can use the current value, base value or maximum value of the status value.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue, separator=true)]
		public int id2 = 0;

		[ORKEditorHelp("Value Origin 2", "Select which value will be used:\n" +
			"- Base: The base value, without any bonuses.\n" +
			"- Current: The actual/real value (including bonuses).\n" +
			"- Maximum: The maximum value the status value can reach.", "")]
		public StatusValueOrigin svOrigin2 = StatusValueOrigin.Current;

		[ORKEditorHelp("Whole Group 2", "Use status values from all members of the combatant's group.", "")]
		public bool wholeGroup2 = false;

		[ORKEditorHelp("Only Battle 2", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("wholeGroup2", true)]
		public bool onlyBattle2 = true;

		[ORKEditorHelp("Multi Value Use 2", "Select how values of multiple combatants will be used:\n" +
			"- First: Use the first available value.\n" +
			"- Lowest: Use the lowest available value.\n" +
			"- Highest: Use the highest available value.\n" +
			"- Average: Use the average of all available values.\n" +
			"- Add: Sum all available values (i.e. value1 + value 2 + value3 ...).\n" +
			"- Sub: Subtract all available values (i.e. value1 - value2 - value3 ...).\n" +
			"- Multiply: Multiply all available values (i.e. value1 * value2 * value3 ...).\n" +
			"- Divide: Divide all available values (i.e. value1 / value2 / value3 ...).", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public MultiFloatValueUse multiValueType2 = MultiFloatValueUse.Add;

		public RandomStatusValueStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.wholeGroup)
				{
					value = this.GetGroupValue(this.onlyBattle ?
						c.Group.GetBattle() : c.Group.GetGroup(),
						this.multiValueType);
				}
				else
				{
					if(StatusValueOrigin.Base == this.svOrigin)
					{
						value = c.Status[this.id].GetBaseValue();
					}
					else if(StatusValueOrigin.Current == this.svOrigin)
					{
						value = c.Status[this.id].GetValue();
					}
					else if(StatusValueOrigin.Maximum == this.svOrigin)
					{
						value = c.Status[this.id].GetMaxValue();
					}
				}

				c = this.origin2.GetCombatant(call);
				if(c != null)
				{
					float value2 = 0;
					if(this.wholeGroup2)
					{
						value = this.GetGroupValue(this.onlyBattle2 ?
							c.Group.GetBattle() : c.Group.GetGroup(),
							this.multiValueType2);
					}
					else
					{
						if(StatusValueOrigin.Base == this.svOrigin2)
						{
							value2 = c.Status[this.id2].GetBaseValue();
						}
						else if(StatusValueOrigin.Current == this.svOrigin2)
						{
							value2 = c.Status[this.id2].GetValue();
						}
						else if(StatusValueOrigin.Maximum == this.svOrigin2)
						{
							value2 = c.Status[this.id2].GetMaxValue();
						}
					}

					if(value < value2)
					{
						ValueHelper.UseOperator(ref call.result,
							this.asInt ? (int)UnityWrapper.Range(value, value2) : UnityWrapper.Range(value, value2),
							this.formulaOperator);
					}
					else if(value > value2)
					{
						ValueHelper.UseOperator(ref call.result,
							this.asInt ? (int)UnityWrapper.Range(value2, value) : UnityWrapper.Range(value2, value),
							this.formulaOperator);
					}
					else
					{
						ValueHelper.UseOperator(ref call.result, this.asInt ? (int)value : value, this.formulaOperator);
					}
				}
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.wholeGroup)
				{
					value = this.GetGroupValuePreview(this.onlyBattle ?
						c.Group.GetBattle() : c.Group.GetGroup(),
						this.multiValueType);
				}
				else
				{
					if(StatusValueOrigin.Base == this.svOrigin)
					{
						value = c.Status[this.id].GetBaseValue();
					}
					else if(StatusValueOrigin.Current == this.svOrigin)
					{
						value = c.Status[this.id].GetPreviewValue(false);
					}
					else if(StatusValueOrigin.Maximum == this.svOrigin)
					{
						value = c.Status[this.id].GetPreviewMaxValue();
					}
				}

				c = this.origin2.GetCombatant(call);
				if(c != null)
				{
					float value2 = 0;
					if(this.wholeGroup2)
					{
						value = this.GetGroupValuePreview(this.onlyBattle2 ?
							c.Group.GetBattle() : c.Group.GetGroup(),
							this.multiValueType2);
					}
					else
					{
						if(StatusValueOrigin.Base == this.svOrigin2)
						{
							value2 = c.Status[this.id2].GetBaseValue();
						}
						else if(StatusValueOrigin.Current == this.svOrigin2)
						{
							value2 = c.Status[this.id2].GetPreviewValue(false);
						}
						else if(StatusValueOrigin.Maximum == this.svOrigin2)
						{
							value2 = c.Status[this.id2].GetPreviewMaxValue();
						}
					}

					if(value < value2)
					{
						ValueHelper.UseOperator(ref call.result,
							this.asInt ? (int)UnityWrapper.Range(value, value2) : UnityWrapper.Range(value, value2),
							this.formulaOperator);
					}
					else if(value > value2)
					{
						ValueHelper.UseOperator(ref call.result,
							this.asInt ? (int)UnityWrapper.Range(value2, value) : UnityWrapper.Range(value2, value),
							this.formulaOperator);
					}
					else
					{
						ValueHelper.UseOperator(ref call.result, this.asInt ? (int)value : value, this.formulaOperator);
					}
				}
			}
			return this.next;
		}

		private float GetGroupValue(List<Combatant> list, MultiFloatValueUse multiUse)
		{
			List<float> values = new List<float>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(StatusValueOrigin.Base == this.svOrigin)
					{
						values.Add(list[i].Status[this.id].GetBaseValue());
					}
					else if(StatusValueOrigin.Current == this.svOrigin)
					{
						values.Add(list[i].Status[this.id].GetValue());
					}
					else if(StatusValueOrigin.Maximum == this.svOrigin)
					{
						values.Add(list[i].Status[this.id].GetMaxValue());
					}
				}
			}

			if(values.Count > 0)
			{
				return ValueHelper.GetMultiValue(values, multiUse);
			}
			return 0;
		}

		private float GetGroupValuePreview(List<Combatant> list, MultiFloatValueUse multiUse)
		{
			List<float> values = new List<float>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(StatusValueOrigin.Base == this.svOrigin)
					{
						values.Add(list[i].Status[this.id].GetBaseValue());
					}
					else if(StatusValueOrigin.Current == this.svOrigin)
					{
						values.Add(list[i].Status[this.id].GetPreviewValue(false));
					}
					else if(StatusValueOrigin.Maximum == this.svOrigin)
					{
						values.Add(list[i].Status[this.id].GetPreviewMaxValue());
					}
				}
			}

			if(values.Count > 0)
			{
				return ValueHelper.GetMultiValue(values, multiUse);
			}
			return 0;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() + " " +
				this.svOrigin + " " + ORK.StatusValues.GetName(this.id) + " ~ " +
				this.origin2.GetInfoText() + " " + this.svOrigin2 + " " +
				ORK.StatusValues.GetName(this.id2);
		}
	}

	[ORKEditorHelp("Attack Attribute", "A combatant's current attack attribute value is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class AttackAttributeStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		public AttackAttributeSelection attackAttribute = new AttackAttributeSelection();

		public AttackAttributeStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("id"))
			{
				data.Get("id", ref this.attackAttribute.index);
				data.Get("id2", ref this.attackAttribute.subIndex);
			}
		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				ValueHelper.UseOperator(ref call.result,
					c.Status.GetAttackAttribute(this.attackAttribute.index).GetValue(this.attackAttribute.subIndex),
					this.formulaOperator);
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				ValueHelper.UseOperator(ref call.result,
					c.Status.GetAttackAttribute(this.attackAttribute.index).GetPreviewValue(this.attackAttribute.subIndex),
					this.formulaOperator);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() + " " +
				ORK.AttackAttributes.GetName(this.attackAttribute.index) + " " +
				ORK.AttackAttributes.GetName(this.attackAttribute.index, this.attackAttribute.subIndex);
		}
	}

	[ORKEditorHelp("Defence Attribute", "A combatant's current defence attribute value is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class DefenceAttributeStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		public DefenceAttributeSelection defenceAttribute = new DefenceAttributeSelection();

		public DefenceAttributeStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("id"))
			{
				data.Get("id", ref this.defenceAttribute.index);
				data.Get("id2", ref this.defenceAttribute.subIndex);
			}
		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				ValueHelper.UseOperator(ref call.result,
					c.Status.GetDefenceAttribute(this.defenceAttribute.index).GetValue(this.defenceAttribute.subIndex),
					this.formulaOperator);
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				ValueHelper.UseOperator(ref call.result,
					c.Status.GetDefenceAttribute(this.defenceAttribute.index).GetPreviewValue(this.defenceAttribute.subIndex),
					this.formulaOperator);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() + " " +
				ORK.DefenceAttributes.GetName(this.defenceAttribute.index) + " " +
				ORK.DefenceAttributes.GetName(this.defenceAttribute.index, this.defenceAttribute.subIndex);
		}
	}

	[ORKEditorHelp("Level", "A combatant's current or maximum level (or class level) is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class LevelStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Class Level", "The class level of the combatant is used.\n" +
			"If disabled, the base level is used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useClass = false;

		[ORKEditorHelp("Use Maximum", "The maximum level is used.\n" +
			"If disabled, the current level is used.", "")]
		public bool useMax = false;

		[ORKEditorHelp("Use Average", "Use the average level of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		public LevelStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useClass)
				{
					if(this.useAverage)
					{
						if(this.onlyBattle)
						{
							value = this.useMax ? c.Group.AverageBattleMaxClassLevel : c.Group.AverageBattleClassLevel;
						}
						else
						{
							value = this.useMax ? c.Group.AverageMaxClassLevel : c.Group.AverageClassLevel;
						}
					}
					else
					{
						value = this.useMax ? c.Class.MaxLevel : c.Class.Level;
					}
				}
				else
				{
					if(this.useAverage)
					{
						if(this.onlyBattle)
						{
							value = this.useMax ? c.Group.AverageBattleMaxLevel : c.Group.AverageBattleLevel;
						}
						else
						{
							value = this.useMax ? c.Group.AverageMaxLevel : c.Group.AverageLevel;
						}
					}
					else
					{
						value = this.useMax ? c.Status.MaxLevel : c.Status.Level;
					}
				}
				ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() +
				(this.useAverage ? " Avg. " : " ") + (this.useMax ? "Max " : "") +
				(this.useClass ? "Class Level" : "Level");
		}
	}

	[ORKEditorHelp("Turn", "A combatant's current turn number is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class TurnStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Use Average", "Use the average turn number of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		public TurnStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useAverage)
				{
					if(this.onlyBattle)
					{
						value = c.Group.AverageBattleTurn;
					}
					else
					{
						value = c.Group.AverageTurn;
					}
				}
				else
				{
					value = c.Battle.Turn;
				}
				ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() +
				(this.useAverage ? " Avg. Turn" : " Turn");
		}
	}

	[ORKEditorHelp("Check Turn", "Checks a combatant's turn.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Combatant", "Check")]
	public class CheckTurnStep : BaseFormulaCheckStep
	{
		// status value
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Use Average", "Use the average turn number of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;


		// check
		[ORKEditorInfo(separator=true)]
		public FormulaValueCheck check = new FormulaValueCheck();

		public CheckTurnStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.check.UpgradeFormulaFloat(data, "check", "turn", "turn2");
		}

		public override int Calculate(FormulaCall call)
		{
			bool check = false;

			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				check = this.check.Check(
					this.useAverage ?
						(this.onlyBattle ? c.Group.AverageBattleTurn : c.Group.AverageTurn) :
						c.Battle.Turn,
					call);
			}

			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText() + ": " + this.check.GetInfoText();
		}
	}

	[ORKEditorHelp("Turn Value", "A combatant's current turn value is used.\n" +
		"The turn value is used in to generate the turn order in 'Turn Based Battles' using 'Multi Turns'.", "")]
	[ORKNodeInfo("Combatant")]
	public class TurnValueStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Use Average", "Use the average turn value of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		public TurnValueStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useAverage)
				{
					if(this.onlyBattle)
					{
						value = c.Group.AverageBattleTurnValue;
					}
					else
					{
						value = c.Group.AverageTurnValue;
					}
				}
				else
				{
					value = c.Battle.TurnValue;
				}
				ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() +
				(this.useAverage ? " Avg. Turn Value" : " Turn Value");
		}
	}

	[ORKEditorHelp("Check Turn Value", "Checks a combatant's turn value.\n" +
		"The turn value is used in to generate the turn order in 'Turn Based Battles' using 'Multi Turns'." +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Check", "Combatant")]
	public class CheckTurnValueStep : BaseFormulaCheckStep
	{
		// status value
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Use Average", "Use the average turn value of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		// check
		[ORKEditorInfo(separator=true)]
		public FormulaValueCheck check = new FormulaValueCheck();

		public CheckTurnValueStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.check.UpgradeFormulaFloat(data, "check", "turn", "turn2");
		}

		public override int Calculate(FormulaCall call)
		{
			bool check = false;

			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				check = this.check.Check(
					this.useAverage ?
						(this.onlyBattle ? c.Group.AverageBattleTurnValue : c.Group.AverageTurnValue) :
						c.Battle.TurnValue,
					call);
			}

			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText() + ": " + this.check.GetInfoText();
		}
	}

	[ORKEditorHelp("Action Bar", "A combatant's current action bar is used.\n" +
		"In 'Turn Based Battles' and 'Phase Battles', the action bar represents the actions per turn of the combatant.\n" +
		"In 'Active Time Battles', the action bar represents the timebar of the combatant.", "")]
	[ORKNodeInfo("Combatant")]
	public class ActionBarStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Used Action Bar", "Use the 'Used Action Bar' instead of the 'Action Bar'.\n" +
			"The 'Used Action Bar' defines how much of the action bar is already used by actions.\n" +
			"In 'Turn Based Battles' and 'Phase Battles', the used action bar will be increased by the actions the combatant selected.\n" +
			"In 'Active Time Battles', the used action bar defines how much of the timebar has already been used.", "")]
		public bool usedActionBar = false;

		[ORKEditorHelp("Use Average", "Use the average turn value of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		public ActionBarStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useAverage)
				{
					if(this.onlyBattle)
					{
						value = this.usedActionBar ?
							c.Group.AverageBattleUsedActionBar :
							c.Group.AverageBattleActionBar;
					}
					else
					{
						value = this.usedActionBar ?
							c.Group.AverageUsedActionBar :
							c.Group.AverageActionBar;
					}
				}
				else
				{
					value = this.usedActionBar ?
						c.Battle.UsedActionBar :
						c.Battle.ActionBar;
				}
				ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() +
				(this.useAverage ?
					(this.usedActionBar ? " Avg. Used Action Bar" : " Avg. Action Bar") :
					(this.usedActionBar ? " Used Action Bar" : " Action Bar"));
		}
	}

	[ORKEditorHelp("Check Action Bar", "Checks a combatant's action bar.\n" +
		"In 'Turn Based Battles' and 'Phase Battles', the action bar represents the actions per turn of the combatant.\n" +
		"In 'Active Time Battles', the action bar represents the timebar of the combatant." +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Check", "Combatant")]
	public class CheckActionBarStep : BaseFormulaCheckStep
	{
		// status value
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Used Action Bar", "Check the 'Used Action Bar' instead of the 'Action Bar'.\n" +
			"The 'Used Action Bar' defines how much of the action bar is already used by actions.\n" +
			"In 'Turn Based Battles' and 'Phase Battles', the used action bar will be increased by the actions the combatant selected.\n" +
			"In 'Active Time Battles', the used action bar defines how much of the timebar has already been used.\n" +
			"E.g. use this to check if a combatant already chose actions by checking if the used action bar equals 0.", "")]
		public bool usedActionBar = false;

		[ORKEditorHelp("Use Average", "Use the average action bar value of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		// check
		[ORKEditorInfo(separator=true)]
		public FormulaValueCheck check = new FormulaValueCheck();

		public CheckActionBarStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.check.UpgradeFormulaFloat(data, "check", "turn", "turn2");
		}

		public override int Calculate(FormulaCall call)
		{
			bool check = false;

			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				check = this.check.Check(
					this.useAverage ?
						(this.onlyBattle ?
							(this.usedActionBar ?
								c.Group.AverageBattleUsedActionBar :
								c.Group.AverageBattleActionBar) :
							(this.usedActionBar ?
								c.Group.AverageUsedActionBar :
								c.Group.AverageActionBar)) :
						(this.usedActionBar ?
							c.Battle.UsedActionBar :
							c.Battle.ActionBar),
					call);
			}

			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText() + ": " + this.check.GetInfoText();
		}
	}

	[ORKEditorHelp("Action Time", "A combatant's current action time is used.\n" +
		"The action time is an optional feature to limit the time a combatant has to perform actions.", "")]
	[ORKNodeInfo("Combatant")]
	public class ActionTimeStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Use Maximum", "Use the maximum action time of the combatant.", "")]
		public bool useMax = false;

		[ORKEditorHelp("Use Average", "Use the average action time of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		public ActionTimeStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useAverage)
				{
					if(this.onlyBattle)
					{
						value = this.useMax ?
							c.Group.AverageBattleActionTimeMax :
							c.Group.AverageBattleActionTime;
					}
					else
					{
						value = this.useMax ?
							c.Group.AverageActionTimeMax :
							c.Group.AverageActionTime;
					}
				}
				else
				{
					value = this.useMax ?
						c.Battle.ActionTimeMax :
						c.Battle.ActionTime;
				}
				ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() +
				(this.useAverage ? " Avg. Action Time" : " Action Time") +
				(this.useMax ? " Max" : "");
		}
	}

	[ORKEditorHelp("Check Action Time", "Checks a combatant's action time.\n" +
		"The action time is an optional feature to limit the time a combatant has to perform actions." +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Check", "Combatant")]
	public class CheckActionTimeStep : BaseFormulaCheckStep
	{
		// status value
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Use Maximum", "Use the maximum action time of the combatant.", "")]
		public bool useMax = false;

		[ORKEditorHelp("Use Average", "Use the average action time of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		// check
		[ORKEditorInfo(separator=true)]
		public FormulaValueCheck check = new FormulaValueCheck();

		public CheckActionTimeStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.check.UpgradeFormulaFloat(data, "check", "turn", "turn2");
		}

		public override int Calculate(FormulaCall call)
		{
			bool check = false;

			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				check = this.check.Check(
					this.useMax ?
						(this.useAverage ?
							(this.onlyBattle ? c.Group.AverageBattleActionTimeMax : c.Group.AverageActionTimeMax) :
							c.Battle.ActionTimeMax) :
						(this.useAverage ?
							(this.onlyBattle ? c.Group.AverageBattleActionTime : c.Group.AverageActionTime) :
							c.Battle.ActionTime),
					call);
			}

			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText() + ": " + this.check.GetInfoText();
		}
	}

	[ORKEditorHelp("Grid Move Range", "A combatant's current grid move range is used (only available in grid battles).", "")]
	[ORKNodeInfo("Combatant")]
	public class MoveRangeStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Use Maximum", "Use the maximum move range of the combatant.", "")]
		public bool useMax = false;

		[ORKEditorHelp("Use Average", "Use the average move range of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		public MoveRangeStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ORK.Battle.Grid != null)
			{
				Combatant c = this.origin.GetCombatant(call);
				if(c != null)
				{
					float value = 0;
					if(this.useAverage)
					{
						if(this.onlyBattle)
						{
							value = this.useMax ?
								c.Group.AverageBattleGridMoveRangeMax :
								c.Group.AverageBattleGridMoveRange;
						}
						else
						{
							value = this.useMax ?
								c.Group.AverageGridMoveRangeMax :
								c.Group.AverageGridMoveRange;
						}
					}
					else
					{
						value = this.useMax ?
							c.Battle.GridMoveRangeMax :
							c.Battle.GridMoveRange;
					}
					ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
				}
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() +
				(this.useAverage ? " Avg. Move Range" : " Move Range") +
				(this.useMax ? " Max" : "");
		}
	}

	[ORKEditorHelp("Check Grid Move Range", "Checks a combatant's current grid move range (only available in grid battles).\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Check", "Combatant")]
	public class CheckMoveRangeStep : BaseFormulaCheckStep
	{
		// status value
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Use Maximum", "Use the maximum move range of the combatant.", "")]
		public bool useMax = false;

		[ORKEditorHelp("Use Average", "Use the average move range of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		// check
		[ORKEditorInfo(separator=true)]
		public FormulaValueCheck check = new FormulaValueCheck();

		public CheckMoveRangeStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.check.UpgradeFormulaFloat(data, "check", "turn", "turn2");
		}

		public override int Calculate(FormulaCall call)
		{
			bool check = false;

			if(ORK.Battle.Grid != null)
			{
				Combatant c = this.origin.GetCombatant(call);
				if(c != null)
				{
					check = this.check.Check(
						this.useMax ?
							(this.useAverage ?
								(this.onlyBattle ? c.Group.AverageBattleGridMoveRangeMax : c.Group.AverageGridMoveRangeMax) :
								c.Battle.GridMoveRangeMax) :
							(this.useAverage ?
								(this.onlyBattle ? c.Group.AverageBattleGridMoveRange : c.Group.AverageGridMoveRange) :
								c.Battle.GridMoveRange),
						call);
				}
			}

			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText() + ": " + this.check.GetInfoText();
		}
	}

	[ORKEditorHelp("Inventory Space", "A combatant's used (occupied) or maximum inventory space is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class InventorySpaceStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Use Maximum", "The maximum inventory space is used.\n" +
			"If disabled, the currently used (occupied) inventory space is used.", "")]
		public bool useMax = false;

		public InventorySpaceStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				float value = 0;
				if(this.useMax)
				{
					value = c.Inventory.TotalSpace;
				}
				else
				{
					value = c.Inventory.Space;
				}
				ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() + (this.useMax ? " Max" : "");
		}
	}

	[ORKEditorHelp("Inventory Quantity", "The quantity of an item, equipment, currency, " +
		"AI behaviour or AI ruleset in a combatant's inventory is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class InventoryQuantityStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();


		// item selection
		[ORKEditorHelp("Type", "Select the type, either an item, weapon, armor, currency (money), " +
			"AI behaviour, AI ruleset or crafting recipe.", "")]
		[ORKEditorInfo(separator=true, labelText="Item Settings")]
		public ItemDropType type = ItemDropType.Item;

		[ORKEditorHelp("Selection", "Select the item based on the selected type.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="type")]
		public int itemID = 0;

		public InventoryQuantityStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant combatant = this.origin.GetCombatant(call);

			if(combatant != null)
			{
				int quantity = 0;
				if(ItemDropType.Item == this.type)
				{
					quantity = combatant.Inventory.Items.GetCount(this.itemID);
				}
				else if(ItemDropType.Weapon == this.type)
				{
					quantity = combatant.Inventory.Weapons.GetCount(this.itemID);
				}
				else if(ItemDropType.Armor == this.type)
				{
					quantity = combatant.Inventory.Armors.GetCount(this.itemID);
				}
				else if(ItemDropType.Currency == this.type)
				{
					quantity = combatant.Inventory.GetMoney(this.itemID);
				}
				else if(ItemDropType.AIBehaviour == this.type)
				{
					quantity = combatant.Inventory.AIBehaviours.GetCount(this.itemID);
				}
				else if(ItemDropType.AIRuleset == this.type)
				{
					quantity = combatant.Inventory.AIRulesets.GetCount(this.itemID);
				}
				else if(ItemDropType.CraftingRecipe == this.type)
				{
					quantity = combatant.Inventory.Crafting.GetCount(this.itemID);
				}
				ValueHelper.UseOperator(ref call.result, quantity, this.formulaOperator);
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(ItemDropType.Item == this.type)
			{
				return this.formulaOperator + " " + this.origin.GetInfoText() +
					": " + ORK.Items.GetName(this.itemID);
			}
			else if(ItemDropType.Weapon == this.type)
			{
				return this.formulaOperator + " " + this.origin.GetInfoText() +
					": " + ORK.Weapons.GetName(this.itemID);
			}
			else if(ItemDropType.Armor == this.type)
			{
				return this.formulaOperator + " " + this.origin.GetInfoText() +
					": " + ORK.Armors.GetName(this.itemID);
			}
			else if(ItemDropType.Currency == this.type)
			{
				return this.formulaOperator + " " + this.origin.GetInfoText() +
					": " + ORK.Currencies.GetName(this.itemID);
			}
			else if(ItemDropType.AIBehaviour == this.type)
			{
				return this.formulaOperator + " " + this.origin.GetInfoText() +
					": " + ORK.AIBehaviours.GetName(this.itemID);
			}
			else if(ItemDropType.AIRuleset == this.type)
			{
				return this.formulaOperator + " " + this.origin.GetInfoText() +
					": " + ORK.AIRulesets.GetName(this.itemID);
			}
			else if(ItemDropType.CraftingRecipe == this.type)
			{
				return this.formulaOperator + " " + this.origin.GetInfoText() +
					": " + ORK.CraftingRecipes.GetName(this.itemID);
			}
			return this.formulaOperator + " " + this.origin.GetInfoText();
		}
	}

	[ORKEditorHelp("Check Status", "Checks a combatant on certain status requirements, e.g. status value.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Combatant", "Check")]
	public class CheckStatusStep : BaseFormulaCheckStep
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();


		// requirements
		[ORKEditorHelp("Needed", "Either all or only one requirement must be met.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Status Requirements")]
		public Needed needed = Needed.All;

		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "",
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid.", ""
		})]
		public StatusRequirement[] req = new StatusRequirement[] {new StatusRequirement()};

		public CheckStatusStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			bool check = true;
			bool any = false;

			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				any = true;
				if(!StatusRequirement.Check(c, this.req, this.needed))
				{
					check = false;
				}
			}

			if(any && check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}

		public override int CalculatePreview(FormulaCall call)
		{
			bool check = true;
			bool any = false;

			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				any = true;
				if(!StatusRequirement.CheckPreview(c, this.req, this.needed))
				{
					check = false;
				}
			}

			if(any && check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText();
		}
	}

	[ORKEditorHelp("Status Fork", "Checks a combatant for certain status requirements.\n" +
		"If a requirement is valid, it's next step will be executed.\n" +
		"If no requirement is valid, 'Failed' will be executed.", "")]
	[ORKNodeInfo("Check", "Combatant")]
	public class StatusForkStep : BaseFormulaStep
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "",
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid.", ""
		})]
		public StatusRequirementNextNode[] req = new StatusRequirementNextNode[] {new StatusRequirementNextNode()};

		public StatusForkStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				for(int i = 0; i < this.req.Length; i++)
				{
					if(this.req[i].CheckRequirement(c))
					{
						return this.req[i].next;
					}
				}
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);
			if(c != null)
			{
				for(int i = 0; i < this.req.Length; i++)
				{
					if(this.req[i].CheckRequirementPreview(c))
					{
						return this.req[i].next;
					}
				}
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText();
		}

		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1) + ": " + this.req[index - 1].GetInfoText();
			}
			return "";
		}

		public override int GetNextCount()
		{
			return this.req.Length + 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.req[index - 1].next;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.req[index - 1].next = next;
			}
		}
	}

	[ORKEditorHelp("Equipment Durability", "The durability of an equipment stored in selected data is used.", "")]
	[ORKNodeInfo("Combatant")]
	public class EquipmentDurabilityStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorHelp("Use Max Durability", "Use the maximum durability of the equipment.", "")]
		public bool useMaxDurability = false;

		[ORKEditorInfo(separator=true, labelText="Selected Key")]
		public FormulaSelectedData selectedData = new FormulaSelectedData();

		[ORKEditorHelp("Use First", "Use the durability of the first found durable equipment stored in the defined selected data.\n" +
			"If disabled, the durability of all stored equipment will be used.", "")]
		public bool useFirst = false;

		public EquipmentDurabilityStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<DataObject>("selectedKey"))
			{
				this.selectedData.SetData(data);
			}
		}

		public override int Calculate(FormulaCall call)
		{
			List<EquipShortcut> equipment = SelectedDataHelper.GetEquipment(
				this.selectedData.GetSelectedData(call));
			float value = 0;
			for(int i = 0; i < equipment.Count; i++)
			{
				if(equipment[i] != null &&
					equipment[i].UseDurability)
				{
					value += this.useMaxDurability ?
						equipment[i].MaxDurability :
						equipment[i].Durability;
					if(this.useFirst)
					{
						break;
					}
				}
			}
			ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.selectedData.GetInfoText() +
				(this.useFirst ? " (First)" : " (All)");
		}
	}

	[ORKEditorHelp("Is Player", "Checks a combatant is the player or a member of the player group.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Combatant", "Check")]
	public class IsPlayerStep : BaseFormulaCheckStep
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Player/Member", "If enabled, checks if the combatant is the player combatant.\n" +
			"If disabled, checks if the combatant is a member of the active player group.", "")]
		public bool isPlayer = true;

		public IsPlayerStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant c = this.origin.GetCombatant(call);

			if(c != null &&
				(this.isPlayer ?
					ORK.Game.PlayerHandler.IsPlayer(c) :
					c.IsPlayerControlled()))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText() +
				(this.isPlayer ? ": Player" : ": Member");
		}
	}

	[ORKEditorHelp("Is Enemy", "Checks if user and target are enemies.\n" +
		"If the check is valid, 'Enemies' will be executed, otherwise 'Allies'.", "")]
	[ORKNodeInfo("Combatant", "Check")]
	public class IsEnemyStep : BaseFormulaCheckStep
	{
		public IsEnemyStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(call.user.IsEnemy(call.target))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Enemies";
			}
			else if(index == 1)
			{
				return "Allies";
			}
			return "";
		}
	}

	[ORKEditorHelp("Battle Statistic", "A defined battle statistic value of a combatant is used.\n" +
		"Requires using the 'Combatant Battle Statistics' settings defined in 'Battle System > Battle Settings'.", "")]
	[ORKNodeInfo("Combatant")]
	public class BattleStatisticStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Whole Group", "Use the received damage from all members of the combatant's group.", "")]
		[ORKEditorInfo(separator=true)]
		public bool wholeGroup = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("wholeGroup", true)]
		public bool onlyBattle = true;

		[ORKEditorHelp("Multi Value Use", "Select how values of multiple combatants will be used:\n" +
			"- First: Use the first available value.\n" +
			"- Lowest: Use the lowest available value.\n" +
			"- Highest: Use the highest available value.\n" +
			"- Average: Use the average of all available values.\n" +
			"- Add: Sum all available values (i.e. value1 + value 2 + value3 ...).\n" +
			"- Sub: Subtract all available values (i.e. value1 - value2 - value3 ...).\n" +
			"- Multiply: Multiply all available values (i.e. value1 * value2 * value3 ...).\n" +
			"- Divide: Divide all available values (i.e. value1 / value2 / value3 ...).", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public MultiFloatValueUse multiValueType = MultiFloatValueUse.Add;


		// statistic
		[ORKEditorHelp("Statistic Key", "The key used to identify the statistic value.", "")]
		[ORKEditorInfo(separator=true, expandWidth=true)]
		public string statisticKey = "";

		[ORKEditorHelp("Value Source", "Select which statistic value will be used:\n" +
			"- Decrease Received: A value decrease the combatant received (e.g. received damage).\n" +
			"- Decrease Given: A value decrease the combatant gave (e.g. dealt damage).\n" +
			"- Increase Received: A value increase the combatant received (e.g. getting healed).\n" +
			"- Increase Given: A value increase the combatant gave (e.g. healing others).", "")]
		public ValueStatistic.Source valueSource = ValueStatistic.Source.DecreaseReceived;

		[ORKEditorHelp("Use Total Change", "Use the total change the combatant registered.\n" +
			"If disabled, uses the change registered from the user (requires using 'Per Combatant' statistics).", "")]
		[ORKEditorInfo(separator=true)]
		public bool useTotalChange = true;


		// source combatant
		[ORKEditorInfo(separator=true, labelText="Source Combatant")]
		[ORKEditorLayout("useTotalChange", false, endCheckGroup=true, autoInit=true)]
		public FormulaStatusOrigin changeOrigin;

		public BattleStatisticStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ORK.Battle.Settings.battleStatistics.useStatictics &&
				(this.useTotalChange ||
					ORK.Battle.Settings.battleStatistics.usePerCombatant))
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null)
				{
					Combatant source = this.useTotalChange ?
						null : this.changeOrigin.GetCombatant(call);
					float value = 0;
					if(this.wholeGroup)
					{
						value = this.GetGroupValue(this.onlyBattle ?
							combatant.Group.GetBattle() : combatant.Group.GetGroup(),
							source);
					}
					else
					{
						if(source != null)
						{
							value = combatant.Battle.Statistic[this.statisticKey].PerCombatant(source).GetValue(this.valueSource);
						}
						else
						{
							value = combatant.Battle.Statistic[this.statisticKey].Total.GetValue(this.valueSource);
						}
					}
					ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
				}
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			// no preview
			return this.next;
		}

		private float GetGroupValue(List<Combatant> list, Combatant source)
		{
			List<float> values = new List<float>();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(source != null)
					{
						values.Add(list[i].Battle.Statistic[this.statisticKey].PerCombatant(source).GetValue(this.valueSource));
					}
					else
					{
						values.Add(list[i].Battle.Statistic[this.statisticKey].Total.GetValue(this.valueSource));
					}
				}
			}

			if(values.Count > 0)
			{
				return ValueHelper.GetMultiValue(values, this.multiValueType);
			}
			return 0;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() +
				(this.useTotalChange ? " total change" : " from " + this.changeOrigin.GetInfoText()) +
				": " + this.statisticKey + " " + this.valueSource;
		}
	}

	[ORKEditorHelp("Combatant Count", "The number of combatants in the scene is used.\n" +
		"The found combatants can be filtered by different settings, e.g. being enemy of a user or status requirements.", "")]
	[ORKNodeInfo("Combatant")]
	public class CombatantCountStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true, labelText="User Combatant")]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();


		// range
		[ORKEditorHelp("Check Range", "Only search within a defined range of the user or a position.", "")]
		[ORKEditorInfo(separator=true, labelText="Range Settings")]
		public bool checkRange = false;

		[ORKEditorHelp("From Position", "Check the range from a defined position.\n" +
			"If disabled, the range will be checked from the user's position.", "")]
		[ORKEditorLayout("checkRange", true)]
		public bool checkPosition = false;

		[ORKEditorLayout(autoInit=true)]
		public Range range;

		[ORKEditorInfo(separator=true, labelText="Search Position")]
		[ORKEditorLayout("checkPosition", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public Vector3Value position;


		// search settings
		public SearchCombatantSettings search = new SearchCombatantSettings();

		public CombatantCountStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant user = this.origin.GetCombatant(call);
			if(user != null)
			{
				List<Combatant> found = this.checkRange && this.checkPosition ?
					this.search.Search(this.position.GetValue(), user, this.checkRange ? this.range : Range.Infinity) :
					this.search.Search(user, this.checkRange ? this.range : Range.Infinity);

				ValueHelper.UseOperator(ref call.result, found.Count, this.formulaOperator);
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			return this.Calculate(call);
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText();
		}
	}

	[ORKEditorHelp("Store Combatant Count", "Stores the number of combatants in the scene into a float variable.\n" +
		"The found combatants can be filtered by different settings, e.g. being enemy of a user or status requirements.", "")]
	[ORKNodeInfo("Combatant", "Variable")]
	public class StoreCombatantCountStep : BaseFormulaStep
	{
		// variable settings
		[ORKEditorInfo(labelText="Variable Settings")]
		public FormulaVariableOrigin variableOrigin = new FormulaVariableOrigin();


		// variable key
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue key = new StringValue();

		[ORKEditorHelp("Operator", "Defines how the variable will be changed:\n" +
			"- Add: Adds the value to the current value of the variable.\n" +
			"- Sub: Subtracts the value from the current value of the variable.\n" +
			"- Multiply: Multiplies the current value of the variable with the value.\n" +
			"- Divide: Divides the current value of the variable by the value.\n" +
			"- Modulo: Uses the modulo operator, current value of the variable % the value.\n" +
			"- Power Of: The current variable value to the power of the value.\n" +
			"- Log: The current variable value is used in a logarithmic calculation with the value as base.\n" +
			"- Set: Sets the current variable value to the value.", "")]
		public FormulaOperator floatOperator = FormulaOperator.Set;


		// user
		[ORKEditorInfo(separator=true, labelText="User Combatant")]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();


		// range
		[ORKEditorHelp("Check Range", "Only search within a defined range of the user or a position.", "")]
		[ORKEditorInfo(separator=true, labelText="Range Settings")]
		public bool checkRange = false;

		[ORKEditorHelp("From Position", "Check the range from a defined position.\n" +
			"If disabled, the range will be checked from the user's position.", "")]
		[ORKEditorLayout("checkRange", true)]
		public bool checkPosition = false;

		[ORKEditorLayout(autoInit=true)]
		public Range range;

		[ORKEditorInfo(separator=true, labelText="Search Position")]
		[ORKEditorLayout("checkPosition", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public Vector3Value position;


		// search settings
		[ORKEditorInfo(separator=true)]
		public SearchCombatantSettings search = new SearchCombatantSettings();

		public StoreCombatantCountStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant user = this.origin.GetCombatant(call);
			if(user != null)
			{
				List<Combatant> found = this.checkRange && this.checkPosition ?
					this.search.Search(this.position.GetValue(), user, this.checkRange ? this.range : Range.Infinity) :
					this.search.Search(user, this.checkRange ? this.range : Range.Infinity);

				this.variableOrigin.ChangeFloat(call, this.key.GetValue(), found.Count, this.floatOperator);
			}
			return this.next;
		}

		public override int CalculatePreview(FormulaCall call)
		{
			return this.Calculate(call);
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variableOrigin.GetInfoText() + ": " + this.key.GetInfoText();
		}
	}

	[ORKEditorHelp("Check Equipment", "Checks the equipment of a combatant.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Combatant", "Check")]
	public class CheckEquipmentStep : BaseFormulaCheckStep
	{
		// status value
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart, separator=true)]
		public int partID = 0;

		[ORKEditorHelp("Check Blocking Part", "Check the equipment of the part that's blocking the selected equipment part.", "")]
		public bool checkBlockingPart = false;


		// selected data
		[ORKEditorHelp("Use Selected Data", "Check for an equipment stored in selected data.", "")]
		public bool useSelectedData = false;

		[ORKEditorInfo(labelText="Selected Key")]
		[ORKEditorLayout("useSelectedData", true, autoInit=true)]
		public FormulaSelectedData selectedData;


		// equipment
		[ORKEditorHelp("Equip", "Select how the equipment part will be checked:\n" +
			"- None: The equipment part has to be unequipped.\n" +
			"- Weapon: A weapon has to be equipped.\n" +
			"- Armor: An armor has to be equipped.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(elseCheckGroup=true)]
		public EquipSet equip = EquipSet.None;

		[ORKEditorHelp("Check Equipment Part", "Checks the equipment part to be " +
			"equipped with a weapon or equipped with an armor - doesn't check for a specific equipment.\n" +
			"If disabled, you'll have to define the weapon/armor that should be checked for.", "")]
		[ORKEditorLayout("equip", EquipSet.None, elseCheckGroup=true)]
		public bool checkPart = false;

		[ORKEditorHelp("Equipment", "Select the equipment that will be checked for.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="equip")]
		[ORKEditorLayout("checkPart", false, endCheckGroup=true, endGroups=3)]
		public int equipID = 0;

		public CheckEquipmentStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(this.useSelectedData &&
				data.Contains<DataObject>("selectedKey"))
			{
				this.selectedData = new FormulaSelectedData();
				this.selectedData.SetData(data);
			}
		}

		public override int Calculate(FormulaCall call)
		{
			if(this.Check(call))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}

		private bool Check(FormulaCall call)
		{
			if(this.useSelectedData)
			{
				List<EquipShortcut> equipList = SelectedDataHelper.GetEquipment(
					this.selectedData.GetSelectedData(call));
				if(equipList != null &&
					equipList.Count > 0)
				{
					Combatant user = this.origin.GetCombatant(call);
					if(user != null)
					{
						// get linked part for multi-part equipments
						int tmpPartID = this.partID;
						if(user.Equipment[tmpPartID].IsLinked ||
							(this.checkBlockingPart &&
								user.Equipment[tmpPartID].IsBlocked))
						{
							user.Equipment[tmpPartID].GetRealPartID(ref tmpPartID);
						}

						for(int j = 0; j < equipList.Count; j++)
						{
							if(user.Equipment[tmpPartID].Equipped &&
								user.Equipment[tmpPartID].Equipment == equipList[j])
							{
								return true;
							}
						}
					}
				}
			}
			else
			{
				Combatant user = this.origin.GetCombatant(call);
				if(user != null)
				{
					// get linked part for multi-part equipments
					int tmpPartID = this.partID;
					if(user.Equipment[tmpPartID].IsLinked ||
						(this.checkBlockingPart &&
							user.Equipment[tmpPartID].IsBlocked))
					{
						user.Equipment[tmpPartID].GetRealPartID(ref tmpPartID);
					}

					if((EquipSet.None == this.equip &&
							!user.Equipment[tmpPartID].Equipped) ||
						(EquipSet.None != this.equip &&
							user.Equipment[tmpPartID].Equipped &&
							user.Equipment[tmpPartID].Equipment.Type == this.equip &&
							(this.checkPart || user.Equipment[tmpPartID].Equipment.ID == this.equipID)))
					{
						return true;
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.EquipmentParts.GetName(this.partID);
		}
	}

	[ORKEditorHelp("Equipment Fork", "Checks a selected equipment part of a combatant.\n" +
		"If an equipment condition is valid, it's next step will be executed.\n" +
		"If no condition is valid, 'Failed' will be executed.", "")]
	[ORKNodeInfo("Combatant", "Check")]
	public class EquipmentForkStep : BaseFormulaStep
	{
		// status value
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart, separator=true)]
		public int partID = 0;

		[ORKEditorHelp("Check Blocking Part", "Check the equipment of the part that's blocking the selected equipment part.", "")]
		public bool checkBlockingPart = false;


		// checks
		[ORKEditorArray(false, "Add Check", "Adds a new equipment condition.", "",
			"Remove", "Removes the equipment condition.", "", isMove=true, isCopy=true,
			noRemoveCount=1, foldout=true, foldoutText=new string[] {
				"Equipment Condition", "Define the game variable condition that must be valid.", ""
		})]
		public EquipmentConditionFormulaNextNode[] condition = new EquipmentConditionFormulaNextNode[] {new EquipmentConditionFormulaNextNode()};

		public EquipmentForkStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant user = this.origin.GetCombatant(call);
			if(user != null)
			{
				// get linked part for multi-part equipments
				int tmpPartID = this.partID;
				if(user.Equipment[tmpPartID].IsLinked ||
					(this.checkBlockingPart &&
						user.Equipment[tmpPartID].IsBlocked))
				{
					user.Equipment[tmpPartID].GetRealPartID(ref tmpPartID);
				}

				for(int j = 0; j < this.condition.Length; j++)
				{
					if(this.condition[j].useSelectedData)
					{
						List<EquipShortcut> equipList = SelectedDataHelper.GetEquipment(
							this.condition[j].selectedData.GetSelectedData(call));
						if(equipList != null &&
							equipList.Count > 0)
						{
							for(int k = 0; k < equipList.Count; k++)
							{
								if(user.Equipment[tmpPartID].Equipped &&
									user.Equipment[tmpPartID].Equipment == equipList[k])
								{
									return this.condition[j].next;
								}
							}
						}
					}
					else
					{
						if((EquipSet.None == this.condition[j].equip &&
								!user.Equipment[tmpPartID].Equipped) ||
							(EquipSet.None != this.condition[j].equip &&
								user.Equipment[tmpPartID].Equipped &&
								user.Equipment[tmpPartID].Equipment.Type == this.condition[j].equip &&
								user.Equipment[tmpPartID].Equipment.ID == this.condition[j].id))
						{
							return this.condition[j].next;
						}
					}
				}
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.EquipmentParts.GetName(this.partID);
		}

		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1) + ": " + this.condition[index - 1].GetInfoText();
			}
			return "";
		}

		public override int GetNextCount()
		{
			return this.condition.Length + 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.condition[index - 1].next;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.condition[index - 1].next = next;
			}
		}
	}
}
