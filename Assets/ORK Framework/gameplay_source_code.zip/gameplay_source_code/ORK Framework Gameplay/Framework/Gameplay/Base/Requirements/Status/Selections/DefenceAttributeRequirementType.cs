﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Defence Attribute", "The combatant must have the selected defence attribute, or compares it to a defined value.", "")]
	public class DefenceAttributeRequirementType : BaseStatusRequirementType
	{
		public DefenceAttributeSelection selection = new DefenceAttributeSelection();

		[ORKEditorHelp("Check Value", "Check the current value of the selected defence attribute.\n" +
			"If disabled, the combatant's current defence attribute is checked.", "")]
		public bool checkValue = false;

		[ORKEditorHelp("Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the attribute.\n" +
			"- Base Value: The base value of the attribute (without bonuses).\n" +
			"- Min Value: The minimum value of the attribute.\n" +
			"- Max Value: The maximum value of the attribute.\n" +
			"- Start Value: The start value of the attribute (i.e. the attribute's initial value).\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.", "")]
		[ORKEditorLayout("checkValue", true)]
		public AttributeGetValue getValue = AttributeGetValue.CurrentValue;

		[ORKEditorLayout(endCheckGroup=true)]
		public ValueCheck check = new ValueCheck();

		public DefenceAttributeRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.selection.index);
				data.Get("selectionID2", ref this.selection.subIndex);
				data.Get("checkDefAttrVal", ref this.checkValue);
				data.GetEnum("attrGetValue", ref this.getValue);
			}
			this.check.UpgradeFloat(data, "comparison", "value");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.checkValue)
			{
				return this.check.Check(
					combatant.Status.GetDefenceAttribute(this.selection.index).
						GetTypeValue(this.selection.subIndex, this.getValue),
					combatant);
			}
			else
			{
				return combatant.Status.GetDefenceAttributeID(this.selection.index).GetID() == this.selection.subIndex;
			}
		}

		public override bool CheckPreview(Combatant combatant)
		{
			if(this.checkValue)
			{
				return this.check.Check(
					combatant.Status.GetDefenceAttribute(this.selection.index).GetPreviewValue(this.selection.subIndex),
					combatant);
			}
			else
			{
				return combatant.Status.GetDefenceAttributeID(this.selection.index).GetID() == this.selection.subIndex;
			}
		}

		public override bool CheckBestiary(Combatant combatant)
		{
			if(combatant.Bestiary != null)
			{
				if(this.checkValue)
				{
					if(combatant.Bestiary.IsComplete ||
						combatant.Bestiary.status.defenceAttribute[this.selection.index].attribute[this.selection.subIndex])
					{
						return this.check.Check(
							combatant.Status.GetDefenceAttribute(this.selection.index).
								GetTypeValue(this.selection.subIndex, this.getValue),
							combatant);
					}
				}
				else if(combatant.Bestiary.IsComplete ||
					combatant.Bestiary.status.defAttrID[this.selection.index])
				{
					return combatant.Status.GetDefenceAttributeID(this.selection.index).GetID() == this.selection.subIndex;
				}
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			if(this.checkValue)
			{
				combatant.Status.GetDefenceAttribute(this.selection.index).Changed += notify.DefenceAttributeChanged;
			}
			else
			{
				combatant.Status.GetDefenceAttributeID(this.selection.index).Changed += notify.DefenceAttributeIDChanged;
			}
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			if(this.checkValue)
			{
				combatant.Status.GetDefenceAttribute(this.selection.index).Changed -= notify.DefenceAttributeChanged;
			}
			else
			{
				combatant.Status.GetDefenceAttributeID(this.selection.index).Changed -= notify.DefenceAttributeIDChanged;
			}
		}
	}
}
