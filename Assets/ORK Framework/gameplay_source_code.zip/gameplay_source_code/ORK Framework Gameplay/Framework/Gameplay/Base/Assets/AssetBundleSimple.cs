﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class AssetBundleSimple : BaseData
	{
		[ORKEditorHelp("Asset Name", "Define the name of the asset in the asset bundle.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string assetName = "";

		[ORKEditorHelp("Asset Bundle Name", "Define the name of the asset bundle.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string assetBundleName = "";

		[ORKEditorHelp("Path Origin", "Select where the path is located:\n" +
			"- None: Only uses the defined path.\n" +
			"- Data Path: Uses 'Application.dataPath'.\n" +
			"- Persistent Data Path: Uses 'Application.persistentDataPath'.\n" +
			"- Streaming Asset Path: Uses 'Application.streamingAssetsPath', " +
			"usually located at 'Assets/StreamingAssets/' in your Unity project.\n" +
			"- Temporary Cache Path: Uses 'Application.temporaryCachePath'.", "")]
		public ApplicationPathType pathOrigin = ApplicationPathType.DataPath;

		[ORKEditorHelp("Path", "Define the path within the path origin.", "")]
		public string path = "";

		[ORKEditorHelp("Load Type", "Select the way this asset bundle will be loaded:\n" +
			"- Load From File: Uses 'AssetBundle.LoadFromFile'.\n" +
			"- Load From Memory: Uses 'AssetBundle.LoadFromMemory' after loading the bundle's data via 'File.ReadAllBytes'.", "")]
		public AssetBundleLoadType loadType = AssetBundleLoadType.LoadFromFile;

		public AssetBundleSimple()
		{

		}

		public T GetAsset<T>() where T : Object
		{
			return AssetSourceCache.Instance.GetFromAssetBundle<T>(
				System.IO.Path.Combine(
					ApplicationPath.GetPath(this.pathOrigin, this.path),
					this.assetBundleName),
				this.assetName,
				this.loadType);
		}
	}
}
