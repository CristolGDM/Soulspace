﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IRenameable
	{
		string RenameableName
		{
			get;
			set;
		}
	}
}
