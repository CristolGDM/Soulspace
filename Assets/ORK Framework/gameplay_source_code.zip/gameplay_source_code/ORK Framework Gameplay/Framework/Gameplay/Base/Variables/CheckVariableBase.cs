
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class CheckVariableBase : BaseData, ISerializationCallbackReceiver
	{
		[ORKEditorHelp("Is Valid", "The check must be valid.\n" +
			"If disabled, the check must be invalid.", "")]
		[ORKEditorInfo(separator=true)]
		public bool isValid = true;

		[ORKEditorHelp("Type", "Select the type of the game variable:\n" +
			"- String: A string variable.\n" +
			"- Bool: A bool variable.\n" +
			"- Float: A float variable.\n" +
			"- Vector3: A Vector3 variable (checks distance between 2 Vector3 values).", "")]
		public GameVariableType type = GameVariableType.String;


		// string
		[ORKEditorInfo(labelText="String Value")]
		[ORKEditorLayout("type", GameVariableType.String, endCheckGroup=true, autoInit=true)]
		public StringValue stringValue;


		// float/vector3
		[System.NonSerialized]
		[ORKEditorLayout(new string[] { "type", "type" },
			new object[] { GameVariableType.Float, GameVariableType.Vector3 },
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public ValueCheck check;

		[SerializeField]
		private ORKDataFile serialize_check;


		// vector3
		[ORKEditorInfo("Vector3 Value", "The Vector3 value used for the distance check.", "",
			endFoldout=true)]
		[ORKEditorLayout("type", GameVariableType.Vector3, endCheckGroup=true, autoInit=true)]
		public Vector3Value vector3Value;


		// old for component update
		[SerializeField]
		private VariableValueCheck floatCheck = VariableValueCheck.None;

		[SerializeField]
		private FloatValue floatValue;

		[SerializeField]
		private FloatValue floatValue2;

		[SerializeField]
		private VariableValueCheck vector3Check = VariableValueCheck.None;

		[SerializeField]
		private FloatValue vector3Distance;

		[SerializeField]
		private FloatValue vector3Distance2;

		public enum VariableValueCheck { IsEqual, IsLess, IsGreater, NotEqual, RangeInclusive, RangeExclusive, Approximately, None };

		public CheckVariableBase()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(GameVariableType.Float == this.type &&
				data.Contains<int>("floatCheck"))
			{
				this.check = new ValueCheck();
				this.check.UpgradeFloatValue(data, "floatCheck", "floatValue", "floatValue2");
			}
			else if(GameVariableType.Vector3 == this.type &&
				data.Contains<int>("vector3Check"))
			{
				this.check = new ValueCheck();
				if(data.Contains<float>("vector3Distance"))
				{
					this.check.UpgradeFloat(data, "vector3Check", "vector3Distance", "vector3Distance2");
				}
				else
				{
					this.check.UpgradeFloatValue(data, "vector3Check", "vector3Distance", "vector3Distance2");
				}
			}
		}

		public bool Check(string key, VariableHandler handler)
		{
			if(GameVariableType.String == this.type)
			{
				return this.isValid == handler.Check(key, this.stringValue.GetValue());
			}
			else if(GameVariableType.Bool == this.type)
			{
				return this.isValid == handler.Check(key, true);
			}
			else if(GameVariableType.Float == this.type)
			{
				return this.isValid == handler.CheckFloat(key,
					this.check.value.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader),
					this.check.value2 != null ?
						this.check.value2.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader) :
						0,
					this.check.type);
			}
			else if(GameVariableType.Vector3 == this.type)
			{
				return this.isValid == handler.CheckVector3(key,
					this.vector3Value.GetValue(),
					this.check.value.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader),
					this.check.value2 != null ?
						this.check.value2.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader) :
						0,
					this.check.type);
			}
			return false;
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			return (this.isValid ? "is" : "is not") + " (" + this.type + ") ";
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public void OnBeforeSerialize()
		{
			if((GameVariableType.Float == this.type ||
			   	GameVariableType.Vector3 == this.type) &&
				this.check != null)
			{
				this.serialize_check = this.check.GetData().GetDataFile("check", false);
			}
		}

		public void OnAfterDeserialize()
		{
			if(GameVariableType.Float == this.type &&
				this.floatCheck != VariableValueCheck.None)
			{
				DataObject data = new DataObject();
				data.SetEnum("floatCheck", this.floatCheck);
				data.Set("floatValue", this.floatValue.GetData());
				data.Set("floatValue2", this.floatValue2.GetData());
				this.check = new ValueCheck();
				this.check.UpgradeFloatValue(data, "floatCheck", "floatValue", "floatValue2");
				this.floatCheck = VariableValueCheck.None;
				this.floatValue = null;
				this.floatValue2 = null;
				this.vector3Check = VariableValueCheck.None;
				this.vector3Distance = null;
				this.vector3Distance2 = null;
			}
			else if(GameVariableType.Vector3 == this.type &&
				this.vector3Check != VariableValueCheck.None)
			{
				this.check = new ValueCheck();
				DataObject data = new DataObject();
				data.SetEnum("vector3Check", this.vector3Check);
				data.Set("vector3Distance", this.vector3Distance.GetData());
				data.Set("vector3Distance2", this.vector3Distance2.GetData());
				this.check.UpgradeFloatValue(data, "vector3Check", "vector3Distance", "vector3Distance2");
				this.floatCheck = VariableValueCheck.None;
				this.floatValue = null;
				this.floatValue2 = null;
				this.vector3Check = VariableValueCheck.None;
				this.vector3Distance = null;
				this.vector3Distance2 = null;
			}
			else if(this.serialize_check != null)
			{
				this.check = new ValueCheck();
				this.check.SetData(this.serialize_check.ToDataObject());
				this.serialize_check = null;
			}
		}
	}
}
