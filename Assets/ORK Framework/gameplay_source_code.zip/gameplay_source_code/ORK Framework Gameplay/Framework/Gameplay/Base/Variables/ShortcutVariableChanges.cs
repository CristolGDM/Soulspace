﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ShortcutVariableChanges : BaseData
	{
		[ORKEditorHelp("Save Variables", "The variables will be saved with save games.", "")]
		public bool variableSave = true;

		[ORKEditorHelp("Use When Loading", "Use the variable changes when loading from a save game.\n" +
			"This will reset changes that where made in the saved version, " +
			"or makes sure that changes to the settings are also available in save games that where saved before.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("variableSave", true, endCheckGroup=true)]
		public bool variableUseWhenLoading = true;

		[ORKEditorHelp("Use In Description", "Replace variable text codes in the description with these variables.\n" +
			"If disabled, the description will use global variables.", "")]
		public bool useVariableDescription = false;

		[ORKEditorHelp("Use Update Variables", "Update variable changes are used when the variables are changed.\n" +
			"These variable changes will also be used when first initializing the variables (after the regular variable changes)." +
			"E.g. use this if a variable holds the result of a formula that depends on other variables.", "")]
		public bool useUpdateVariables = false;

		public VariableSetter variableChanges = new VariableSetter();

		[ORKEditorInfo("Update Variable Changes", "These variable changes are used each time the variables are changed " +
			"(excluding the update variable changes).", "",
			endFoldout=true)]
		[ORKEditorLayout("useUpdateVariables", true, endCheckGroup=true, autoInit=true)]
		public VariableSetter updateVariableChanges;

		public ShortcutVariableChanges()
		{

		}

		public bool HasUpdateChanges
		{
			get
			{
				return this.useUpdateVariables &&
					this.updateVariableChanges != null &&
					this.updateVariableChanges.HasChanges;
			}
		}
	}
}
