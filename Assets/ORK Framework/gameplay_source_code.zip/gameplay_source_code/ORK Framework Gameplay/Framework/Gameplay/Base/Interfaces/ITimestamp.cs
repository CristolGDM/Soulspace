﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface ITimestamp
	{
		float Timestamp
		{
			get;
			set;
		}
	}
}
