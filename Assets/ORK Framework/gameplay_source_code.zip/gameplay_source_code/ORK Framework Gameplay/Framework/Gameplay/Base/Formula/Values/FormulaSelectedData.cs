﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Formulas
{
	public class FormulaSelectedData : FormulaSelectedDataOrigin
	{
		[ORKEditorInfo(labelText="Selected Key")]
		public StringValue selectedKey = new StringValue();

		public FormulaSelectedData()
		{

		}

		public string GetInfoText()
		{
			return this.selectedKey.GetInfoText() + "(" + this.origin.ToString() + ")";
		}

		public int GetCount(FormulaCall call)
		{
			return this.GetCount(call, this.selectedKey.GetValue());
		}

		public List<object> GetSelectedData(FormulaCall call)
		{
			return this.GetSelectedData(call, this.selectedKey.GetValue());
		}

		public void Change(FormulaCall call, object data, ListChangeType changeType)
		{
			this.Change(call, this.selectedKey.GetValue(), data, changeType);
		}
	}
}
