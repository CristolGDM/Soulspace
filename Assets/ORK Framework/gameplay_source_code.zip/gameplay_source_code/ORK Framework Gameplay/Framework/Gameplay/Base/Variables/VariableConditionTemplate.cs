
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class VariableConditionTemplate : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of the variable condition template.", "")]
		[ORKEditorInfo("Template Settings", "Define the name of this variable condition template.", "", 
			endFoldout=true, expandWidth=true)]
		public string name = "";
		
		[ORKEditorInfo("Variable Condition", "Define the variable conditions of this template.\n" +
			"You can use this template in other variable conditions, e.g. in event interactions.", "", 
			endFoldout=true)]
		public VariableCondition condition = new VariableCondition();
		
		public VariableConditionTemplate()
		{
			
		}
		
		public VariableConditionTemplate(string name)
		{
			this.name = name;
		}
		
		public bool Check(VariableHandler handler)
		{
			return this.condition.CheckVariables(handler);
		}
	}
}
