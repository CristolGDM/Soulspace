﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Level", "The combatants level (or class level) will be compared to a defined value.", "")]
	public class LevelRequirementType : BaseStatusRequirementType
	{
		public ValueCheck check = new ValueCheck();


		// class level
		[ORKEditorHelp("Class Level", "If enabled, the combatants class level will be used instead of the base level.", "")]
		public bool classLevel = false;

		[ORKEditorHelp("Define Class", "Define the class which's class level will be checked.\n" +
			"If the combatant never used the defined class, it's class level will be 0.\n" +
			"If disabled, the class level of the combatant's current class will be checked.", "")]
		[ORKEditorLayout("classLevel", true)]
		public bool checkDefinedClassLevel = false;

		[ORKEditorHelp("Class", "Select the class which's level will be checked.\n" +
			"If the combatant never used the class, it's class level will be 0.", "")]
		[ORKEditorInfo(ORKDataType.Class)]
		[ORKEditorLayout("checkDefinedClassLevel", true, endCheckGroup=true, endGroups=2)]
		public int classLevelID = 0;


		public LevelRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.check.UpgradeFloat(data, "comparison", "value");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.check.Check(
				this.classLevel ?
					(this.checkDefinedClassLevel ?
						combatant.Class.GetLevel(this.classLevelID) :
						combatant.Class.Level) :
					combatant.Status.Level,
				combatant);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			if(this.classLevel)
			{
				combatant.Class.LevelChanged += notify.ClassLevelChanged;
			}
			else
			{
				combatant.Status.LevelChanged += notify.LevelChanged;
			}
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			if(this.classLevel)
			{
				combatant.Class.LevelChanged -= notify.ClassLevelChanged;
			}
			else
			{
				combatant.Status.LevelChanged -= notify.LevelChanged;
			}
		}
	}
}
