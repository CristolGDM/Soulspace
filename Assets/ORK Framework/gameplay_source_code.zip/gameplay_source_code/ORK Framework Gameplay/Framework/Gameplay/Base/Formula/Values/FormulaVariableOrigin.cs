﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Formulas
{
	public class FormulaVariableOrigin : BaseData
	{
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used while calculating a formula and don't interfere with global variables. " +
			"The variable will be gone once the formula finished calculating.\n" +
			"When a formula is called from an event, the local variables are shared with the event and " +
			"will also be available in the running event (until the event ends)." +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.\n" +
			"- Selected: Variables assigned to selected data coming from an event.\n" +
			"When coming from a battle event, the variables are usually assigned to the ability or item of the action.\n" +
			"Only available when the formula was initially called by an event.", "")]
		public VariableOrigin variableOrigin = VariableOrigin.Global;

		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("variableOrigin", VariableOrigin.Object, endCheckGroup=true, autoInit=true)]
		public FormulaStatusOrigin origin;

		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("variableOrigin", VariableOrigin.Selected, endCheckGroup=true, autoInit=true)]
		public FormulaSelectedData selectedData;

		public FormulaVariableOrigin()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(VariableOrigin.Selected == this.variableOrigin &&
				data.Contains<DataObject>("selectedKey"))
			{
				this.selectedData = new FormulaSelectedData();
				this.selectedData.SetData(data);
			}
		}

		public string GetInfoText()
		{
			return this.variableOrigin.ToString();
		}


		/*
		============================================================================
		Handler functions
		============================================================================
		*/
		public bool IsSingle
		{
			get
			{
				return VariableOrigin.Selected != this.variableOrigin;
			}
		}

		public VariableHandler GetSingle(FormulaCall call)
		{
			if(VariableOrigin.Local == this.variableOrigin)
			{
				return call.Variables;
			}
			else if(VariableOrigin.Global == this.variableOrigin)
			{
				return ORK.Game.Variables;
			}
			else if(VariableOrigin.Object == this.variableOrigin)
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null)
				{
					return combatant.Variables;
				}
			}
			return null;
		}

		public List<VariableHandler> GetMulti(FormulaCall call)
		{
			if(VariableOrigin.Selected == this.variableOrigin)
			{
				return SelectedDataHelper.GetVariableHandlers(
					this.selectedData.GetSelectedData(call));
			}
			return null;
		}

		public VariableHandler GetFirst(FormulaCall call)
		{
			if(VariableOrigin.Local == this.variableOrigin)
			{
				return call.Variables;
			}
			else if(VariableOrigin.Global == this.variableOrigin)
			{
				return ORK.Game.Variables;
			}
			else if(VariableOrigin.Object == this.variableOrigin)
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null)
				{
					return combatant.Variables;
				}
			}
			else if(VariableOrigin.Selected == this.variableOrigin)
			{
				return SelectedDataHelper.GetFirstVariableHandler(
					this.selectedData.GetSelectedData(call));
			}
			return null;
		}


		/*
		============================================================================
		Change functions
		============================================================================
		*/
		public void ChangeFloat(FormulaCall call, string key, float value, FormulaOperator floatOperator)
		{
			if(VariableOrigin.Local == this.variableOrigin)
			{
				call.Variables.ChangeFloat(key, call.result, floatOperator);
			}
			else if(VariableOrigin.Global == this.variableOrigin)
			{
				ORK.Game.Variables.ChangeFloat(key, call.result, floatOperator);
			}
			else if(VariableOrigin.Object == this.variableOrigin)
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null)
				{
					combatant.Variables.ChangeFloat(key, call.result, floatOperator);
				}
			}
			else if(VariableOrigin.Selected == this.variableOrigin)
			{
				List<VariableHandler> handlers = SelectedDataHelper.GetVariableHandlers(
					this.selectedData.GetSelectedData(call));
				for(int i = 0; i < handlers.Count; i++)
				{
					handlers[i].ChangeFloat(key, call.result, floatOperator);
				}
			}
		}
	}
}
