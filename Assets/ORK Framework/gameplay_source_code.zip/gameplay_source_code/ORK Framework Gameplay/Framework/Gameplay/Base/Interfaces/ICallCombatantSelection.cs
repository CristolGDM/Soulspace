﻿
using UnityEngine;
using ORKFramework.Menu.Parts;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface ICallCombatantSelection
	{
		void CallCombatantSelection(BaseMenuPart parent, bool useAction);
	}
}
