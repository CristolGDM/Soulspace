﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("In Action", "The combatant must or mustn't be in action (e.g. performing an ability).", "")]
	public class InActionRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Is In Action", "The combatant must be in action (e.g. performing an ability).\n" +
			"If disabled, the combatant mustn't be in action.", "")]
		public bool isInAction = true;

		public InActionRequirementType()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return (combatant.Actions.ActionState != CombatantActionState.Available) == this.isInAction;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Actions.ActionStateChanged += notify.CombatantActionStateChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Actions.ActionStateChanged -= notify.CombatantActionStateChanged;
		}
	}
}
