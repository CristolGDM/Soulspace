﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class RaycastUseSettings : BaseData
	{
		// raycast settings
		[ORKEditorHelp("Distance", "The distance the raycast will use.\n" +
			"If nothing is hit within this distance, no target will be found.", "")]
		public float distance = 100.0f;

		[ORKEditorHelp("Layer Mask", "Select the layer the raycast will use.\n" +
			"Only objects on this layer can be hit by the raycast.", "")]
		public LayerMask layerMask = -1;

		[ORKEditorHelp("Ray Origin", "The origin position of the raycast.\n" +
			"- User: A game object (e.g. an actor) is the origin.\n" +
			"- Screen: The screen is the origin. If you use mouse/touch control, " +
			"the point you clicked/touched the screen is the origin, otherwise the center of the screen.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75)]
		public TargetRayOrigin rayOrigin = TargetRayOrigin.User;

		[ORKEditorHelp("Use Mouse Position", "Use the current mouse position as target for the raycast.", "")]
		public bool useMousePosition = false;

		[ORKEditorHelp("Origin Offset", "The offset will be added to the origin position of the raycast.", "")]
		public Vector3 originOffset = Vector3.zero;


		// user
		[ORKEditorHelp("Ignore User", "The game object of the user will be ignored by the raycast.", "")]
		[ORKEditorLayout("rayOrigin", TargetRayOrigin.User)]
		public bool ignoreUser = false;

		[ORKEditorHelp("Direction", "The direction the raycast will be sent to (in local space of the user).\n" +
			"E.g. X=0, Y=0, Z=1 will send the raycast forward.\n" +
			"This setting is only used when not using mouse/touch input.", "")]
		[ORKEditorLayout("useMousePosition", false, endCheckGroup=true, endGroups=2)]
		public Vector3 rayDirection = Vector3.forward;

		public RaycastUseSettings()
		{

		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public Vector3 ScreenRayPoint(Vector3 point, Camera camera)
		{
			Ray ray = new Ray(Vector3.zero, Vector3.forward);

			if(camera != null)
			{
				ray = camera.ScreenPointToRay(point);
			}
			else if(ORK.Game.Camera != null)
			{
				ray = ORK.Game.Camera.ScreenPointToRay(point);
			}

			RaycastOutput hit = null;
			if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit, this.distance, this.layerMask))
			{
				point = hit.point;
			}
			else
			{
				point = ray.GetPoint(this.distance);
			}

			return point;
		}

		public Vector3 GetMousePosition()
		{
			Vector3 pos = this.originOffset + (Vector3)ORK.Control.MousePosition;
			pos = ORK.Core.UIMatrix.Matrix.MultiplyPoint3x4(pos);
			pos.y = Screen.height - pos.y;
			return pos;
		}

		public Ray GetRay(GameObject user, Camera camera)
		{
			if(TargetRayOrigin.User == this.rayOrigin)
			{
				if(user != null)
				{
					return new Ray(user.transform.position + this.originOffset,
						this.useMousePosition ?
							VectorHelper.GetDirection(user.transform.position + this.originOffset,
								this.ScreenRayPoint(this.GetMousePosition(), camera)) :
							user.transform.TransformDirection(this.rayDirection));
				}
			}
			else
			{
				Vector3 point = Vector3.zero;
				if(this.useMousePosition)
				{
					point = this.GetMousePosition();
				}
				else
				{
					point = ORK.GameSettings.GetScreenCenter() + this.originOffset;
					point = ORK.Core.UIMatrix.Matrix.MultiplyPoint3x4(point);
					point.y = Screen.height - point.y;
				}

				if(camera != null)
				{
					return camera.ScreenPointToRay(point);
				}
				else if(ORK.Game.Camera != null)
				{
					return ORK.Game.Camera.ScreenPointToRay(point);
				}
			}
			return new Ray();
		}


		/*
		============================================================================
		Raycast functions
		============================================================================
		*/
		public bool Raycast(GameObject user, Camera camera, out RaycastOutput hit)
		{
			Ray ray = this.GetRay(user, camera);

			if(TargetRayOrigin.User == this.rayOrigin)
			{
				if(user != null)
				{
					if(this.ignoreUser)
					{
						if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit,
							this.distance, this.layerMask, user.transform))
						{
							return true;
						}
					}
					else
					{
						if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit,
							this.distance, this.layerMask))
						{
							return true;
						}
					}
				}
			}
			else
			{
				if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit,
					this.distance, this.layerMask))
				{
					return true;
				}
			}

			hit = new RaycastOutput();
			return false;
		}

		public List<RaycastOutput> RaycastAll(GameObject user, Camera camera)
		{
			Ray ray = this.GetRay(user, camera);

			if(TargetRayOrigin.User == this.rayOrigin)
			{
				if(user != null)
				{
					if(this.ignoreUser)
					{
						return RaycastHelper.RaycastAll(ray.origin, ray.direction,
							this.distance, this.layerMask, user.transform);
					}
					else
					{
						return RaycastHelper.RaycastAll(ray.origin, ray.direction,
							this.distance, this.layerMask);
					}
				}
			}
			else
			{
				return RaycastHelper.RaycastAll(ray.origin, ray.direction,
					this.distance, this.layerMask);
			}
			return new List<RaycastOutput>();
		}
	}
}
