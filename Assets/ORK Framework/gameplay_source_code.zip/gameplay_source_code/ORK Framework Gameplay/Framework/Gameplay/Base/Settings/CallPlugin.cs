
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CallPlugin : BaseData
	{
		[ORKEditorHelp("Plugin", "Select the plugin that will be called.", "")]
		[ORKEditorInfo(ORKDataType.Plugin)]
		public int pluginID = 0;
		
		[ORKEditorHelp("Call Information", "The information text that will be passed to the plugin's 'Call' function.\n" +
			"You can use this text to trigger different things in the plugin.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string info = "";
		
		public CallPlugin()
		{
			
		}
		
		public bool Call()
		{
			PluginSetting plugin = ORK.Plugins.Get(this.pluginID);
			if(plugin.settings != null)
			{
				return plugin.settings.Call(this.info);
			}
			return false;
		}
	}
}
