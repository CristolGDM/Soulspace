﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CameraControlTargetTransition : BaseData
	{
		[ORKEditorHelp("Use Transition", "Use a transition when changing to a new camera control target.", "")]
		public bool enabled = false;

		[ORKEditorHelp("Transition Time (s)", "The time in seconds used to transition to the new camera control target.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("enabled", true)]
		public float time = 1.0f;

		[ORKEditorHelp("Per World Unit", "The transition time is per world unit distance between current and new camera control target.\n" +
			"E.g. a distance of 2 world units would multiply the transition time by 2.", "")]
		public bool perWorldUnit = false;


		// position
		[ORKEditorHelp("Use Position", "Transition the camera position.", "")]
		public bool usePosition = true;

		[ORKEditorHelp("Position Interpolation", "The interpolation used for the position transition.", "")]
		[ORKEditorLayout("usePosition", true, endCheckGroup=true)]
		public EaseType positionEaseType = EaseType.Linear;


		// rotation
		[ORKEditorHelp("Use Rotation", "Transition the camera rotation.", "")]
		public bool useRotation = true;

		[ORKEditorHelp("Rotation Interpolation", "The interpolation used for the rotation transition.", "")]
		[ORKEditorLayout("useRotation", true, endCheckGroup=true, endGroups=2)]
		public EaseType rotationEaseType = EaseType.Linear;


		// in-game
		private Function positionInterpolate;

		private Function rotationInterpolate;

		private float duration = 0;

		private Vector3 startPosition;

		private Quaternion startRotation;

		public CameraControlTargetTransition()
		{

		}

		public float Duration
		{
			get { return this.duration; }
		}


		/*
		============================================================================
		Transition functions
		============================================================================
		*/
		public void StartTransition(Transform transform, float distance)
		{
			if(this.usePosition)
			{
				this.startPosition = transform.position;
				if(this.positionInterpolate == null)
				{
					this.positionInterpolate = Interpolate.Ease(this.positionEaseType);
				}
			}
			if(this.useRotation)
			{
				this.startRotation = transform.rotation;
				if(this.rotationInterpolate == null)
				{
					this.rotationInterpolate = Interpolate.Ease(this.rotationEaseType); ;
				}
			}

			this.duration = this.perWorldUnit ? this.time * distance : this.time;
		}

		public bool Transition(Transform transform, Vector3 position, Quaternion rotation, float elapsedTime)
		{
			if(this.usePosition && this.useRotation)
			{
				transform.SetPositionAndRotation(
					Interpolate.Ease(this.positionInterpolate,
						this.startPosition, position - this.startPosition,
						elapsedTime, this.duration),
					Interpolate.Ease(this.rotationInterpolate,
						this.startRotation, Quaternion.Lerp(this.startRotation, rotation, elapsedTime / this.duration),
						elapsedTime, this.duration));
			}
			else
			{
				if(this.usePosition)
				{
					transform.position = Interpolate.Ease(this.positionInterpolate,
						this.startPosition, position - this.startPosition,
						elapsedTime, this.duration);
				}
				if(this.useRotation)
				{
					transform.rotation = Interpolate.Ease(this.rotationInterpolate,
						this.startRotation, Quaternion.Lerp(this.startRotation, rotation, elapsedTime / this.duration),
						elapsedTime, this.duration);
				}
			}

			return elapsedTime >= this.duration;
		}
	}
}
