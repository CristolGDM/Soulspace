
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class CheckGameVariable : BaseData, ISerializationCallbackReceiver
	{
		[ORKEditorHelp("Condition Type", "Select what will be checked:\n" +
			"- Variable: A single game variable will be checked.\n" +
			"- Conditions: Defined variable conditions will be checked, allows more complex conditions.\n" +
			"- Template: A variable condition template will be used.", "")]
		public GameVariableCheckType conditionType = GameVariableCheckType.Variable;


		// variable
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		[ORKEditorLayout("conditionType", GameVariableCheckType.Variable, autoInit=true)]
		public StringValue key = new StringValue();

		[ORKEditorLayout(endCheckGroup=true)]
		public CheckVariableBase variable = new CheckVariableBase();


		// conditions
		[ORKEditorLayout("conditionType", GameVariableCheckType.Conditions, endCheckGroup=true, autoInit=true)]
		public SimpleVariableCondition condition;



		// template
		[ORKEditorHelp("Template", "Select the variable condition template that will be used.", "")]
		[ORKEditorInfo(ORKDataType.VariableConditionTemplate)]
		[ORKEditorLayout("conditionType", GameVariableCheckType.Template, endCheckGroup=true)]
		public int templateID = 0;


		// old for component update
		[SerializeField]
		private bool isValid = true;

		[SerializeField]
		private CheckGameVariable.GameVariableType type = CheckGameVariable.GameVariableType.None;
		private enum GameVariableType { String, Bool, Float, Vector3, None }

		[SerializeField]
		private StringValue stringValue;

		[SerializeField]
		private CheckVariableBase.VariableValueCheck floatCheck = CheckVariableBase.VariableValueCheck.IsEqual;

		[SerializeField]
		private FloatValue floatValue;

		[SerializeField]
		private FloatValue floatValue2;

		[SerializeField]
		private CheckVariableBase.VariableValueCheck vector3Check = CheckVariableBase.VariableValueCheck.IsLess;

		[SerializeField]
		private FloatValue vector3Distance;

		[SerializeField]
		private FloatValue vector3Distance2;

		[SerializeField]
		private Vector3Value vector3Value;

		public CheckGameVariable()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(GameVariableCheckType.Variable == this.conditionType &&
				data.Contains<bool>("isValid"))
			{
				this.variable.SetData(data);
			}
		}

		public bool Check(VariableHandler handler)
		{
			if(GameVariableCheckType.Variable == this.conditionType)
			{
				return this.variable.Check(this.key.GetValue(), handler);
			}
			else if(GameVariableCheckType.Conditions == this.conditionType)
			{
				return this.condition.CheckVariables(handler);
			}
			else if(GameVariableCheckType.Template == this.conditionType)
			{
				return ORK.VariableConditionTemplates.Get(this.templateID).Check(handler);
			}
			return false;
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public void OnBeforeSerialize()
		{

		}

		public void OnAfterDeserialize()
		{
			if(GameVariableCheckType.Variable == this.conditionType &&
				CheckGameVariable.GameVariableType.None != this.type)
			{
				DataObject data = new DataObject();
				data.Set("isValid", this.isValid);
				data.SetEnum("type", this.type);
				if(CheckGameVariable.GameVariableType.String == this.type)
				{
					data.Set("stringValue", this.stringValue.GetData());
				}
				else if(CheckGameVariable.GameVariableType.Float == this.type)
				{
					data.SetEnum("floatCheck", this.floatCheck);
					data.Set("floatValue", this.floatValue.GetData());
					if(this.floatValue2 != null)
					{
						data.Set("floatValue2", this.floatValue2.GetData());
					}
				}
				else if(CheckGameVariable.GameVariableType.Vector3 == this.type)
				{
					data.Set("vector3Check", this.vector3Check);
					data.Set("vector3Distance", this.vector3Distance.GetData());
					data.Set("vector3Value", this.vector3Value.GetData());
					if(this.vector3Distance2 != null)
					{
						data.Set("vector3Distance2", this.vector3Distance2.GetData());
					}
				}
				this.variable.SetData(data);

				this.type = CheckGameVariable.GameVariableType.None;
				this.stringValue = null;
				this.floatCheck = CheckVariableBase.VariableValueCheck.None;
				this.floatValue = null;
				this.floatValue2 = null;
				this.vector3Check = CheckVariableBase.VariableValueCheck.None;
				this.vector3Distance = null;
				this.vector3Distance2 = null;
				this.vector3Value = null;
			}
		}
	}
}
