﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CustomTextCode : BaseData
	{
		[ORKEditorHelp("Text Code", "Define the custom text code that will be used.\n" +
			"It's recommended to start a text code with a '%'-sign, e.g. %customCode.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string textCode = "";

		[ORKEditorHelp("Text", "The text used to replace the defined text code.", "")]
		[ORKEditorInfo(isTextArea=true)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public string[] value = ArrayHelper.CreateArray(ORK.Languages.Count, "");

		public CustomTextCode()
		{

		}

		public void Replace(ref string text)
		{
			text = text.Replace(this.textCode, this.value[ORK.Game.Language]);
		}
	}
}
