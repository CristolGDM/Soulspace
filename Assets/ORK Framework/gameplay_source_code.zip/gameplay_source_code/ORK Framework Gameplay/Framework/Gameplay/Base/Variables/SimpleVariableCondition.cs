
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class SimpleVariableCondition : BaseData
	{
		[ORKEditorHelp("Needed", "Either all or just one of the variable conditions needs to be valid.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.All;

		[ORKEditorArray(false, "Add Game Variable", "Adds a new game variable condition.", "",
			"Remove", "Removes the game variable condition.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Variable Condition", "Define the game variable condition that must be valid.", ""
		})]
		public SimpleCheckGameVariable[] gameVariable = new SimpleCheckGameVariable[0];

		public SimpleVariableCondition()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool CheckVariables()
		{
			return this.CheckVariables(ORK.Game.Variables);
		}

		public bool CheckVariables(VariableHandler handler)
		{
			if(this.gameVariable.Length > 0)
			{
				for(int i = 0; i < this.gameVariable.Length; i++)
				{
					if(this.gameVariable[i].Check(handler))
					{
						if(Needed.One == this.needed)
						{
							return true;
						}
					}
					else if(Needed.All == this.needed)
					{
						return false;
					}
				}
				if(Needed.All == this.needed)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return true;
			}
		}
	}
}
