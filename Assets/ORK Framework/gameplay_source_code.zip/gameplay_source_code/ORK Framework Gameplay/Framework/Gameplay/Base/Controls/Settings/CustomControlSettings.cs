
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CustomControlSettings : BaseData
	{
		[ORKEditorArray(false, "Add Custom Control", "Adds a control behaviour.\n" +
			"Control behaviours will be automatically enabled/disabled by ORK when the selected control state changes.\n" +
			"Add control behaviours if you're using your own player or camera control scripts.", "",
			"Remove", "Removes the control behaviour.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Custom Control", "Define the name and settings of the custom control behaviour.", ""
		})]
		public ControlBehaviour[] behaviours = new ControlBehaviour[0];

		public CustomControlSettings()
		{

		}


		/*
		============================================================================
		Player control functions
		============================================================================
		*/
		public void AddControlsToPlayer(GameObject player)
		{
			for(int i = 0; i < this.behaviours.Length; i++)
			{
				if(CustomControlType.Player == this.behaviours[i].objectType)
				{
					this.behaviours[i].Add(player);
				}
			}
		}

		public void RemoveControlsFromPlayer(GameObject player)
		{
			for(int i = 0; i < this.behaviours.Length; i++)
			{
				if(CustomControlType.Player == this.behaviours[i].objectType)
				{
					this.behaviours[i].Remove(player);
				}
			}
		}


		/*
		============================================================================
		Camera control functions
		============================================================================
		*/
		public void AddControlsToCamera(GameObject camera)
		{
			for(int i = 0; i < this.behaviours.Length; i++)
			{
				if(CustomControlType.Camera == this.behaviours[i].objectType)
				{
					this.behaviours[i].Add(camera);
				}
			}
		}

		public void RemoveControlsFromCamera(GameObject camera)
		{
			for(int i = 0; i < this.behaviours.Length; i++)
			{
				if(CustomControlType.Camera == this.behaviours[i].objectType)
				{
					this.behaviours[i].Remove(camera);
				}
			}
		}
	}
}
