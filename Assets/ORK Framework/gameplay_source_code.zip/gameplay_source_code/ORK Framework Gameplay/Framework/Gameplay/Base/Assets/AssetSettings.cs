﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public enum AssetBundleLoadType { LoadFromFile, LoadFromMemory }

	public class AssetSettings : BaseData
	{
		[ORKEditorHelp("Unload Resources", "Scene changes will unload all unused resources.\n" +
			"This is done before changing to the new scene.", "")]
		public bool unloadResourcesOnSceneChange = false;

		[ORKEditorHelp("Unload Asset Bundles", "Scene changes will unload asset bundles that where loaded by ORK.\n" +
			"This is done before changing to the new scene.", "")]
		public bool unloadAssetBundlesOnSceneChange = false;

		[ORKEditorHelp("Default Asset Bundle Path", "Define the default path asset bundles will be available at.\n" +
			"The asset bundles will be loaded using 'AssetBundle.LoadFromFile' using this path (and the asset bundle name).\n" +
			"Individual asset selections can override the default asset bundle path.", "")]
		public ApplicationPath defaultAssetBundlePath = new ApplicationPath(ApplicationPathType.StreamingAssetsPath);

		[ORKEditorHelp("Default Load Type", "Select the default way asset bundles will be loaded:\n" + 
			"- Load From File: Uses 'AssetBundle.LoadFromFile'.\n" + 
			"- Load From Memory: Uses 'AssetBundle.LoadFromMemory' after loading the bundle's data via 'File.ReadAllBytes'.", "")]
		public AssetBundleLoadType defaultAssetBundleLoadType = AssetBundleLoadType.LoadFromFile;


		// load asset bundles
		[ORKEditorArray(false, "Add Load Asset Bundle", "Adds an asset bundle that will be loaded when ORK is initialized.\n" +
			"Asset bundles will be loaded using 'AssetBundle.LoadFromFile' and only load the bundle's definition and not the assets within. " +
			"Having asset bundles loaded shouldn't have a huge impact on memory or performance.", "",
			"Remove", "Removes this asset bundle.", "",
			isCopy=true, isMove=true, foldout=true, foldoutText= new string[] {
				"Load Asset Bundle", "Define the asset bundle that will be loaded when ORK is initialized.\n" +
				"Asset bundles will be loaded using 'AssetBundle.LoadFromFile' and only load the bundle's definition and not the assets within. " +
				"Having asset bundles loaded shouldn't have a huge impact on memory or performance.", ""
		})]
		[ORKEditorInfo(callbackBefore="button:loadassetbundles", callbackAfter="button:assetsources")]
		public AssetBundleSettings[] loadAssetBundle = new AssetBundleSettings[0];

		public AssetSettings()
		{

		}

		public void LoadAssetBundles()
		{
			for(int i = 0; i < this.loadAssetBundle.Length; i++)
			{
				this.loadAssetBundle[i].LoadBundle();
			}
		}
	}
}
