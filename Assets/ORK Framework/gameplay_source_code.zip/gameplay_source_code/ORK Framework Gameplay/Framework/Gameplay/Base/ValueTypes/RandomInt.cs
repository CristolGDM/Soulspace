
using UnityEngine;

namespace ORKFramework
{
	public class RandomInt : BaseData
	{
		[ORKEditorHelp("Minimum Random", "The minimum random value (inclusive).", "")]
		public int min = 0;
		
		[ORKEditorHelp("Maximum Random", "The maximum random value (inclusive).", "")]
		[ORKEditorLimit("min", false)]
		public int max = 0;
		
		public RandomInt()
		{
			
		}
		
		public int GetValue()
		{
			return UnityWrapper.Range(this.min, this.max + 1);
		}
	}
}
