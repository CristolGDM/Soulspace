﻿
using UnityEngine;

namespace ORKFramework
{
	public class Vector2Fader
	{
		private bool fading = false;

		private Function ease;

		private Vector2 start = Vector2.zero;

		private Vector2 distance = Vector2.zero;

		private Vector2 target = Vector2.zero;

		private float time = 0;

		private float time2 = 0;

		public Vector2Fader(EaseType interpolation, float time)
		{
			this.ease = Interpolate.Ease(interpolation);
			this.time2 = time;
		}

		public bool Fading
		{
			get { return this.fading; }
		}

		public Vector2 Target
		{
			get { return this.target; }
		}

		public void Start(Vector2 start, Vector2 target)
		{
			this.start = start;
			this.target = target;
			this.distance = target - start;
			this.time = 0;
			this.fading = true;
		}

		public void Fade(ref Vector2 value, float t)
		{
			this.time += t;
			value = Interpolate.Ease(this.ease, this.start, this.distance, this.time, this.time2);

			if(this.time >= this.time2)
			{
				this.fading = false;
			}
		}
	}
}
