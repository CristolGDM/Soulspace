
using UnityEngine;

namespace ORKFramework
{
	public class Language : BaseIndexData, IContentSimple
	{
		[ORKEditorHelp("Name", "The name of the language.\n" +
			"It is displayed in editors where you enter texts for this " +
			"language and in the language selection of the main menu.", "")]
		[ORKEditorInfo("Name/Icon", "Set the name and icon of the language.", "",
			expandWidth=true)]
		public string name = "";

		[ORKEditorHelp("Short Name", "Define the short name of the language.\n" +
			"The name is used if no short name is defined.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string shortName = "";

		[ORKEditorHelp("Description", "The description of the language.\n" +
			"It can be displayed in the language selection of the main menu.", "")]
		[ORKEditorInfo(isTextArea=true)]
		public string description = "";

		[ORKEditorHelp("Icon", "The icon of the language.\n" +
			"It is displayed in the language selection of the main menu.\n" +
			"Select none if no item should be displayed.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public AssetSource<Texture> icon = new AssetSource<Texture>();


		// settings
		[ORKEditorHelp("Initial Language", "This language will be the initially selected language when starting the game.\n" +
			"If no language is set as initial language, the first language (index 0) will be used.", "")]
		[ORKEditorInfo("Language Settings", "Base settings for this language.", "", endFoldout=true,
			callbackAfter="check:initiallanguage")]
		public bool initialLanguage = false;

		public Language()
		{

		}

		public Language(string n)
		{
			this.name = n;
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			this.icon.Upgrade(data, "icon");
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get { return this.realID; }
		}

		public string GetName()
		{
			return this.name;
		}

		public string GetShortName()
		{
			return this.shortName == "" ? this.name : this.shortName;
		}

		public string GetDescription()
		{
			return this.description;
		}

		public string GetIconTextCode()
		{
			return TextCode.LanguageIcon + this.realID + "#";
		}

		public Texture GetIcon()
		{
			return this.icon;
		}

		public GUIContent GetContent()
		{
			return new GUIContent(this.name, this.icon);
		}
	}
}
