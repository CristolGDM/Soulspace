
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Animations
{
	public class MecanimStateCheck : BaseData
	{
		[ORKEditorHelp("Active State Name", "The name of the active state (without layer name).", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("Layer Index", "The index of the AnimatorController layer that will be checked.", "")]
		[ORKEditorLimit(0, false)]
		public int layer = 0;
		
		[ORKEditorHelp("Layer Name", "The name of the AnimatorController layer that will be checked.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string layerName = "Base Layer";
		
		[ORKEditorHelp("Check Transition", "Check if the AnimatorController layer is in a transition.", "")]
		public bool checkTransition = false;
		
		[ORKEditorHelp("In Transition", "The layer must be in transition.\n" +
			"If disabled, the layer mustn't be in transition.", "")]
		[ORKEditorLayout("checkTransition", true, endCheckGroup=true)]
		public bool inTransition = false;
		
		
		// set values
		[ORKEditorArray(false, "Add Parameter", "Adds a parameter that will be set.", "", 
			"Remove", "Removes this parameter.", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {"Set Parameter", "The parameter will be set to the defined value.", ""})]
		public MecanimParameter[] parameter = new MecanimParameter[0];
		
		
		// ingame
		private int stateID = 0;
		
		public MecanimStateCheck()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.stateID = Animator.StringToHash(this.layerName + "." + this.name);
		}
		
		
		/*
		============================================================================
		Value functions
		============================================================================
		*/
		public void Check(Animator animator)
		{
			if(animator.GetCurrentAnimatorStateInfo(this.layer).fullPathHash == this.stateID && 
				(!this.checkTransition || animator.IsInTransition(this.layer) == this.inTransition))
			{
				for(int i=0; i<this.parameter.Length; i++)
				{
					this.parameter[i].Set(animator);
				}
			}
		}
	}
}
