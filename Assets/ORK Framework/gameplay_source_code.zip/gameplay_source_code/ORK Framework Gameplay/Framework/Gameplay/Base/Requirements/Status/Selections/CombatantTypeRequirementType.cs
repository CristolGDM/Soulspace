﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Combatant Type", "The combatant must or mustn't be of the selected combatant type.", "")]
	public class CombatantTypeRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Combatant Type", "Select the combatant type that will be used.", "")]
		[ORKEditorInfo(ORKDataType.CombatantType)]
		public int combatantTypeID = 0;

		[ORKEditorHelp("Is Combatant Type", "The combatant must be the selected combatant type.\n" +
			"If disabled, the combatant mustn't be the selected combatant type.", "")]
		public bool isCombatantType = true;

		public CombatantTypeRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.combatantTypeID);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return (combatant.TypeID == this.combatantTypeID) == this.isCombatantType;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{

		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{

		}
	}
}
