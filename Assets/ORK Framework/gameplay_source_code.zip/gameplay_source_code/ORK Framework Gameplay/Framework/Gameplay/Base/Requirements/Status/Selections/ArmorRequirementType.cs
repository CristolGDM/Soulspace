﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Armor", "A defined armor must or mustn't be equipped.", "")]
	public class ArmorRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Armor", "Select the armor that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Armor)]
		public int armorID = 0;

		[ORKEditorHelp("Level", "The level of the armor that will be checked for.\n" +
			"The combatant must have at least the defined equipment level equipped.", "")]
		[ORKEditorLimit(1, false)]
		public int level = 1;

		[ORKEditorHelp("Is Equipped", "The armor must be equipped on the combatant.\n" +
			"If disabled, the armor mustn't be equipped.", "")]
		public bool isEquipped = true;

		[ORKEditorHelp("Check Equipment Part", "Check if the armor is equipped on a defined equipment part.\n" +
			"If disabled, checks if the armor is equipped on any part.", "")]
		public bool checkEquipmentPart = false;

		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be check.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		[ORKEditorLayout("checkEquipmentPart", true, endCheckGroup=true)]
		public int equipmentPartID = 0;

		public ArmorRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.armorID);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return combatant.Equipment.IsEquipped(EquipSet.Armor, this.armorID, this.level,
				this.checkEquipmentPart ? this.equipmentPartID : -1) == this.isEquipped;
		}

		public override bool CheckBestiary(Combatant combatant)
		{
			if(combatant.Bestiary != null &&
				(combatant.Bestiary.IsComplete ||
				combatant.Bestiary.status.equipment))
			{
				return this.Check(combatant);
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Equipment.Changed += notify.EquipmentChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Equipment.Changed -= notify.EquipmentChanged;
		}
	}
}
