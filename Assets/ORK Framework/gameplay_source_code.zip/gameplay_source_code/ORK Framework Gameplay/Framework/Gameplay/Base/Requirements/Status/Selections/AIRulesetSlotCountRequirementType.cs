﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("AI Ruleset Slot Count", "The combatant's AI number of ruleset slot will be compared to a defined value..", "")]
	public class AIRulesetSlotCountRequirementType : BaseStatusRequirementType
	{
		public ValueCheck check = new ValueCheck();

		public AIRulesetSlotCountRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("aiSlotCount"))
			{
				this.check.UpgradeInt(data, "aiSlotComparison", "aiSlotCount");
			}
			else
			{
				this.check.UpgradeInt(data, "comparison", "slotCount");
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.check.Check(combatant.AI.AIRulesetSlot.Length, combatant);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.AI.Changed += notify.CombatantAIChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.AI.Changed -= notify.CombatantAIChanged;
		}
	}
}
