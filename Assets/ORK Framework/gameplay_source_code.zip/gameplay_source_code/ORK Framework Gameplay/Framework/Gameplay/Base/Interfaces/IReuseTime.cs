﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IReuseTime
	{
		bool IsReuseTime(EndAfter type);

		string GetReuseTimeText(Combatant user, int decimals);

		float GetReuseTime(Combatant user);

		float GetMaxReuseTime(Combatant user);
	}
}
