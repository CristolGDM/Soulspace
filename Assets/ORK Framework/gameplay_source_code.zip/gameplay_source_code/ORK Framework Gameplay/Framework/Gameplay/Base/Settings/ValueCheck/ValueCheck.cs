﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ValueCheck : BaseData
	{
		[ORKEditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than the defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		public ValueCheckType type = ValueCheckType.IsEqual;

		[ORKEditorInfo("Check Value", "The value used for the check.\n" +
			"In range inclusive/exclusive checks, this is the lower limit.", "",
			endFoldout=true)]
		public FloatValue value = new FloatValue();

		[ORKEditorInfo("Check Value 2", "The value used for the check (upper limit).", "",
			endFoldout=true)]
		[ORKEditorLayout(new string[] { "type", "type" } ,
			new System.Object[] { ValueCheckType.RangeInclusive, ValueCheckType.RangeExclusive },
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public FloatValue value2;

		public ValueCheck()
		{

		}

		public ValueCheck(float value)
		{
			this.value = new FloatValue(value);
		}

		public bool Check(int checkValue, Combatant combatant)
		{
			return ValueHelper.CheckValue(checkValue,
				(int)this.value.GetValue(combatant, combatant, null, null),
				this.value2 != null ? (int)this.value2.GetValue(combatant, combatant, null, null) : 0,
				this.type);
		}

		public bool Check(float checkValue, Combatant combatant)
		{
			return ValueHelper.CheckValue(checkValue,
				this.value.GetValue(combatant, combatant, null, null),
				this.value2 != null ? this.value2.GetValue(combatant, combatant, null, null) : 0.0f,
				this.type);
		}

		public bool Check(int checkValue, Combatant user, Combatant target)
		{
			return ValueHelper.CheckValue(checkValue,
				(int)this.value.GetValue(user, target, null, null),
				this.value2 != null ? (int)this.value2.GetValue(user, target, null, null) : 0,
				this.type);
		}

		public bool Check(float checkValue, Combatant user, Combatant target)
		{
			return ValueHelper.CheckValue(checkValue,
				this.value.GetValue(user, target, null, null),
				this.value2 != null ? this.value2.GetValue(user, target, null, null) : 0.0f,
				this.type);
		}

		public bool CheckOffset(int checkValue, int offset, Combatant user, Combatant target)
		{
			return ValueHelper.CheckValue(checkValue,
				(int)this.value.GetValue(user, target, null, null) + offset,
				(this.value2 != null ? (int)this.value2.GetValue(user, target, null, null) : 0) + offset,
				this.type);
		}

		public bool CheckOffset(float checkValue, float offset, Combatant user, Combatant target)
		{
			return ValueHelper.CheckValue(checkValue,
				this.value.GetValue(user, target, null, null) + offset,
				(this.value2 != null ? this.value2.GetValue(user, target, null, null) : 0.0f) + offset,
				this.type);
		}

		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			return this.type.ToString() + " " +
				this.value.GetInfoText() +
				(ValueCheckType.RangeInclusive == this.type || ValueCheckType.RangeExclusive == this.type ?
					" ~ " + this.value2.GetInfoText() : "");
		}


		/*
		============================================================================
		Upgrade functions
		============================================================================
		*/
		public static void UpgradeOldType(DataObject data, string typeName, ref ValueCheckType type)
		{
			int tmp = -1;
			data.Get(typeName, ref tmp);
			if(tmp == 0)
			{
				type = ValueCheckType.IsEqual;
			}
			else if(tmp == 1)
			{
				type = ValueCheckType.IsLess;
			}
			else if(tmp == 2)
			{
				type = ValueCheckType.IsGreater;
			}
			else if(tmp == 3)
			{
				type = ValueCheckType.NotEqual;
			}
		}

		public static void UpgradeOldTypeVariable(DataObject data, string typeName, ref ValueCheckType type)
		{
			int tmp = -1;
			data.Get(typeName, ref tmp);
			if(tmp == 0)
			{
				type = ValueCheckType.IsEqual;
			}
			else if(tmp == 1)
			{
				type = ValueCheckType.IsLess;
			}
			else if(tmp == 2)
			{
				type = ValueCheckType.IsGreater;
			}
			else if(tmp == 3)
			{
				type = ValueCheckType.NotEqual;
			}
			else if(tmp == 4)
			{
				type = ValueCheckType.RangeInclusive;
			}
			else if(tmp == 5)
			{
				type = ValueCheckType.RangeExclusive;
			}
			else if(tmp == 6)
			{
				type = ValueCheckType.Approximately;
			}
		}

		public void UpgradeInt(DataObject data, string typeName, string valueName)
		{
			if(data.Contains<int>(typeName))
			{
				int tmpValue = 0;
				data.Get(valueName, ref tmpValue);
				this.value = new FloatValue(tmpValue);

				ValueCheck.UpgradeOldType(data, typeName, ref this.type);
			}
		}

		public void UpgradeFloat(DataObject data, string typeName, string valueName)
		{
			if(data.Contains<int>(typeName))
			{
				float tmpValue = 0;
				data.Get(valueName, ref tmpValue);
				this.value = new FloatValue(tmpValue);

				ValueCheck.UpgradeOldType(data, typeName, ref this.type);
			}
		}

		public void UpgradeFloat(DataObject data, string typeName, string valueName, string value2Name)
		{
			if(data.Contains<int>(typeName))
			{
				ValueCheck.UpgradeOldTypeVariable(data, typeName, ref this.type);

				float tmpValue = 0;
				data.Get(valueName, ref tmpValue);
				this.value = new FloatValue(tmpValue);

				if(ValueCheckType.RangeInclusive == this.type ||
					ValueCheckType.RangeExclusive == this.type)
				{
					tmpValue = 0;
					data.Get(valueName, ref tmpValue);
					this.value2 = new FloatValue(tmpValue);
				}
			}
		}

		public void UpgradeFloatValue(DataObject data, string typeName, string valueName, string value2Name)
		{
			if(data.Contains<int>(typeName))
			{
				ValueCheck.UpgradeOldTypeVariable(data, typeName, ref this.type);

				this.value.SetData(data.GetFile(valueName));
				if(ValueCheckType.RangeInclusive == this.type ||
					ValueCheckType.RangeExclusive == this.type)
				{
					this.value2 = new FloatValue();
					this.value2.SetData(data.GetFile(value2Name));
				}

			}
		}
	}
}
