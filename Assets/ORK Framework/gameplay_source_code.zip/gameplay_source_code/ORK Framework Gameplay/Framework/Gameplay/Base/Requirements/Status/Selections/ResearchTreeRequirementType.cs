﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Research Tree", "The combatant must know the defined research tree.", "")]
	public class ResearchTreeRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Research Tree", "Select the research tree that will be used.", "")]
		[ORKEditorInfo(ORKDataType.ResearchTree)]
		public int researchTreeID = 0;

		[ORKEditorHelp("Research Tree State", "Select the state that will be checked:\n" +
			"- Known: The combatant must know the research tree.\n" +
			"- Unknown: The combatant mustn't know the research tree.\n" +
			"- Complete: The combatant must know the research tree and fully researched all research items.", "")]
		public ResearchTreeStateCheck researchTreeState = ResearchTreeStateCheck.Known;

		public ResearchTreeRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.researchTreeID);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return combatant.Research.CheckTreeState(this.researchTreeID, this.researchTreeState);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Research.Changed += notify.CombatantResearchChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Research.Changed -= notify.CombatantResearchChanged;
		}
	}
}
