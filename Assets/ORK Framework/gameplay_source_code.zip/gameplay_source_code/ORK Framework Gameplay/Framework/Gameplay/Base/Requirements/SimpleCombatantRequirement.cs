
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class SimpleCombatantRequirement : BaseData
	{
		// status requirements
		[ORKEditorHelp("Needed", "Either all or only one requirement must be met.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75, labelText="Status Requirements")]
		public Needed needed = Needed.All;

		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "",
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be met to use this prefab.", ""
		})]
		public StatusRequirement[] req = new StatusRequirement[0];


		// variable conditions
		[ORKEditorHelp("Use Object Variable", "Use object variables of the combatant.\n" +
			"The combatant's game object must have an 'Object Variables' component attached, " +
			"otherwise the check fails.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Conditions")]
		public bool useObjectVariable = false;

		public VariableCondition condition = new VariableCondition();

		public SimpleCombatantRequirement()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool Check(Combatant combatant)
		{
			return combatant != null &&
				StatusRequirement.Check(combatant, this.req, this.needed) &&
				this.CheckVariables(combatant, null);
		}

		public bool Check(Combatant combatant, VariableHandler handler)
		{
			return combatant != null &&
				StatusRequirement.Check(combatant, this.req, this.needed) &&
				this.CheckVariables(combatant, handler);
		}

		public bool CheckVariables(Combatant combatant, VariableHandler handler)
		{
			handler = this.GetUsedVariableHandler(combatant, handler);
			if(handler != null)
			{
				return this.condition.CheckVariables(handler);
			}
			return false;
		}

		private VariableHandler GetUsedVariableHandler(Combatant combatant, VariableHandler handler)
		{
			if(this.useObjectVariable)
			{
				if(combatant != null)
				{
					return combatant.Variables;
				}
			}
			else if(handler != null)
			{
				return handler;
			}
			else
			{
				return ORK.Game.Variables;
			}
			return null;
		}

		public void FilterList(ref List<Combatant> list)
		{
			if(list != null)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(!this.Check(list[i]))
					{
						list.RemoveAt(i--);
					}
				}
			}
		}


		/*
		============================================================================
		Register functions
		============================================================================
		*/
		public void RegisterChanges(Combatant combatant, IStatusChanged statusChanged, Notify variablesChanged)
		{
			// status changes
			for(int i = 0; i < this.req.Length; i++)
			{
				this.req[i].RegisterStatusChanges(combatant, statusChanged);
			}

			// variable changes
			if(this.condition.Has)
			{
				VariableHandler handler = this.GetUsedVariableHandler(combatant, null);
				if(handler != null)
				{
					handler.Changed += variablesChanged;
				}
			}
		}

		public void UnregisterChanges(Combatant combatant, IStatusChanged statusChanged, Notify variablesChanged)
		{
			// status changes
			for(int i = 0; i < this.req.Length; i++)
			{
				this.req[i].UnregisterStatusChanges(combatant, statusChanged);
			}

			// variable changes
			if(this.condition.Has)
			{
				VariableHandler handler = this.GetUsedVariableHandler(combatant, null);
				if(handler != null)
				{
					handler.Changed -= variablesChanged;
				}
			}
		}
	}
}
