﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IInventoryExchange
	{
		Combatant GetOwner();

		IContentSimple GetContent();

		void CheckDataChanged(bool checkItems, bool checkWeapons, bool checkArmors,
			bool checkAIBehaviours, bool checkAIRulesets, bool checkCraftingRecipes);

		bool IsEmpty
		{
			get;
		}

		event Notify Changed;


		/*
		============================================================================
		Item type functions
		============================================================================
		*/
		void GetItemTypes(int parentType, ref List<int> list, bool onlySellable,
			bool addMoney, bool addEmptyMoney, bool addItems, bool addWeapons, bool addArmor,
			bool addAIBehaviours, bool addAIRulesets, bool addCraftingRecipes);

		bool HasNewItemTypes(bool checkParent, List<int> types, bool onlySellable,
			bool addItems, bool addWeapons, bool addArmor,
			bool addAIBehaviours, bool addAIRulesets, bool addCraftingRecipes);

		bool HasItemType(bool checkParent, int typeID, bool onlySellable,
			bool addMoney, bool addEmptyMoney, bool addItems, bool addWeapons, bool addArmor,
			bool addAIBehaviours, bool addAIRulesets, bool addCraftingRecipes, bool checkNewContent);


		/*
		============================================================================
		Inventory functions
		============================================================================
		*/
		void GetAll(bool addMoney, bool addEmptyMoney, bool addItems, bool addWeapons, bool addArmor,
			bool addAIBehaviours, bool addAIRulesets, bool addCraftingRecipes,
			int typeID, bool checkParent, ref List<IInventoryShortcut> list);

		bool AddAccess(IShortcut item, bool showNotification, bool showConsole, bool markNewContent);

		void RemoveAccess(IShortcut item, int quantity, bool showNotification, bool showConsole);

		void DropAccess(IShortcut item, int quantity, bool showNotification, bool showConsole);

		int GetAllowedQuantity(IShortcut shortcut, int quantity);

		int GetCount(IShortcut item);

		bool HasEnoughMoney(int id, int quantity);

		int GetMoney(int id);

		void AddMoneyAccess(int id, int quantity, bool showNotification, bool showConsole);

		void SubMoneyAccess(int id, int quantity, bool showNotification, bool showConsole);
	}
}
