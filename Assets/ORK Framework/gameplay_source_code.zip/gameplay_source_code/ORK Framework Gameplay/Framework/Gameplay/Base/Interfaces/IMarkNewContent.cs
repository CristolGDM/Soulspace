﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IMarkNewContent
	{
		void UnmarkID(int id);

		bool IsNewContent
		{
			get;
			set;
		}
	}
}
